# CampusSolve: Emergency Contact Organizer - Executive Summary
**Generated:** 2026-11-26 13:33:23  
**Campus Safety Domain:** Comprehensive Audit & Status Insight  

---
## 1. High-Level Operational Metrics
- **Total Emergency Contacts Registered:** 37
- **24/7 Emergency Services Available:** 18 (48.6% coverage)
- **Contacts in Active Compliance:** 33
- **Audit Review Recommended (>180d):** 3
- **Critical Overdue Inquiries (>90d for SOS):** 1  

## 2. Category Distribution
| Category | Count | Percentage |
| :--- | :---: | :---: |
| Administration | 10 | 27.0% |
| Security | 5 | 13.5% |
| Fire & Safety | 5 | 13.5% |
| External Emergency | 5 | 13.5% |
| Mental Health | 4 | 10.8% |
| Medical | 3 | 8.1% |
| Facilities | 3 | 8.1% |
| Residence/Housing | 2 | 5.4% |

## 3. Priority Tier Breakdown
| Priority Tier | Count | Description |
| :--- | :---: | :--- |
| SOS/Critical | 9 | Top-level instant responder |
| High | 8 | Standard operational tier |
| Medium | 10 | Standard operational tier |
| Standard | 10 | Standard operational tier |

## 4. Threshold Warnings & Anomalies (7 Detected)
| Severity | Contact ID | Name | Issue Flag |
| :--- | :--- | :--- | :--- |
| **CRITICAL** | `CAMP-1005` | Campus Sexual Assault Support (Title IX) | SOS Contact verification overdue! Last verified 164 days ago (limit: 90 days). |
| **HIGH** | `CAMP-1005` | Campus Sexual Assault Support (Title IX) | SOS contact has NO secondary/backup phone number registered. |
| **WARNING** | `CAMP-1012` | Radiation Safety & Lab Officer | Contact verification is stale (230 days ago, recommended audit interval: 180 days). |
| **WARNING** | `CAMP-1018` | Biological Waste & Biohazard Hotline | Contact verification is stale (257 days ago, recommended audit interval: 180 days). |
| **HIGH** | `CAMP-1028` | Regional Poison Control Center | SOS contact has NO secondary/backup phone number registered. |
| **WARNING** | `CAMP-1030` | State Spill Response & Environmental Hotline | Contact verification is stale (200 days ago, recommended audit interval: 180 days). |
| **HIGH** | `CAMP-1036` | Campus Emergency Rapid Response | SOS contact has NO secondary/backup phone number registered. |

## 5. Master Directory Roster
| ID | Name | Category | Primary Phone | 24/7 | Priority | Last Verified |
| :--- | :--- | :--- | :--- | :---: | :--- | :--- |
| CAMP-1036 | Campus Emergency Rapid Response | Security | 555-0888 | YES | SOS/Critical | 2026-11-23 |
| CAMP-1001 | Campus Police 24/7 Dispatch | Security | 555-0100 | YES | SOS/Critical | 2026-11-15 |
| CAMP-1005 | Campus Sexual Assault Support (Title IX) | Mental Health | 555-0144 | YES | SOS/Critical | 2026-06-15 |
| CAMP-1004 | Crisis & Suicide Prevention Lifeline | Mental Health | 555-0199 | YES | SOS/Critical | 2026-11-01 |
| CAMP-1002 | Emergency Medical Trauma Center | Medical | 555-0111 | YES | SOS/Critical | 2026-11-10 |
| CAMP-1003 | Fire & Hazmat Emergency Response | Fire & Safety | 555-0119 | YES | SOS/Critical | 2026-10-28 |
| CAMP-1027 | Metro Fire & Rescue Department | External Emergency | 911 | YES | SOS/Critical | 2026-11-20 |
| CAMP-1026 | Municipal City Police Emergency | External Emergency | 911 | YES | SOS/Critical | 2026-11-20 |
| CAMP-1028 | Regional Poison Control Center | External Emergency | 1-800-222-1222 | YES | SOS/Critical | 2026-11-01 |
| CAMP-1010 | Campus SafeWalk Escort Service | Security | 555-0177 | No | High | 2026-11-12 |
| CAMP-1029 | County Mental Health Mobile Crisis Unit | External Emergency | 988 | YES | High | 2026-10-18 |
| CAMP-1008 | Dean of Students Emergency Office | Administration | 555-0150 | No | High | 2026-09-12 |
| CAMP-1009 | Facilities Gas & Electrical Hazard Desk | Facilities | 555-0160 | YES | High | 2026-11-02 |
| CAMP-1007 | Hostel / Residence Warden Emergency Desk | Residence/Housing | 555-0130 | YES | High | 2026-11-05 |
| CAMP-1034 | Night Shuttle On-Call Dispatch | Administration | 555-0380 | YES | High | 2026-11-19 |
| CAMP-1006 | Student Health Services Clinic | Medical | 555-0122 | No | High | 2026-10-15 |
| CAMP-1035 | University Public Affairs & Media Hotline | Administration | 555-0390 | YES | High | 2026-10-30 |
| CAMP-1014 | Athletics & Gym First Aid Room | Medical | 555-0230 | No | Medium | 2026-11-08 |
| CAMP-1018 | Biological Waste & Biohazard Hotline | Fire & Safety | 555-0270 | No | Medium | 2026-03-14 |
| CAMP-1015 | Campus IT Cyber Incident Response Team | Administration | 555-0240 | YES | Medium | 2026-11-18 |
| CAMP-1011 | Counseling & Psychological Services (CAPS) | Mental Health | 555-0188 | No | Medium | 2026-10-01 |
| CAMP-1016 | Disability & Accessibility Transport | Administration | 555-0250 | No | Medium | 2026-10-10 |
| CAMP-1033 | Engineering Robotics Lab Safety Monitor | Fire & Safety | 555-0370 | No | Medium | 2026-11-14 |
| CAMP-1013 | International Student Support Coordinator | Administration | 555-0220 | No | Medium | 2026-10-20 |
| CAMP-1012 | Radiation Safety & Lab Officer | Fire & Safety | 555-0210 | No | Medium | 2026-04-10 |
| CAMP-1017 | South Campus Housing Security Office | Residence/Housing | 555-0260 | YES | Medium | 2026-11-01 |
| CAMP-1030 | State Spill Response & Environmental Hotline | External Emergency | 1-800-424-8802 | YES | Medium | 2026-05-10 |
| CAMP-1023 | Campus Animal Welfare & Pest Control | Facilities | 555-0320 | No | Standard | 2026-08-15 |
| CAMP-1032 | Campus Chaplaincy & Spiritual Grief Support | Mental Health | 555-0360 | No | Standard | 2026-09-15 |
| CAMP-1021 | Campus Food Pantry Emergency Hampers | Administration | 555-0300 | No | Standard | 2026-09-30 |
| CAMP-1019 | Campus Lost and Found & Key Control | Security | 555-0280 | No | Standard | 2026-10-25 |
| CAMP-1022 | Environmental Health & Occupational Safety | Fire & Safety | 555-0310 | No | Standard | 2026-10-14 |
| CAMP-1025 | Legal Aid Clinic for Students | Administration | 555-0340 | No | Standard | 2026-10-05 |
| CAMP-1020 | Parking & Campus Transit Dispatch | Administration | 555-0290 | No | Standard | 2026-11-04 |
| CAMP-1024 | Residence Maintenance (Plumbing & HVAC) | Facilities | 555-0330 | YES | Standard | 2026-11-16 |
| CAMP-1031 | Student Government Emergency Relief Fund | Administration | 555-0350 | No | Standard | 2026-10-22 |
| CAMP-1037 | Valid Name Test | Security | 555-1234 | No | Standard | 2026-11-23 |