/**
 * CampusSolve - Emergency Contact Organizer
 * Interactive Frontend Controller (Dual-Engine: REST API + Offline Browser Storage)
 */

// Embedded Initial Sample Dataset (35 verified campus records)
const SEED_CONTACTS = [
  {
    "contact_id": "CAMP-1001",
    "name": "Campus Police 24/7 Dispatch",
    "category": "Security",
    "primary_phone": "555-0100",
    "secondary_phone": "555-0101",
    "email": "police@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Security HQ Rm 101",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-15",
    "notes": "Immediate response dispatch unit"
  },
  {
    "contact_id": "CAMP-1002",
    "name": "Emergency Medical Trauma Center",
    "category": "Medical",
    "primary_phone": "555-0111",
    "secondary_phone": "555-0112",
    "email": "emt@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Health Pavilion Wing A",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-10",
    "notes": "Paramedic ambulance station on campus"
  },
  {
    "contact_id": "CAMP-1003",
    "name": "Fire & Hazmat Emergency Response",
    "category": "Fire & Safety",
    "primary_phone": "555-0119",
    "secondary_phone": "555-0120",
    "email": "hazmat@campus.edu",
    "campus_zone": "Science Complex",
    "building_room": "Chemical Safety Bldg B",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-10-28",
    "notes": "Chemical spill and rapid fire suppression"
  },
  {
    "contact_id": "CAMP-1004",
    "name": "Crisis & Suicide Prevention Lifeline",
    "category": "Mental Health",
    "primary_phone": "555-0199",
    "secondary_phone": "1-800-273-8255",
    "email": "crisis@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Student Well-being Suite 300",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-01",
    "notes": "Confidential 24/7 mental health emergency team"
  },
  {
    "contact_id": "CAMP-1005",
    "name": "Campus Sexual Assault Support (Title IX)",
    "category": "Mental Health",
    "primary_phone": "555-0144",
    "secondary_phone": "",
    "email": "advocate@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Student Services Rm 204",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-06-15",
    "notes": "Confidential victim advocacy (Needs backup phone)"
  },
  {
    "contact_id": "CAMP-1006",
    "name": "Student Health Services Clinic",
    "category": "Medical",
    "primary_phone": "555-0122",
    "secondary_phone": "555-0123",
    "email": "health@campus.edu",
    "campus_zone": "North Campus",
    "building_room": "Infirmary Bldg Level 1",
    "is_24_7": false,
    "priority_tier": "High",
    "last_verified_date": "2026-10-15",
    "notes": "Mon-Fri 8am-8pm, Sat 9am-2pm urgent walk-in"
  },
  {
    "contact_id": "CAMP-1007",
    "name": "Hostel / Residence Warden Emergency Desk",
    "category": "Residence/Housing",
    "primary_phone": "555-0130",
    "secondary_phone": "555-0131",
    "email": "warden@campus.edu",
    "campus_zone": "Student Residences",
    "building_room": "Dorm Quad Main Office",
    "is_24_7": true,
    "priority_tier": "High",
    "last_verified_date": "2026-11-05",
    "notes": "Dorm lockouts, domestic issues, building emergencies"
  },
  {
    "contact_id": "CAMP-1008",
    "name": "Dean of Students Emergency Office",
    "category": "Administration",
    "primary_phone": "555-0150",
    "secondary_phone": "",
    "email": "dean.emergency@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Administration Tower Rm 401",
    "is_24_7": false,
    "priority_tier": "High",
    "last_verified_date": "2026-09-12",
    "notes": "Student family emergencies and academic accommodations"
  },
  {
    "contact_id": "CAMP-1009",
    "name": "Facilities Gas & Electrical Hazard Desk",
    "category": "Facilities",
    "primary_phone": "555-0160",
    "secondary_phone": "555-0161",
    "email": "facilities.rapid@campus.edu",
    "campus_zone": "Engineering Block",
    "building_room": "Power Substation B",
    "is_24_7": true,
    "priority_tier": "High",
    "last_verified_date": "2026-11-02",
    "notes": "Gas leaks, live wires, flooding emergencies"
  },
  {
    "contact_id": "CAMP-1010",
    "name": "Campus SafeWalk Escort Service",
    "category": "Security",
    "primary_phone": "555-0177",
    "secondary_phone": "",
    "email": "safewalk@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Student Union Ground Floor",
    "is_24_7": false,
    "priority_tier": "High",
    "last_verified_date": "2026-11-12",
    "notes": "Night-time walking escort 6 PM - 4 AM"
  },
  {
    "contact_id": "CAMP-1011",
    "name": "Counseling & Psychological Services (CAPS)",
    "category": "Mental Health",
    "primary_phone": "555-0188",
    "secondary_phone": "",
    "email": "counseling@campus.edu",
    "campus_zone": "North Campus",
    "building_room": "Wellness Center Rm 110",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-10-01",
    "notes": "Individual and group counseling appointments"
  },
  {
    "contact_id": "CAMP-1012",
    "name": "Radiation Safety & Lab Officer",
    "category": "Fire & Safety",
    "primary_phone": "555-0210",
    "secondary_phone": "",
    "email": "radsafety@campus.edu",
    "campus_zone": "Science Complex",
    "building_room": "Physics Hall Rm 402",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-04-10",
    "notes": "Stale verification test case (Overdue > 180 days)"
  },
  {
    "contact_id": "CAMP-1013",
    "name": "International Student Support Coordinator",
    "category": "Administration",
    "primary_phone": "555-0220",
    "secondary_phone": "",
    "email": "intl.support@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Global Center Rm 105",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-10-20",
    "notes": "Visa & passport emergency assistance"
  },
  {
    "contact_id": "CAMP-1014",
    "name": "Athletics & Gym First Aid Room",
    "category": "Medical",
    "primary_phone": "555-0230",
    "secondary_phone": "",
    "email": "gym.firstaid@campus.edu",
    "campus_zone": "Athletics Center",
    "building_room": "Fieldhouse Rm 12",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-11-08",
    "notes": "Sports injuries and physical rehab"
  },
  {
    "contact_id": "CAMP-1015",
    "name": "Campus IT Cyber Incident Response Team",
    "category": "Administration",
    "primary_phone": "555-0240",
    "secondary_phone": "555-0241",
    "email": "soc@campus.edu",
    "campus_zone": "Science Complex",
    "building_room": "Data Center Annex",
    "is_24_7": true,
    "priority_tier": "Medium",
    "last_verified_date": "2026-11-18",
    "notes": "Data breach, ransomware, server outage response"
  },
  {
    "contact_id": "CAMP-1016",
    "name": "Disability & Accessibility Transport",
    "category": "Administration",
    "primary_phone": "555-0250",
    "secondary_phone": "",
    "email": "access.rides@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Transit Depot",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-10-10",
    "notes": "Wheelchair van shuttle on demand"
  },
  {
    "contact_id": "CAMP-1017",
    "name": "South Campus Housing Security Office",
    "category": "Residence/Housing",
    "primary_phone": "555-0260",
    "secondary_phone": "",
    "email": "south.housing@campus.edu",
    "campus_zone": "South Campus",
    "building_room": "Tower C Gatehouse",
    "is_24_7": true,
    "priority_tier": "Medium",
    "last_verified_date": "2026-11-01",
    "notes": "South quad student residence safety"
  },
  {
    "contact_id": "CAMP-1018",
    "name": "Biological Waste & Biohazard Hotline",
    "category": "Fire & Safety",
    "primary_phone": "555-0270",
    "secondary_phone": "",
    "email": "biohazard@campus.edu",
    "campus_zone": "Science Complex",
    "building_room": "Biomedical Tower Rm 103",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-03-14",
    "notes": "Biohazard containment protocol (Stale audit)"
  },
  {
    "contact_id": "CAMP-1019",
    "name": "Campus Lost and Found & Key Control",
    "category": "Security",
    "primary_phone": "555-0280",
    "secondary_phone": "",
    "email": "lostfound@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Welcome Center Rm 12",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-10-25",
    "notes": "Recover lost IDs, laptops, transit passes"
  },
  {
    "contact_id": "CAMP-1020",
    "name": "Parking & Campus Transit Dispatch",
    "category": "Administration",
    "primary_phone": "555-0290",
    "secondary_phone": "",
    "email": "parking@campus.edu",
    "campus_zone": "North Campus",
    "building_room": "Parking Structure 2",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-11-04",
    "notes": "Vehicle battery jump, flat tire assistance"
  },
  {
    "contact_id": "CAMP-1021",
    "name": "Campus Food Pantry Emergency Hampers",
    "category": "Administration",
    "primary_phone": "555-0300",
    "secondary_phone": "",
    "email": "pantry@campus.edu",
    "campus_zone": "South Campus",
    "building_room": "Basement Dining Hall",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-09-30",
    "notes": "Food security assistance for students"
  },
  {
    "contact_id": "CAMP-1022",
    "name": "Environmental Health & Occupational Safety",
    "category": "Fire & Safety",
    "primary_phone": "555-0310",
    "secondary_phone": "",
    "email": "ehs@campus.edu",
    "campus_zone": "Science Complex",
    "building_room": "Safety Bldg Rm 201",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-10-14",
    "notes": "Ergonomics, workplace air quality testing"
  },
  {
    "contact_id": "CAMP-1023",
    "name": "Campus Animal Welfare & Pest Control",
    "category": "Facilities",
    "primary_phone": "555-0320",
    "secondary_phone": "",
    "email": "pestcontrol@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Maintenance Yards",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-08-15",
    "notes": "Wildlife removal and safety"
  },
  {
    "contact_id": "CAMP-1024",
    "name": "Residence Maintenance (Plumbing & HVAC)",
    "category": "Facilities",
    "primary_phone": "555-0330",
    "secondary_phone": "",
    "email": "dorm.repair@campus.edu",
    "campus_zone": "Student Residences",
    "building_room": "Underground Shop 3",
    "is_24_7": true,
    "priority_tier": "Standard",
    "last_verified_date": "2026-11-16",
    "notes": "24/7 pipe burst and heating failure repairs"
  },
  {
    "contact_id": "CAMP-1025",
    "name": "Legal Aid Clinic for Students",
    "category": "Administration",
    "primary_phone": "555-0340",
    "secondary_phone": "",
    "email": "legalaid@campus.edu",
    "campus_zone": "North Campus",
    "building_room": "Law Annex Rm 310",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-10-05",
    "notes": "Tenant rights and emergency legal consultation"
  },
  {
    "contact_id": "CAMP-1026",
    "name": "Municipal City Police Emergency",
    "category": "External Emergency",
    "primary_phone": "911",
    "secondary_phone": "555-0911",
    "email": "dispatch@citypolice.gov",
    "campus_zone": "Campus-Wide",
    "building_room": "Off-Campus Station 4",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-20",
    "notes": "City police joint jurisdiction dispatch"
  },
  {
    "contact_id": "CAMP-1027",
    "name": "Metro Fire & Rescue Department",
    "category": "External Emergency",
    "primary_phone": "911",
    "secondary_phone": "555-0912",
    "email": "alarm@metrofire.gov",
    "campus_zone": "Campus-Wide",
    "building_room": "Station 7 (0.8 miles from campus)",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-20",
    "notes": "City fire department ladder and engine truck"
  },
  {
    "contact_id": "CAMP-1028",
    "name": "Regional Poison Control Center",
    "category": "External Emergency",
    "primary_phone": "1-800-222-1222",
    "secondary_phone": "",
    "email": "help@poisoncontrol.org",
    "campus_zone": "Campus-Wide",
    "building_room": "National Network",
    "is_24_7": true,
    "priority_tier": "SOS/Critical",
    "last_verified_date": "2026-11-01",
    "notes": "Toxic ingestion and snake bite emergency advice"
  },
  {
    "contact_id": "CAMP-1029",
    "name": "County Mental Health Mobile Crisis Unit",
    "category": "External Emergency",
    "primary_phone": "988",
    "secondary_phone": "555-0988",
    "email": "mobilecrisis@countyhealth.gov",
    "campus_zone": "Campus-Wide",
    "building_room": "County Health Dept",
    "is_24_7": true,
    "priority_tier": "High",
    "last_verified_date": "2026-10-18",
    "notes": "Off-campus rapid mental crisis deployment"
  },
  {
    "contact_id": "CAMP-1030",
    "name": "State Spill Response & Environmental Hotline",
    "category": "External Emergency",
    "primary_phone": "1-800-424-8802",
    "secondary_phone": "",
    "email": "spill@state.gov",
    "campus_zone": "Campus-Wide",
    "building_room": "State Environmental Agency",
    "is_24_7": true,
    "priority_tier": "Medium",
    "last_verified_date": "2026-05-10",
    "notes": "Overdue verification test case"
  },
  {
    "contact_id": "CAMP-1031",
    "name": "Student Government Emergency Relief Fund",
    "category": "Administration",
    "primary_phone": "555-0350",
    "secondary_phone": "",
    "email": "sga.relief@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Student Union 312",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-10-22",
    "notes": "Micro-grants for sudden unexpected crises"
  },
  {
    "contact_id": "CAMP-1032",
    "name": "Campus Chaplaincy & Spiritual Grief Support",
    "category": "Mental Health",
    "primary_phone": "555-0360",
    "secondary_phone": "",
    "email": "chaplain@campus.edu",
    "campus_zone": "North Campus",
    "building_room": "Interfaith Chapel",
    "is_24_7": false,
    "priority_tier": "Standard",
    "last_verified_date": "2026-09-15",
    "notes": "Multi-faith bereavement support"
  },
  {
    "contact_id": "CAMP-1033",
    "name": "Engineering Robotics Lab Safety Monitor",
    "category": "Fire & Safety",
    "primary_phone": "555-0370",
    "secondary_phone": "",
    "email": "robo.safety@campus.edu",
    "campus_zone": "Engineering Block",
    "building_room": "Robotics High Bay Rm 105",
    "is_24_7": false,
    "priority_tier": "Medium",
    "last_verified_date": "2026-11-14",
    "notes": "High voltage and mechanical arm emergency stop"
  },
  {
    "contact_id": "CAMP-1034",
    "name": "Night Shuttle On-Call Dispatch",
    "category": "Administration",
    "primary_phone": "555-0380",
    "secondary_phone": "",
    "email": "nightshuttle@campus.edu",
    "campus_zone": "Campus-Wide",
    "building_room": "Transit Depot",
    "is_24_7": true,
    "priority_tier": "High",
    "last_verified_date": "2026-11-19",
    "notes": "Late night safe transit for campus commuters"
  },
  {
    "contact_id": "CAMP-1035",
    "name": "University Public Affairs & Media Hotline",
    "category": "Administration",
    "primary_phone": "555-0390",
    "secondary_phone": "",
    "email": "press.emergency@campus.edu",
    "campus_zone": "Central Quad",
    "building_room": "Media Center Rm 50",
    "is_24_7": true,
    "priority_tier": "High",
    "last_verified_date": "2026-10-30",
    "notes": "Emergency communications and campus-wide alerts"
  }
];

// State
let allContacts = [];
let currentFiltered = [];
let currentView = 'grid'; // 'grid' | 'table'
let isBackendConnected = false;

// DOM Elements
const backendStatusBadge = document.getElementById('backendStatusBadge');
const backendStatusDot = document.getElementById('backendStatusDot');
const backendStatusText = document.getElementById('backendStatusText');

const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const zoneFilter = document.getElementById('zoneFilter');
const priorityFilter = document.getElementById('priorityFilter');
const only247Toggle = document.getElementById('only247Toggle');
const resultsCount = document.getElementById('resultsCount');

const contactsGrid = document.getElementById('contactsGrid');
const contactsTableContainer = document.getElementById('contactsTableContainer');
const contactsTableBody = document.getElementById('contactsTableBody');
const emptyState = document.getElementById('emptyState');

// Metrics elements
const statTotalContacts = document.getElementById('statTotalContacts');
const statCount247 = document.getElementById('statCount247');
const statPct247 = document.getElementById('statPct247');
const statVerifiedCurrent = document.getElementById('statVerifiedCurrent');
const statWarningsCount = document.getElementById('statWarningsCount');

// Warning Banner
const warningBannerSection = document.getElementById('warningBannerSection');
const warningHeaderTitle = document.getElementById('warningHeaderTitle');
const warningHeaderSub = document.getElementById('warningHeaderSub');
const warningItemsList = document.getElementById('warningItemsList');
const btnDismissWarnings = document.getElementById('btnDismissWarnings');

// Modals
const contactModal = document.getElementById('contactModal');
const modalTitle = document.getElementById('modalTitle');
const contactForm = document.getElementById('contactForm');
const formErrorMessage = document.getElementById('formErrorMessage');
const btnOpenAddModal = document.getElementById('btnOpenAddModal');
const btnCloseContactModal = document.getElementById('btnCloseContactModal');
const btnCancelContactForm = document.getElementById('btnCancelContactForm');
const btnSaveContact = document.getElementById('btnSaveContact');

const importModal = document.getElementById('importModal');
const btnOpenImportModal = document.getElementById('btnOpenImportModal');
const btnCloseImportModal = document.getElementById('btnCloseImportModal');
const btnCancelImport = document.getElementById('btnCancelImport');
const btnExecuteImport = document.getElementById('btnExecuteImport');
const btnLoadSampleCSV = document.getElementById('btnLoadSampleCSV');
const csvFileInput = document.getElementById('csvFileInput');
const csvTextarea = document.getElementById('csvTextarea');
const importResultBox = document.getElementById('importResultBox');

// Export Menu
const btnExportMenu = document.getElementById('btnExportMenu');
const exportDropdownMenu = document.getElementById('exportDropdownMenu');

// Views
const btnViewGrid = document.getElementById('btnViewGrid');
const btnViewTable = document.getElementById('btnViewTable');

// Form Fields
const formContactId = document.getElementById('formContactId');
const formName = document.getElementById('formName');
const formCategory = document.getElementById('formCategory');
const formPriority = document.getElementById('formPriority');
const formPrimaryPhone = document.getElementById('formPrimaryPhone');
const formSecondaryPhone = document.getElementById('formSecondaryPhone');
const formEmail = document.getElementById('formEmail');
const formZone = document.getElementById('formZone');
const formRoom = document.getElementById('formRoom');
const formIs247 = document.getElementById('formIs247');
const formVerifiedDate = document.getElementById('formVerifiedDate');
const formNotes = document.getElementById('formNotes');

// Toast Container
const toastContainer = document.getElementById('toastContainer');

// ==========================================
// INITIALIZATION
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
  initIcons();
  setupEventListeners();

  if (formVerifiedDate) {
    formVerifiedDate.value = new Date().toISOString().split('T')[0];
  }

  await initializeApp();
});

function initIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

async function initializeApp() {
  try {
    const res = await fetch('/api/contacts', { method: 'GET', headers: { 'Accept': 'application/json' } });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data)) {
        isBackendConnected = true;
        allContacts = data;
        updateStatusBadge(true, 'Python REST API');
        await fetchMetrics();
        applyFilters();
        return;
      }
    }
  } catch (e) {
    // Backend offline / static server
  }

  isBackendConnected = false;
  updateStatusBadge(false, 'Local Browser Storage');
  loadFromLocalStorage();
  applyFilters();
}

function updateStatusBadge(connected, text) {
  if (!backendStatusBadge) return;
  backendStatusBadge.className = connected 
    ? 'hidden sm:inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200'
    : 'hidden sm:inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded-full bg-amber-100 text-amber-800 border border-amber-200';
  
  if (backendStatusDot) {
    backendStatusDot.className = connected
      ? 'w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse'
      : 'w-1.5 h-1.5 rounded-full bg-amber-500 mr-1.5';
  }
  if (backendStatusText) {
    backendStatusText.textContent = text;
  }
}

function loadFromLocalStorage() {
  const saved = localStorage.getItem('campussolve_contacts_v1');
  if (saved) {
    try {
      allContacts = JSON.parse(saved);
    } catch (e) {
      allContacts = [...SEED_CONTACTS];
    }
  } else {
    allContacts = [...SEED_CONTACTS];
    saveToLocalStorage();
  }
  updateLocalMetrics();
}

function saveToLocalStorage() {
  localStorage.setItem('campussolve_contacts_v1', JSON.stringify(allContacts));
  updateLocalMetrics();
}

function updateLocalMetrics() {
  const total = allContacts.length;
  const count247 = allContacts.filter(c => c.is_24_7).length;
  const pct247 = total > 0 ? ((count247 / total) * 100).toFixed(1) : 0;

  const today = new Date();
  let verifiedCurrent = 0;
  let needsReview = 0;
  let criticalOverdue = 0;
  const warnings = [];

  allContacts.forEach(c => {
    let days = 0;
    try {
      const vd = new Date(c.last_verified_date);
      days = Math.floor((today - vd) / (1000 * 60 * 60 * 24));
    } catch (e) {
      days = 999;
    }

    if (c.priority_tier === 'SOS/Critical' && days > 90) {
      criticalOverdue++;
      warnings.push({
        contact_id: c.contact_id,
        name: c.name,
        severity: 'CRITICAL',
        message: `SOS contact verification overdue (${days} days ago, limit: 90 days).`
      });
    } else if (days > 180) {
      needsReview++;
      warnings.push({
        contact_id: c.contact_id,
        name: c.name,
        severity: 'WARNING',
        message: `Verification stale (${days} days ago, recommended audit interval: 180 days).`
      });
    } else {
      verifiedCurrent++;
    }

    if (c.priority_tier === 'SOS/Critical' && (!c.secondary_phone || c.secondary_phone.trim() === '')) {
      warnings.push({
        contact_id: c.contact_id,
        name: c.name,
        severity: 'HIGH',
        message: 'Critical SOS contact has NO secondary fallback phone.'
      });
    }

    if (!c.building_room || ['tbd', 'unknown', 'n/a', '-'].includes(c.building_room.toLowerCase().trim())) {
      warnings.push({
        contact_id: c.contact_id,
        name: c.name,
        severity: 'MEDIUM',
        message: 'Physical room / location is marked unassigned or TBD.'
      });
    }
  });

  updateMetricsUI({
    total_contacts: total,
    count_24_7: count247,
    pct_24_7: pct247,
    audit_status: { verified_current: verifiedCurrent, needs_review: needsReview, critical_overdue: criticalOverdue },
    warnings_count: warnings.length,
    warnings
  });
}

async function fetchMetrics() {
  if (!isBackendConnected) {
    updateLocalMetrics();
    return;
  }
  try {
    const res = await fetch('/api/metrics');
    if (res.ok) {
      const data = await res.json();
      updateMetricsUI(data);
    }
  } catch (err) {
    updateLocalMetrics();
  }
}

function updateMetricsUI(m) {
  if (statTotalContacts) statTotalContacts.textContent = m.total_contacts || 0;
  if (statCount247) statCount247.textContent = m.count_24_7 || 0;
  if (statPct247) statPct247.textContent = `(${m.pct_24_7 || 0}%)`;
  if (statVerifiedCurrent) statVerifiedCurrent.textContent = m.audit_status ? m.audit_status.verified_current : 0;
  if (statWarningsCount) statWarningsCount.textContent = m.warnings_count || 0;

  const warnings = m.warnings || [];
  if (warningBannerSection) {
    if (warnings.length > 0) {
      warningBannerSection.classList.remove('hidden');
      if (warningHeaderTitle) warningHeaderTitle.textContent = `${warnings.length} Threshold Warning Flag${warnings.length > 1 ? 's' : ''} Active`;
      if (warningItemsList) {
        warningItemsList.innerHTML = warnings.map(w => `
          <div class="flex items-center justify-between py-1 border-b border-amber-200/50 last:border-b-0">
            <div>
              <span class="font-bold uppercase tracking-wider text-[10px] px-1.5 py-0.5 rounded ${w.severity === 'CRITICAL' ? 'bg-red-200 text-red-800' : 'bg-amber-200 text-amber-900'}">${w.severity}</span>
              <span class="font-medium ml-1.5">[${w.contact_id}] ${escapeHtml(w.name)}:</span>
              <span class="text-amber-900">${escapeHtml(w.message)}</span>
            </div>
            <button onclick="quickAuditContact('${w.contact_id}')" class="text-[11px] font-semibold text-amber-900 hover:text-red-700 underline ml-2 shrink-0">
              Verify Today
            </button>
          </div>
        `).join('');
      }
    } else {
      warningBannerSection.classList.add('hidden');
    }
  }
}

window.quickAuditContact = async function(contactId) {
  const today = new Date().toISOString().split('T')[0];
  if (isBackendConnected) {
    try {
      const res = await fetch(`/api/contacts/${contactId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ last_verified_date: today })
      });
      if (res.ok) {
        showToast(`Contact [${contactId}] marked verified as of today!`, 'success');
        const cres = await fetch('/api/contacts');
        allContacts = await cres.json();
        await fetchMetrics();
        applyFilters();
        return;
      }
    } catch (e) {}
  }

  const idx = allContacts.findIndex(c => c.contact_id === contactId);
  if (idx !== -1) {
    allContacts[idx].last_verified_date = today;
    saveToLocalStorage();
    showToast(`Contact [${contactId}] marked verified as of today!`, 'success');
    applyFilters();
  }
};

function applyFilters() {
  const q = searchInput ? searchInput.value.trim().toLowerCase() : '';
  const selectedCat = categoryFilter ? categoryFilter.value.trim().toLowerCase() : '';
  const selectedZone = zoneFilter ? zoneFilter.value.trim().toLowerCase() : '';
  const selectedPrio = priorityFilter ? priorityFilter.value.trim().toLowerCase() : '';
  const only247 = only247Toggle ? only247Toggle.checked : false;

  currentFiltered = allContacts.filter(c => {
    if (only247 && !c.is_24_7) return false;
    if (selectedCat && c.category.toLowerCase() !== selectedCat) return false;
    if (selectedZone && c.campus_zone.toLowerCase() !== selectedZone) return false;
    if (selectedPrio && c.priority_tier.toLowerCase() !== selectedPrio) return false;
    if (q) {
      const haystack = `${c.contact_id} ${c.name} ${c.category} ${c.primary_phone} ${c.secondary_phone || ''} ${c.email || ''} ${c.campus_zone} ${c.building_room} ${c.notes || ''}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  if (resultsCount) {
    resultsCount.textContent = `Showing ${currentFiltered.length} of ${allContacts.length} contacts`;
  }
  renderContacts();
}

function renderContacts() {
  if (!contactsGrid || !contactsTableContainer || !emptyState) return;

  if (currentFiltered.length === 0) {
    contactsGrid.classList.add('hidden');
    contactsTableContainer.classList.add('hidden');
    emptyState.classList.remove('hidden');
    initIcons();
    return;
  }

  emptyState.classList.add('hidden');

  if (currentView === 'grid') {
    contactsGrid.classList.remove('hidden');
    contactsTableContainer.classList.add('hidden');
    renderGrid();
  } else {
    contactsGrid.classList.add('hidden');
    contactsTableContainer.classList.remove('hidden');
    renderTable();
  }

  initIcons();
}

function getPriorityClass(prio) {
  if (prio === 'SOS/Critical') return 'badge-sos';
  if (prio === 'High') return 'badge-high';
  if (prio === 'Medium') return 'badge-medium';
  return 'badge-standard';
}

function getCategoryClass(cat) {
  const c = (cat || '').toLowerCase();
  if (c.includes('security')) return 'badge-cat-security';
  if (c.includes('medical')) return 'badge-cat-medical';
  if (c.includes('mental')) return 'badge-cat-mental';
  if (c.includes('fire')) return 'badge-cat-fire';
  if (c.includes('residence') || c.includes('housing')) return 'badge-cat-residence';
  if (c.includes('facilities')) return 'badge-cat-facilities';
  if (c.includes('external')) return 'badge-cat-external';
  return 'badge-cat-admin';
}

function renderGrid() {
  contactsGrid.innerHTML = currentFiltered.map(c => {
    const prioBadge = getPriorityClass(c.priority_tier);
    const catBadge = getCategoryClass(c.category);
    const isSos = c.priority_tier === 'SOS/Critical';

    return `
      <div class="contact-card bg-white rounded-xl border ${isSos ? 'border-red-300 ring-1 ring-red-200' : 'border-slate-200'} shadow-sm p-4 flex flex-col justify-between">
        <div>
          <div class="flex items-center justify-between gap-2 mb-2">
            <span class="text-[11px] font-semibold px-2 py-0.5 rounded-md ${catBadge}">
              ${escapeHtml(c.category)}
            </span>
            <div class="flex items-center space-x-1.5">
              ${c.is_24_7 ? `
                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1 animate-pulse"></span> 24/7
                </span>
              ` : ''}
              <span class="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${prioBadge}">
                ${escapeHtml(c.priority_tier)}
              </span>
            </div>
          </div>

          <div class="mb-3">
            <div class="text-[11px] font-mono text-slate-400 font-medium">${c.contact_id}</div>
            <h3 class="text-sm font-bold text-slate-900 leading-snug">${escapeHtml(c.name)}</h3>
          </div>

          <div class="space-y-1.5 text-xs text-slate-600 mb-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
            <div class="flex items-center justify-between">
              <span class="font-semibold text-slate-700 flex items-center">
                <i data-lucide="phone" class="w-3.5 h-3.5 mr-1.5 text-red-500"></i>
                ${escapeHtml(c.primary_phone)}
              </span>
              <div class="flex items-center space-x-1">
                <button onclick="copyToClipboard('${c.primary_phone}')" class="p-1 hover:bg-slate-200 rounded text-slate-500" title="Copy Number">
                  <i data-lucide="copy" class="w-3.5 h-3.5"></i>
                </button>
                <a href="tel:${c.primary_phone.replace(/[^0-9+]/g, '')}" class="p-1 hover:bg-red-100 rounded text-red-600 font-bold" title="Call">
                  <i data-lucide="phone-call" class="w-3.5 h-3.5"></i>
                </a>
              </div>
            </div>

            ${c.secondary_phone ? `
              <div class="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                <span class="flex items-center">
                  <i data-lucide="phone-forwarded" class="w-3 h-3 mr-1 text-slate-400"></i>
                  Alt: ${escapeHtml(c.secondary_phone)}
                </span>
                <button onclick="copyToClipboard('${c.secondary_phone}')" class="p-0.5 hover:bg-slate-200 rounded text-slate-400" title="Copy">
                  <i data-lucide="copy" class="w-3 h-3"></i>
                </button>
              </div>
            ` : ''}

            ${c.email ? `
              <div class="flex items-center text-[11px] text-slate-500 pt-1 border-t border-slate-200/60 truncate">
                <i data-lucide="mail" class="w-3 h-3 mr-1.5 text-slate-400 shrink-0"></i>
                <a href="mailto:${escapeHtml(c.email)}" class="hover:underline text-blue-600 truncate">${escapeHtml(c.email)}</a>
              </div>
            ` : ''}
          </div>

          <div class="text-xs space-y-1 mb-2 text-slate-600">
            <div class="flex items-center">
              <i data-lucide="map-pin" class="w-3.5 h-3.5 mr-1.5 text-slate-400 shrink-0"></i>
              <span class="font-medium text-slate-800">${escapeHtml(c.campus_zone)}</span>
              <span class="mx-1 text-slate-300">&bull;</span>
              <span class="truncate">${escapeHtml(c.building_room)}</span>
            </div>
            ${c.notes ? `
              <div class="text-[11px] text-slate-500 italic line-clamp-2 pl-5">
                "${escapeHtml(c.notes)}"
              </div>
            ` : ''}
          </div>
        </div>

        <div class="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span class="text-slate-400">
            Verified: <span class="font-medium text-slate-600">${c.last_verified_date}</span>
          </span>
          <div class="flex items-center space-x-1">
            <button onclick="openEditModal('${c.contact_id}')" class="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded" title="Edit">
              <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="deleteContactRecord('${c.contact_id}', '${escapeHtml(c.name)}')" class="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded" title="Delete">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function renderTable() {
  contactsTableBody.innerHTML = currentFiltered.map(c => {
    const prioBadge = getPriorityClass(c.priority_tier);
    const catBadge = getCategoryClass(c.category);

    return `
      <tr class="hover:bg-slate-50 transition">
        <td class="py-2.5 px-4 font-mono font-medium text-slate-500">${c.contact_id}</td>
        <td class="py-2.5 px-4">
          <div class="font-bold text-slate-900">${escapeHtml(c.name)}</div>
          <div class="text-[11px] text-slate-500">${escapeHtml(c.building_room)}</div>
        </td>
        <td class="py-2.5 px-4">
          <span class="text-[10px] font-semibold px-2 py-0.5 rounded ${catBadge}">${escapeHtml(c.category)}</span>
        </td>
        <td class="py-2.5 px-4 font-semibold text-slate-800">
          <div class="flex items-center space-x-1.5">
            <a href="tel:${c.primary_phone.replace(/[^0-9+]/g, '')}" class="text-red-600 hover:underline flex items-center">
              <i data-lucide="phone-call" class="w-3 h-3 mr-1"></i>
              ${escapeHtml(c.primary_phone)}
            </a>
            <button onclick="copyToClipboard('${c.primary_phone}')" class="text-slate-400 hover:text-slate-600">
              <i data-lucide="copy" class="w-3 h-3"></i>
            </button>
          </div>
        </td>
        <td class="py-2.5 px-4 text-slate-600">${escapeHtml(c.campus_zone)}</td>
        <td class="py-2.5 px-4">
          ${c.is_24_7 ? '<span class="text-emerald-600 font-bold">YES</span>' : '<span class="text-slate-400">No</span>'}
        </td>
        <td class="py-2.5 px-4">
          <span class="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${prioBadge}">${escapeHtml(c.priority_tier)}</span>
        </td>
        <td class="py-2.5 px-4 text-slate-500">${c.last_verified_date}</td>
        <td class="py-2.5 px-4 text-right space-x-1">
          <button onclick="openEditModal('${c.contact_id}')" class="p-1 text-slate-400 hover:text-blue-600">
            <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
          </button>
          <button onclick="deleteContactRecord('${c.contact_id}', '${escapeHtml(c.name)}')" class="p-1 text-slate-400 hover:text-red-600">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

// ==========================================
// FORM HANDLING (ADD / EDIT)
// ==========================================
function openAddModal() {
  contactForm.reset();
  formContactId.value = '';
  modalTitle.textContent = 'Record Emergency Contact';
  formVerifiedDate.value = new Date().toISOString().split('T')[0];
  formErrorMessage.classList.add('hidden');
  contactModal.classList.remove('hidden');
  formName.focus();
}

window.openEditModal = function(contactId) {
  const contact = allContacts.find(c => c.contact_id === contactId);
  if (!contact) return;

  formContactId.value = contact.contact_id;
  formName.value = contact.name;
  formCategory.value = contact.category;
  formPriority.value = contact.priority_tier;
  formPrimaryPhone.value = contact.primary_phone;
  formSecondaryPhone.value = contact.secondary_phone || '';
  formEmail.value = contact.email || '';
  formZone.value = contact.campus_zone;
  formRoom.value = contact.building_room;
  formIs247.checked = contact.is_24_7;
  formVerifiedDate.value = contact.last_verified_date;
  formNotes.value = contact.notes || '';

  modalTitle.textContent = `Update Contact [${contact.contact_id}]`;
  formErrorMessage.classList.add('hidden');
  contactModal.classList.remove('hidden');
  formName.focus();
};

function closeContactModal() {
  contactModal.classList.add('hidden');
}

contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  formErrorMessage.classList.add('hidden');

  const isEdit = !!formContactId.value;
  const payload = {
    name: formName.value.trim(),
    category: formCategory.value,
    priority_tier: formPriority.value,
    primary_phone: formPrimaryPhone.value.trim(),
    secondary_phone: formSecondaryPhone.value.trim(),
    email: formEmail.value.trim(),
    campus_zone: formZone.value,
    building_room: formRoom.value.trim(),
    is_24_7: formIs247.checked,
    last_verified_date: formVerifiedDate.value,
    notes: formNotes.value.trim()
  };

  if (payload.name.length < 2) {
    showFormError('Name must be at least 2 characters.');
    return;
  }
  if (!payload.primary_phone) {
    showFormError('Primary phone is mandatory.');
    return;
  }

  btnSaveContact.disabled = true;
  btnSaveContact.textContent = 'Saving...';

  // 1. Try Python REST API backend if connected
  if (isBackendConnected) {
    try {
      const url = isEdit ? `/api/contacts/${formContactId.value}` : '/api/contacts';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const text = await res.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; } catch(pe) {}

      if (res.ok) {
        showToast(isEdit ? 'Contact updated successfully!' : 'Emergency contact recorded!', 'success');
        closeContactModal();
        const fresh = await fetch('/api/contacts');
        allContacts = await fresh.json();
        await fetchMetrics();
        applyFilters();
        btnSaveContact.disabled = false;
        btnSaveContact.textContent = 'Save Contact';
        return;
      } else if (res.status !== 405 && res.status !== 404) {
        showFormError(data.error || `Server error (${res.status})`);
        btnSaveContact.disabled = false;
        btnSaveContact.textContent = 'Save Contact';
        return;
      }
    } catch (err) {
      // Backend request failed, fall through to local save
    }
  }

  // 2. Local fallback save (Zero errors even on static servers / LiveServer!)
  if (isEdit) {
    const idx = allContacts.findIndex(c => c.contact_id === formContactId.value);
    if (idx !== -1) {
      allContacts[idx] = { ...allContacts[idx], ...payload };
    }
  } else {
    const existingNums = allContacts.map(c => {
      const m = (c.contact_id || '').match(/CAMP-(\d+)/);
      return m ? parseInt(m[1]) : 0;
    });
    const nextNum = Math.max(...existingNums, 1000) + 1;
    const newContact = {
      contact_id: `CAMP-${nextNum}`,
      ...payload
    };
    allContacts.push(newContact);
  }

  saveToLocalStorage();
  showToast(isEdit ? 'Contact updated (Saved in local storage)!' : 'Contact recorded (Saved in local storage)!', 'success');
  closeContactModal();
  applyFilters();

  btnSaveContact.disabled = false;
  btnSaveContact.textContent = 'Save Contact';
});

function showFormError(msg) {
  formErrorMessage.textContent = msg;
  formErrorMessage.classList.remove('hidden');
}

window.deleteContactRecord = async function(contactId, name) {
  if (!confirm(`Are you sure you want to permanently remove '${name}' (${contactId})?`)) {
    return;
  }

  if (isBackendConnected) {
    try {
      const res = await fetch(`/api/contacts/${contactId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast(`Removed [${contactId}] ${name}`, 'info');
        const fresh = await fetch('/api/contacts');
        allContacts = await fresh.json();
        await fetchMetrics();
        applyFilters();
        return;
      }
    } catch (e) {}
  }

  allContacts = allContacts.filter(c => c.contact_id !== contactId);
  saveToLocalStorage();
  showToast(`Removed [${contactId}] ${name}`, 'info');
  applyFilters();
};

// ==========================================
// BULK CSV IMPORT
// ==========================================
function openImportModal() {
  csvTextarea.value = '';
  importResultBox.classList.add('hidden');
  importModal.classList.remove('hidden');
}

function closeImportModal() {
  importModal.classList.add('hidden');
}

btnLoadSampleCSV.addEventListener('click', () => {
  const sample = `name,category,primary_phone,secondary_phone,email,campus_zone,building_room,is_24_7,priority_tier,last_verified_date,notes
Campus Emergency Escort Van,Security,555-0401,555-0402,escort@campus.edu,Campus-Wide,Fleet Lot B,True,High,2026-11-20,Ingested from transit division
Dorm Hall A Night Warden,Residence/Housing,555-0403,,warden.a@campus.edu,Student Residences,Hall A Lobby,True,High,2026-11-18,On-duty overnight warden
Chemical Waste Spills Team,Fire & Safety,555-0404,555-0405,chemwaste@campus.edu,Science Complex,Lab Annex 101,True,SOS/Critical,2026-11-10,Rapid neutralizer unit
South Quad AED Station,Medical,555-0406,,aed.south@campus.edu,South Campus,Quad Pavilion,True,High,2026-11-12,Automated external defibrillator team
Student Financial Emergency Aid,Administration,555-0407,,bursar.aid@campus.edu,Central Quad,Admin Bldg Rm 20,False,Standard,2026-10-15,Emergency loan officer
,Security,555-0408,,badrow@campus.edu,North Campus,Rm 1,False,Standard,2026-10-10,Test edge case: Missing name (will trigger error log)
Corrupt Phone Contact,Medical,INVALID_PHONE,,clinic@campus.edu,North Campus,Rm 2,False,High,2026-10-10,Test edge case: Invalid phone format (will trigger error log)`;
  csvTextarea.value = sample;
});

csvFileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (evt) => {
    csvTextarea.value = evt.target.result;
  };
  reader.readAsText(file);
});

btnExecuteImport.addEventListener('click', async () => {
  const content = csvTextarea.value.trim();
  if (!content) {
    showToast('Please upload or paste CSV content first.', 'error');
    return;
  }

  btnExecuteImport.disabled = true;
  btnExecuteImport.textContent = 'Ingesting & Validating...';

  if (isBackendConnected) {
    try {
      const res = await fetch('/api/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csv_content: content })
      });
      if (res.ok) {
        const data = await res.json();
        handleImportResult(data);
        const fresh = await fetch('/api/contacts');
        allContacts = await fresh.json();
        await fetchMetrics();
        applyFilters();
        btnExecuteImport.disabled = false;
        btnExecuteImport.textContent = 'Process & Ingest Dataset';
        return;
      }
    } catch(e) {}
  }

  const lines = content.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length < 2) {
    showToast('CSV must contain a header and at least one data row.', 'error');
    btnExecuteImport.disabled = false;
    btnExecuteImport.textContent = 'Process & Ingest Dataset';
    return;
  }

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const nameIdx = headers.indexOf('name');
  const catIdx = headers.indexOf('category');
  const phoneIdx = headers.indexOf('primary_phone');

  if (nameIdx === -1 || phoneIdx === -1) {
    showToast('CSV missing required headers: name, primary_phone', 'error');
    btnExecuteImport.disabled = false;
    btnExecuteImport.textContent = 'Process & Ingest Dataset';
    return;
  }

  let imported = 0;
  const errors = [];
  const existingNums = allContacts.map(c => {
    const m = (c.contact_id || '').match(/CAMP-(\d+)/);
    return m ? parseInt(m[1]) : 0;
  });
  let nextNum = Math.max(...existingNums, 1000) + 1;

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim());
    const name = cols[nameIdx] || '';
    const phone = cols[phoneIdx] || '';
    if (!name) {
      errors.push(`Row ${i + 1}: Missing contact name.`);
      continue;
    }
    if (!phone || phone.includes('INVALID') || phone.length < 3) {
      errors.push(`Row ${i + 1} ('${name}'): Invalid primary phone '${phone}'.`);
      continue;
    }

    const rowObj = {};
    headers.forEach((h, colI) => {
      rowObj[h] = cols[colI] || '';
    });

    allContacts.push({
      contact_id: `CAMP-${nextNum++}`,
      name: name,
      category: rowObj['category'] || 'Security',
      primary_phone: phone,
      secondary_phone: rowObj['secondary_phone'] || '',
      email: rowObj['email'] || '',
      campus_zone: rowObj['campus_zone'] || 'Campus-Wide',
      building_room: rowObj['building_room'] || 'Main Desk',
      is_24_7: ['true', '1', 'yes'].includes((rowObj['is_24_7'] || '').toLowerCase()),
      priority_tier: rowObj['priority_tier'] || 'Standard',
      last_verified_date: rowObj['last_verified_date'] || new Date().toISOString().split('T')[0],
      notes: rowObj['notes'] || 'Imported via CSV'
    });
    imported++;
  }

  saveToLocalStorage();
  handleImportResult({ imported, errors });
  applyFilters();

  btnExecuteImport.disabled = false;
  btnExecuteImport.textContent = 'Process & Ingest Dataset';
});

function handleImportResult(data) {
  let reportHtml = `
    <div class="font-bold text-emerald-700">✓ Ingestion Summary:</div>
    <div>Successfully imported <strong>${data.imported}</strong> valid emergency contact records.</div>
  `;

  if (data.errors && data.errors.length > 0) {
    reportHtml += `
      <div class="mt-2 font-bold text-amber-800">Row-by-Row Format Warnings (${data.errors.length} skipped):</div>
      <ul class="list-disc pl-4 space-y-0.5 text-amber-700">
        ${data.errors.map(err => `<li>${escapeHtml(err)}</li>`).join('')}
      </ul>
    `;
    importResultBox.className = 'p-3 rounded-lg border bg-amber-50 border-amber-200 text-xs space-y-1 max-h-48 overflow-y-auto';
  } else {
    importResultBox.className = 'p-3 rounded-lg border bg-emerald-50 border-emerald-200 text-xs space-y-1';
  }

  importResultBox.innerHTML = reportHtml;
  importResultBox.classList.remove('hidden');
  showToast(`Bulk imported ${data.imported} records!`, 'success');
}

// ==========================================
// EXPORTS ENGINE (Works Online & Offline!)
// ==========================================
window.downloadExport = function(fmt) {
  if (isBackendConnected) {
    window.location.href = `/api/export?format=${fmt}`;
    showToast(`Downloading ${fmt.toUpperCase()} report...`, 'info');
    return;
  }

  const dateStr = new Date().toISOString().split('T')[0];
  let content = '';
  let filename = '';
  let mimeType = 'text/plain';

  if (fmt === 'json') {
    content = JSON.stringify(allContacts, null, 2);
    filename = `emergency_contacts_${dateStr}.json`;
    mimeType = 'application/json';
  } else if (fmt === 'csv') {
    const headers = ['contact_id','name','category','primary_phone','secondary_phone','email','campus_zone','building_room','is_24_7','priority_tier','last_verified_date','notes'];
    const rows = allContacts.map(c => headers.map(h => `"${(c[h] || '').toString().replace(/"/g, '""')}"`).join(','));
    content = [headers.join(','), ...rows].join('\n');
    filename = `emergency_contacts_${dateStr}.csv`;
    mimeType = 'text/csv';
  } else if (fmt === 'md') {
    content = `# CampusSolve: Emergency Contact Organizer - Executive Summary\nGenerated: ${dateStr}\n\n## Directory\n` +
      allContacts.map(c => `- **${c.name}** (${c.category}) | ${c.primary_phone} | Zone: ${c.campus_zone} | Priority: ${c.priority_tier}`).join('\n');
    filename = `CampusSolve_Report_${dateStr}.md`;
    mimeType = 'text/markdown';
  } else if (fmt === 'txt') {
    content = `CAMPUSSOLVE AUDIT LOG - ${dateStr}\nTotal Contacts: ${allContacts.length}\n\n` +
      allContacts.map(c => `[${c.contact_id}] ${c.name} | ${c.primary_phone} | Verified: ${c.last_verified_date}`).join('\n');
    filename = `audit_log_${dateStr}.txt`;
    mimeType = 'text/plain';
  }

  const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  showToast(`Downloaded ${filename}`, 'success');
};

// ==========================================
// UTILITIES & EVENT LISTENERS
// ==========================================
function setupEventListeners() {
  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (categoryFilter) categoryFilter.addEventListener('change', applyFilters);
  if (zoneFilter) zoneFilter.addEventListener('change', applyFilters);
  if (priorityFilter) priorityFilter.addEventListener('change', applyFilters);
  if (only247Toggle) only247Toggle.addEventListener('change', applyFilters);

  if (btnViewGrid) {
    btnViewGrid.addEventListener('click', () => {
      currentView = 'grid';
      btnViewGrid.className = 'px-2.5 py-1 rounded text-xs font-semibold bg-white text-slate-800 shadow-sm flex items-center space-x-1 transition';
      btnViewTable.className = 'px-2.5 py-1 rounded text-xs font-medium text-slate-600 hover:text-slate-800 flex items-center space-x-1 transition';
      renderContacts();
    });
  }

  if (btnViewTable) {
    btnViewTable.addEventListener('click', () => {
      currentView = 'table';
      btnViewTable.className = 'px-2.5 py-1 rounded text-xs font-semibold bg-white text-slate-800 shadow-sm flex items-center space-x-1 transition';
      btnViewGrid.className = 'px-2.5 py-1 rounded text-xs font-medium text-slate-600 hover:text-slate-800 flex items-center space-x-1 transition';
      renderContacts();
    });
  }

  if (btnOpenAddModal) btnOpenAddModal.addEventListener('click', openAddModal);
  if (btnCloseContactModal) btnCloseContactModal.addEventListener('click', closeContactModal);
  if (btnCancelContactForm) btnCancelContactForm.addEventListener('click', closeContactModal);

  if (btnOpenImportModal) btnOpenImportModal.addEventListener('click', openImportModal);
  if (btnCloseImportModal) btnCloseImportModal.addEventListener('click', closeImportModal);
  if (btnCancelImport) btnCancelImport.addEventListener('click', closeImportModal);

  if (btnDismissWarnings) {
    btnDismissWarnings.addEventListener('click', () => {
      if (warningBannerSection) warningBannerSection.classList.add('hidden');
    });
  }

  if (btnExportMenu) {
    btnExportMenu.addEventListener('click', (e) => {
      e.stopPropagation();
      if (exportDropdownMenu) exportDropdownMenu.classList.toggle('hidden');
    });
  }

  document.addEventListener('click', () => {
    if (exportDropdownMenu) exportDropdownMenu.classList.add('hidden');
  });
}

window.copyToClipboard = function(text) {
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    showToast(`Copied "${text}" to clipboard`, 'info');
  }).catch(() => {
    showToast('Failed to copy to clipboard', 'error');
  });
};

function showToast(message, type = 'info') {
  if (!toastContainer) return;
  const toast = document.createElement('div');
  const bg = type === 'success' ? 'bg-emerald-600' : type === 'error' ? 'bg-red-600' : 'bg-slate-900';
  toast.className = `toast text-white text-xs px-3.5 py-2.5 rounded-xl shadow-lg pointer-events-auto flex items-center space-x-2 ${bg}`;
  toast.innerHTML = `<span>${escapeHtml(message)}</span>`;
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
