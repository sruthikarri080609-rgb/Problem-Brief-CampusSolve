import runpy
from pathlib import Path

# Main entrypoint alias for Streamlit Cloud (streamlit.io)
app_path = Path(__file__).resolve().parent / "streamlit_app.py"
runpy.run_path(str(app_path), run_name="__main__")
