"""
CampusSolve - Streamlit Web Application
Project #71: Emergency Contact Organizer | Domain: Safety & Community

Modern interactive web dashboard designed for local execution (`streamlit run streamlit_app.py`)
and seamless cloud deployment on Streamlit Community Cloud (streamlit.io).
"""

import sys
import os
import json
import io
import pandas as pd
from pathlib import Path
from datetime import date, datetime
import streamlit as st

# Configure page metadata
st.set_page_config(
    page_title="CampusSolve - Emergency Contact Organizer",
    page_icon="🚨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from emergency_organizer import (
    PersistenceEngine,
    ContactManager,
    EmergencyContact,
    InputValidator,
    VALID_CATEGORIES,
    VALID_PRIORITIES,
    VALID_CAMPUS_ZONES,
    generate_sample_dataset
)

# Custom CSS for polished styling
st.markdown("""
<style>
    /* Metric Cards */
    div[data-testid="stMetricValue"] {
        font-size: 1.8rem;
        font-weight: 700;
        color: #DC2626;
    }
    
    /* SOS Speed Dial Card */
    .sos-card {
        background: linear-gradient(135deg, #FFF1F2 0%, #FFE4E6 100%);
        border: 1px solid #FECDD3;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 12px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .sos-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(220, 38, 38, 0.15);
    }
    
    /* Badges */
    .badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 4px;
    }
    .badge-sos { background-color: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
    .badge-high { background-color: #FFEDD5; color: #9A3412; border: 1px solid #FDBA74; }
    .badge-medium { background-color: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
    .badge-standard { background-color: #F1F5F9; color: #475569; border: 1px solid #CBD5E1; }
    .badge-247 { background-color: #DCFCE7; color: #166534; border: 1px solid #86EFAC; }
    
    /* Warning Cards */
    .warning-critical {
        background-color: #FEF2F2;
        border-left: 5px solid #EF4444;
        padding: 12px 16px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 10px;
    }
    .warning-high {
        background-color: #FFF7ED;
        border-left: 5px solid #F97316;
        padding: 12px 16px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 10px;
    }
    .warning-medium {
        background-color: #FEFCE8;
        border-left: 5px solid #EAB308;
        padding: 12px 16px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 10px;
    }
</style>
""", unsafe_allow_html=True)

# ==========================================
# STATE INITIALIZATION
# ==========================================
@st.cache_resource
def get_persistence():
    data_dir = BASE_DIR / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return PersistenceEngine(
        data_dir=data_dir,
        json_file=data_dir / "emergency_contacts.json",
        csv_file=data_dir / "emergency_contacts.csv"
    )

persistence = get_persistence()

def initialize_manager():
    mgr = ContactManager(persistence)
    if not mgr.contacts:
        sample_contacts = generate_sample_dataset()
        persistence.save_contacts(sample_contacts)
        mgr = ContactManager(persistence)
    return mgr

if "manager" not in st.session_state:
    st.session_state.manager = initialize_manager()

def reload_manager():
    st.session_state.manager = ContactManager(persistence)

manager = st.session_state.manager

# Helper for priority color formatting
def priority_badge_html(tier: str) -> str:
    css_class = {
        "SOS/Critical": "badge-sos",
        "High": "badge-high",
        "Medium": "badge-medium",
        "Standard": "badge-standard"
    }.get(tier, "badge-standard")
    return f'<span class="badge {css_class}">{tier}</span>'

def is_247_badge_html(is_24_7: bool) -> str:
    if is_24_7:
        return '<span class="badge badge-247">⚡ 24/7 Active</span>'
    return '<span class="badge badge-standard">Business Hours</span>'

# ==========================================
# SIDEBAR NAVIGATION & SYSTEM INFO
# ==========================================
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/shield.png", width=64)
    st.title("CampusSolve")
    st.caption("🛡️ Emergency Contact Organizer\n*Project #71 | Safety & Community*")
    st.markdown("---")

    menu_option = st.radio(
        "Navigation",
        [
            "🚨 SOS Speed-Dial",
            "📋 Contact Directory",
            "➕ Record New Contact",
            "✏️ Edit / Manage Records",
            "📊 Analytics & Audit",
            "⚠️ Threshold Warnings",
            "📁 Import & Export",
            "⚙️ System & Settings"
        ],
        index=0
    )

    st.markdown("---")
    
    # Quick Metrics in Sidebar
    total_count = len(manager.contacts)
    count_247 = sum(1 for c in manager.contacts if c.is_24_7)
    sos_count = sum(1 for c in manager.contacts if c.priority_tier == "SOS/Critical")
    active_warnings = len(manager.check_threshold_warnings())
    
    st.markdown("### 📊 Status Overview")
    col_sb1, col_sb2 = st.columns(2)
    col_sb1.metric("Total", total_count)
    col_sb2.metric("24/7 Active", count_247)
    
    col_sb3, col_sb4 = st.columns(2)
    col_sb3.metric("Critical SOS", sos_count)
    col_sb4.metric("Warnings", active_warnings, delta=f"-{active_warnings}" if active_warnings > 0 else "0", delta_color="inverse")

    st.markdown("---")
    st.caption("🚀 **Live Streamlit Interface**\nDeployable on [streamlit.io](https://streamlit.io)")

# ==========================================
# VIEW 1: 🚨 SOS EMERGENCY SPEED-DIAL
# ==========================================
if menu_option == "🚨 SOS Speed-Dial":
    st.header("🚨 Emergency Speed-Dial & SOS Hotline")
    st.markdown("Immediate one-click campus emergency contacts with rapid dispatch protocols.")
    
    # Hero Quick-Dispatch Row
    sos_contacts = [c for c in manager.get_all() if c.priority_tier == "SOS/Critical"]
    
    st.subheader("⚡ Critical Priority SOS Roster")
    if not sos_contacts:
        st.info("No contacts marked as SOS/Critical currently.")
    else:
        # Display in 2-column cards
        cols = st.columns(2)
        for idx, contact in enumerate(sos_contacts):
            with cols[idx % 2]:
                with st.container(border=True):
                    h_col1, h_col2 = st.columns([4, 1])
                    h_col1.markdown(f"#### 🚨 {contact.name}")
                    h_col2.markdown('<span class="badge badge-sos">SOS</span>', unsafe_allow_html=True)
                    
                    st.caption(f"**ID:** `{contact.contact_id}` &nbsp;•&nbsp; **Zone:** {contact.campus_zone} &nbsp;•&nbsp; **Room:** {contact.building_room}")
                    
                    phone_html = f'<div style="margin: 6px 0;"><span style="font-size: 1.25rem; font-weight: 700; color: #DC2626;">📞 {contact.primary_phone}</span>'
                    if contact.secondary_phone:
                        phone_html += f'<span style="font-size: 0.85rem; color: #64748B; margin-left: 10px;">Alt: {contact.secondary_phone}</span>'
                    phone_html += '</div>'
                    st.markdown(phone_html, unsafe_allow_html=True)
                    
                    proto = contact.notes or "Immediate rapid dispatch; 24/7 round-the-clock emergency response team."
                    st.info(f"**Protocol:** {proto}", icon="🛡️")
                    
                    call_cols = st.columns(2)
                    clean_phone = contact.primary_phone.replace("-", "").replace(" ", "").replace("+", "")
                    call_cols[0].link_button(f"📞 Call {contact.primary_phone}", f"tel:{clean_phone}", use_container_width=True)
                    if contact.email:
                        call_cols[1].link_button("✉️ Email Dispatch", f"mailto:{contact.email}", use_container_width=True)

    st.markdown("---")
    st.subheader("🛡️ All High-Priority Response Units")
    high_contacts = [c for c in manager.get_all() if c.priority_tier == "High"]
    
    if high_contacts:
        high_df_data = [{
            "ID": c.contact_id,
            "Agency / Contact": c.name,
            "Category": c.category,
            "Primary Phone": c.primary_phone,
            "Zone": c.campus_zone,
            "Location": c.building_room,
            "24/7": "Yes" if c.is_24_7 else "No",
            "Notes": c.notes
        } for c in high_contacts]
        st.dataframe(pd.DataFrame(high_df_data), use_container_width=True, hide_index=True)

# ==========================================
# VIEW 2: 📋 CONTACT DIRECTORY & SEARCH
# ==========================================
elif menu_option == "📋 Contact Directory":
    st.header("📋 Campus Emergency Contact Directory")
    st.markdown("Search, filter, and inspect verified campus safety and emergency contacts.")

    # Search & Filter Controls
    col_search, col_cat, col_zone, col_prio = st.columns([3, 2, 2, 2])
    
    with col_search:
        search_query = st.text_input("🔍 Search keyword", placeholder="Search by name, room, note, phone...").strip()
    with col_cat:
        category_filter = st.selectbox("Category", ["All"] + VALID_CATEGORIES)
    with col_zone:
        zone_filter = st.selectbox("Campus Zone", ["All"] + VALID_CAMPUS_ZONES)
    with col_prio:
        priority_filter = st.selectbox("Priority Tier", ["All"] + VALID_PRIORITIES)
        
    only_247 = st.checkbox("⚡ Show only 24/7 round-the-clock emergency services", value=False)

    # Perform multi-criteria search
    results = manager.search(
        query=search_query,
        category="" if category_filter == "All" else category_filter,
        zone="" if zone_filter == "All" else zone_filter,
        priority="" if priority_filter == "All" else priority_filter,
        only_24_7=only_247
    )

    st.caption(f"Showing **{len(results)}** of **{len(manager.contacts)}** records")

    # View Mode Toggle
    view_mode = st.radio("Display Format", ["📊 Table View", "🗂️ Detailed Cards"], horizontal=True)

    if not results:
        st.warning("No matching contacts found. Try adjusting your search query or filter settings.")
    else:
        if view_mode == "📊 Table View":
            table_data = []
            for c in results:
                table_data.append({
                    "ID": c.contact_id,
                    "Name / Agency": c.name,
                    "Category": c.category,
                    "Priority": c.priority_tier,
                    "Primary Phone": c.primary_phone,
                    "Backup Phone": c.secondary_phone or "-",
                    "Email": c.email or "-",
                    "Campus Zone": c.campus_zone,
                    "Building / Room": c.building_room,
                    "24/7": "⚡ Yes" if c.is_24_7 else "No",
                    "Verified": c.last_verified_date
                })
            df = pd.DataFrame(table_data)
            
            # Interactive Streamlit Dataframe
            st.dataframe(
                df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Priority": st.column_config.TextColumn(
                        "Priority",
                        help="Emergency Priority Classification"
                    ),
                    "Primary Phone": st.column_config.LinkColumn(
                        "Primary Phone",
                        help="Click to initiate call",
                        validate=r"^tel:"
                    ) if False else st.column_config.TextColumn("Primary Phone"),
                }
            )
        else:
            # Cards view
            for c in results:
                with st.expander(f"**{c.contact_id}** — {c.name} ({c.category}) | {c.priority_tier}", expanded=False):
                    c_col1, c_col2, c_col3 = st.columns([2, 2, 2])
                    
                    with c_col1:
                        st.markdown(f"**Primary Phone:** `{c.primary_phone}`")
                        st.markdown(f"**Backup Phone:** `{c.secondary_phone or 'None registered'}`")
                        st.markdown(f"**Official Email:** `{c.email or 'N/A'}`")
                        
                    with c_col2:
                        st.markdown(f"**Campus Zone:** {c.campus_zone}")
                        st.markdown(f"**Building & Room:** {c.building_room}")
                        st.markdown(f"**24/7 Service:** {'⚡ Active 24/7' if c.is_24_7 else 'Standard Hours'}")
                        
                    with c_col3:
                        st.markdown(f"**Priority Tier:** `{c.priority_tier}`")
                        st.markdown(f"**Last Verified:** `{c.last_verified_date}`")
                        st.markdown(f"**Operational Notes:** {c.notes or 'No notes recorded.'}")
                        
                    act_cols = st.columns([1, 1, 4])
                    act_cols[0].link_button("📞 Call", f"tel:{c.primary_phone.replace('-', '').replace(' ', '')}")
                    if c.email:
                        act_cols[1].link_button("✉️ Email", f"mailto:{c.email}")

# ==========================================
# VIEW 3: ➕ RECORD NEW CONTACT
# ==========================================
elif menu_option == "➕ Record New Contact":
    st.header("➕ Record New Emergency Contact")
    st.markdown("Add a validated emergency contact to the official campus safety directory.")

    with st.form("add_contact_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        
        with c1:
            name_input = st.text_input("Contact Name / Agency *", placeholder="e.g. Student Health Urgent Care Desk")
            category_input = st.selectbox("Category *", VALID_CATEGORIES, index=0)
            priority_input = st.selectbox("Priority Tier *", VALID_PRIORITIES, index=1)
            primary_phone_input = st.text_input("Primary Phone *", placeholder="e.g. 555-0155 or 911")
            secondary_phone_input = st.text_input("Secondary / Backup Phone (Optional)", placeholder="e.g. 555-0156")

        with c2:
            email_input = st.text_input("Official Email (Optional)", placeholder="e.g. health@campus.edu")
            zone_input = st.selectbox("Campus Zone *", VALID_CAMPUS_ZONES, index=0)
            room_input = st.text_input("Building & Office / Station Room *", placeholder="e.g. Health Pavilion Rm 102")
            is_247_input = st.checkbox("24/7 Round-the-Clock Emergency Active Service", value=False)
            verified_date_input = st.date_input("Last Verification Date *", value=date.today())

        notes_input = st.text_area("Operational Notes & Emergency Protocols", placeholder="e.g. Rapid response team stationed at north gate.")
        
        submit_btn = st.form_submit_button("💾 Save Emergency Contact", type="primary", use_container_width=True)

        if submit_btn:
            # Defensive validation
            name_ok, name_msg = InputValidator.validate_name(name_input)
            if not name_ok:
                st.error(f"❌ Name Error: {name_msg}")
            else:
                phone_ok, phone_msg = InputValidator.validate_phone(primary_phone_input)
                if not phone_ok:
                    st.error(f"❌ Primary Phone Error: {phone_msg}")
                else:
                    email_ok, email_msg = InputValidator.validate_email(email_input, optional=True)
                    if not email_ok:
                        st.error(f"❌ Email Error: {email_msg}")
                    else:
                        date_str = verified_date_input.isoformat()
                        date_ok, date_msg = InputValidator.validate_date(date_str)
                        if not date_ok:
                            st.error(f"❌ Date Error: {date_msg}")
                        else:
                            # Generate unique ID
                            new_id = manager.generate_next_id()
                            new_contact = EmergencyContact(
                                contact_id=new_id,
                                name=name_input.strip(),
                                category=category_input,
                                primary_phone=phone_msg,
                                secondary_phone=secondary_phone_input.strip(),
                                email=email_input.strip(),
                                campus_zone=zone_input,
                                building_room=room_input.strip() or "Unassigned",
                                is_24_7=is_247_input,
                                priority_tier=priority_input,
                                last_verified_date=date_str,
                                notes=notes_input.strip()
                            )
                            
                            success, msg = manager.add_contact(new_contact)
                            if success:
                                st.success(f"✅ Success! Contact **{new_contact.name}** recorded under ID **{new_id}** and persisted to disk.")
                                reload_manager()
                            else:
                                st.error(f"❌ Save Failed: {msg}")

# ==========================================
# VIEW 4: ✏️ EDIT & MANAGE RECORDS
# ==========================================
elif menu_option == "✏️ Edit / Manage Records":
    st.header("✏️ Edit or Remove Emergency Contact")
    st.markdown("Update details, re-verify dates, or retire inactive emergency contacts.")

    all_contacts = manager.get_all()
    if not all_contacts:
        st.warning("No contacts available to edit.")
    else:
        contact_options = {f"{c.contact_id} — {c.name} ({c.category})": c.contact_id for c in all_contacts}
        selected_label = st.selectbox("Select Contact to Edit", list(contact_options.keys()))
        selected_id = contact_options[selected_label]
        target = manager.find_by_id(selected_id)

        if target:
            st.markdown(f"Editing **{target.name}** (`{target.contact_id}`)")
            
            with st.form("edit_contact_form"):
                col_e1, col_e2 = st.columns(2)
                
                with col_e1:
                    edit_name = st.text_input("Contact Name / Agency", value=target.name)
                    edit_cat = st.selectbox("Category", VALID_CATEGORIES, index=VALID_CATEGORIES.index(target.category) if target.category in VALID_CATEGORIES else 0)
                    edit_prio = st.selectbox("Priority Tier", VALID_PRIORITIES, index=VALID_PRIORITIES.index(target.priority_tier) if target.priority_tier in VALID_PRIORITIES else 0)
                    edit_phone = st.text_input("Primary Phone", value=target.primary_phone)
                    edit_sec_phone = st.text_input("Secondary Phone", value=target.secondary_phone)

                with col_e2:
                    edit_email = st.text_input("Official Email", value=target.email)
                    edit_zone = st.selectbox("Campus Zone", VALID_CAMPUS_ZONES, index=VALID_CAMPUS_ZONES.index(target.campus_zone) if target.campus_zone in VALID_CAMPUS_ZONES else 0)
                    edit_room = st.text_input("Building & Office / Room", value=target.building_room)
                    edit_247 = st.checkbox("24/7 Active Service", value=target.is_24_7)
                    
                    try:
                        cur_date = datetime.strptime(target.last_verified_date, "%Y-%m-%d").date()
                    except Exception:
                        cur_date = date.today()
                    edit_vdate = st.date_input("Last Verification Date", value=cur_date)

                edit_notes = st.text_area("Operational Notes", value=target.notes)

                col_btn1, col_btn2 = st.columns([1, 1])
                save_edit = col_btn1.form_submit_button("💾 Save Changes", type="primary", use_container_width=True)

                if save_edit:
                    phone_ok, phone_clean = InputValidator.validate_phone(edit_phone)
                    if not phone_ok:
                        st.error(f"❌ Phone Error: {phone_clean}")
                    else:
                        updated_fields = {
                            "name": edit_name.strip(),
                            "category": edit_cat,
                            "priority_tier": edit_prio,
                            "primary_phone": phone_clean,
                            "secondary_phone": edit_sec_phone.strip(),
                            "email": edit_email.strip(),
                            "campus_zone": edit_zone,
                            "building_room": edit_room.strip(),
                            "is_24_7": edit_247,
                            "last_verified_date": edit_vdate.isoformat(),
                            "notes": edit_notes.strip()
                        }
                        ok, msg = manager.update_contact(target.contact_id, updated_fields)
                        if ok:
                            st.success(f"✅ Contact `{target.contact_id}` successfully updated and saved!")
                            reload_manager()
                        else:
                            st.error(f"❌ Update failed: {msg}")

            # Danger Zone: Deletion
            st.markdown("---")
            with st.expander("🗑️ Danger Zone: Permanently Delete Contact"):
                st.warning(f"Are you sure you want to permanently delete **{target.name}** ({target.contact_id})?")
                confirm_delete = st.checkbox(f"Yes, permanently delete {target.contact_id}")
                if st.button("Delete Contact Permanently", type="secondary", disabled=not confirm_delete):
                    ok, msg = manager.delete_contact(target.contact_id)
                    if ok:
                        st.success(f"🗑️ {msg}")
                        reload_manager()
                        st.rerun()
                    else:
                        st.error(f"❌ Deletion failed: {msg}")

# ==========================================
# VIEW 5: 📊 ANALYTICS & AUDIT
# ==========================================
elif menu_option == "📊 Analytics & Audit":
    st.header("📊 Executive Analytics & Safety Compliance Audit")
    st.markdown("High-level metrics, round-the-clock coverage, and institutional distribution insights.")

    metrics = manager.generate_summary_metrics()

    # Top KPI row
    m_col1, m_col2, m_col3, m_col4 = st.columns(4)
    m_col1.metric("Total Contacts", metrics["total_contacts"])
    m_col2.metric("24/7 Coverage", f"{metrics['pct_24_7']}%", f"{metrics['count_24_7']} active services")
    m_col3.metric("Verified Current", metrics["audit_status"]["verified_current"])
    m_col4.metric("Audits Overdue", metrics["audit_status"]["critical_overdue"] + metrics["audit_status"]["needs_review"])

    st.markdown("---")

    # Interactive charts row
    c_chart1, c_chart2 = st.columns(2)
    
    with c_chart1:
        st.subheader("Distribution by Category")
        cat_data = metrics["category_breakdown"]
        if cat_data:
            df_cat = pd.DataFrame(list(cat_data.items()), columns=["Category", "Count"]).set_index("Category")
            st.bar_chart(df_cat, color="#DC2626")
        else:
            st.info("No category data available.")

    with c_chart2:
        st.subheader("Distribution by Priority Tier")
        prio_data = metrics["priority_breakdown"]
        if prio_data:
            df_prio = pd.DataFrame(list(prio_data.items()), columns=["Priority", "Count"]).set_index("Priority")
            st.bar_chart(df_prio, color="#F97316")
        else:
            st.info("No priority data available.")

    st.markdown("---")
    
    c_chart3, c_chart4 = st.columns(2)
    with c_chart3:
        st.subheader("Coverage by Campus Zone")
        zone_data = metrics["zone_breakdown"]
        if zone_data:
            df_zone = pd.DataFrame(list(zone_data.items()), columns=["Zone", "Count"]).set_index("Zone")
            st.bar_chart(df_zone, color="#2563EB")
        else:
            st.info("No zone data available.")

    with c_chart4:
        st.subheader("Audit Health Compliance")
        audit_data = {
            "Verified Current (<90d)": metrics["audit_status"]["verified_current"],
            "Needs Review (>180d)": metrics["audit_status"]["needs_review"],
            "Critical Overdue (SOS >90d)": metrics["audit_status"]["critical_overdue"]
        }
        df_audit = pd.DataFrame(list(audit_data.items()), columns=["Status", "Contacts"]).set_index("Status")
        st.bar_chart(df_audit, color="#10B981")

# ==========================================
# VIEW 6: ⚠️ THRESHOLD WARNINGS
# ==========================================
elif menu_option == "⚠️ Threshold Warnings":
    st.header("⚠️ Automated Safety Threshold & Compliance Warnings")
    st.markdown("The system monitors compliance deadlines, missing emergency fallbacks, and physical location gaps.")

    warnings = manager.check_threshold_warnings()

    if not warnings:
        st.success("🎉 **Zero Active Warnings!** All campus emergency contacts meet safety compliance standards and verification intervals.")
    else:
        st.warning(f"⚠️ **{len(warnings)} Active Warning Flags Detected** requiring coordinator review.")

        crit_count = sum(1 for w in warnings if w["severity"] == "CRITICAL")
        high_count = sum(1 for w in warnings if w["severity"] == "HIGH")
        med_count = sum(1 for w in warnings if w["severity"] == "MEDIUM")
        
        col_w1, col_w2, col_w3 = st.columns(3)
        col_w1.metric("Critical Overdue Flags", crit_count)
        col_w2.metric("Missing Backup Phones", high_count)
        col_w3.metric("Location / Info Flags", med_count)

        st.markdown("---")

        for w in warnings:
            sev = w["severity"]
            sev_badge = "badge-sos" if sev == "CRITICAL" else "badge-high" if sev == "HIGH" else "badge-medium"
            
            with st.container(border=True):
                w_col1, w_col2 = st.columns([4, 1])
                w_col1.markdown(f"**{w['name']}** `({w['contact_id']})`")
                w_col2.markdown(f'<span class="badge {sev_badge}">{sev}</span>', unsafe_allow_html=True)
                
                if sev == "CRITICAL":
                    st.error(w['message'], icon="🚨")
                elif sev == "HIGH":
                    st.warning(w['message'], icon="⚠️")
                else:
                    st.info(w['message'], icon="ℹ️")
                    
                st.caption(f"Rule Trigger: `{w['code']}`")

# ==========================================
# VIEW 7: 📁 IMPORT & EXPORT
# ==========================================
elif menu_option == "📁 Import & Export":
    st.header("📁 Data Persistence, Multi-Format Export & Bulk Ingestion")
    st.markdown("Export the official directory for offline safety binders or import legacy CSV rosters.")

    tab_export, tab_import = st.tabs(["📤 Multi-Format Exports", "📥 Bulk CSV Ingestion"])

    with tab_export:
        st.subheader("Generate & Download Official Safety Exports")
        
        all_data = [c.to_dict() for c in manager.get_all()]
        df_export = pd.DataFrame(all_data)
        
        col_ex1, col_ex2 = st.columns(2)
        
        # 1. CSV Export
        with col_ex1:
            st.markdown("#### 📄 Standard CSV Spreadsheet")
            st.caption("Standard comma-separated format compatible with Excel and Google Sheets.")
            csv_buffer = io.StringIO()
            df_export.to_csv(csv_buffer, index=False)
            st.download_button(
                label="⬇️ Download Directory as CSV",
                data=csv_buffer.getvalue(),
                file_name=f"emergency_contacts_{date.today().isoformat()}.csv",
                mime="text/csv",
                use_container_width=True
            )

        # 2. JSON Export
        with col_ex2:
            st.markdown("#### 🗄️ JSON Database Export")
            st.caption("Structured JSON representation with all metadata fields.")
            json_str = json.dumps(all_data, indent=2, ensure_ascii=False)
            st.download_button(
                label="⬇️ Download Database as JSON",
                data=json_str,
                file_name=f"emergency_contacts_{date.today().isoformat()}.json",
                mime="application/json",
                use_container_width=True
            )

        st.markdown("---")
        col_ex3, col_ex4 = st.columns(2)

        # 3. Markdown Executive Report
        with col_ex3:
            st.markdown("#### 📋 Executive Markdown Summary")
            st.caption("Structured report with breakdown tables and audit compliance status.")
            md_path = manager.export_summary_markdown()
            md_content = md_path.read_text(encoding="utf-8") if md_path.exists() else "No report generated"
            st.download_button(
                label="⬇️ Download Markdown Report (.md)",
                data=md_content,
                file_name=md_path.name,
                mime="text/markdown",
                use_container_width=True
            )

        # 4. Text Audit Log
        with col_ex4:
            st.markdown("#### 📜 Text Audit & Inspection Log")
            st.caption("Monospace audit dossier suited for terminal printouts and physical binders.")
            txt_path = manager.export_audit_log()
            txt_content = txt_path.read_text(encoding="utf-8") if txt_path.exists() else "No log generated"
            st.download_button(
                label="⬇️ Download Audit Log (.txt)",
                data=txt_content,
                file_name=txt_path.name,
                mime="text/plain",
                use_container_width=True
            )

    with tab_import:
        st.subheader("Bulk Import Contacts via CSV")
        st.markdown("Upload any CSV file. The system validates phone numbers, emails, and categories row by row.")

        uploaded_file = st.file_uploader("Choose a CSV file to ingest", type=["csv"])

        if uploaded_file is not None:
            try:
                content = uploaded_file.getvalue().decode("utf-8")
                # Save to temporary file for bulk_import_csv
                temp_import_path = BASE_DIR / "temp_streamlit_import.csv"
                temp_import_path.write_text(content, encoding="utf-8")

                import_result = manager.bulk_import_csv(str(temp_import_path))
                if temp_import_path.exists():
                    temp_import_path.unlink()

                st.success(f"✅ Ingestion Complete: **{import_result['added_count']}** contacts added, **{import_result['failed_count']}** rejected.")
                reload_manager()

                if import_result['error_log']:
                    st.warning("⚠️ The following rows contained errors and were skipped:")
                    for err in import_result['error_log']:
                        st.markdown(f"- {err}")

            except Exception as e:
                st.error(f"❌ Failed to process CSV: {str(e)}")

# ==========================================
# VIEW 8: ⚙️ SYSTEM & SETTINGS
# ==========================================
elif menu_option == "⚙️ System & Settings":
    st.header("⚙️ System Configuration & Diagnostics")
    st.markdown("Environment status, storage paths, and recovery utilities.")

    st.subheader("📁 Database & Storage Locations")
    st.code(f"""
Persistence Engine    : JSON & CSV Atomic Synchronizer
JSON Database Path    : {persistence.json_file}
CSV Synchronization   : {persistence.csv_file}
Exports Directory     : {BASE_DIR / 'exports'}
Python Runtime        : {sys.version.split()[0]}
Streamlit Version     : {st.__version__}
    """, language="yaml")

    st.markdown("---")
    st.subheader("🔄 Reset to Default Verified Campus Dataset")
    st.markdown("Restores the official seed dataset of **35 campus safety records** across all 8 emergency categories.")

    confirm_reset = st.checkbox("I understand this will overwrite current changes with the default verified directory.")
    if st.button("♻️ Reset Database to Default Sample Data", disabled=not confirm_reset, type="primary"):
        sample_contacts = generate_sample_dataset()
        persistence.save_contacts(sample_contacts)
        reload_manager()
        st.success("✅ Database has been reset to the default 35 verified campus records!")
        st.rerun()

    st.markdown("---")
    st.subheader("☁️ Deploying on Streamlit Community Cloud (streamlit.io)")
    st.markdown("""
    To host this application for free on **[streamlit.io](https://streamlit.io)**:
    1. Push this folder to a GitHub repository (e.g. `github.com/your-username/campussolve`).
    2. Sign in to [share.streamlit.io](https://share.streamlit.io).
    3. Click **"New app"** and select your repository.
    4. Set Main file path to: `streamlit_app.py` (or `app.py`).
    5. Click **"Deploy!"** — Streamlit Cloud installs `requirements.txt` and runs your app automatically with a public URL!
    """)
