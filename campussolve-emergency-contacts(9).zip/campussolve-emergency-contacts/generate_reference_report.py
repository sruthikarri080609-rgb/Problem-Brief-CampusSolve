"""
Comprehensive Generator for CampusSolve Mini Project Report DOCX
Conforms exactly to the 23-page Malla Reddy Technical Campus Reference Document:
- Page borders on every page (solid black line)
- Page numbering: lower Roman numerals (i, ii, iii) for front matter, decimal (1 to 20) for chapters
- Title page with exact colors: Red Title, Green Subtitle, Blue Degree, Purple 'Submitted by', Red Names, Green College, Magenta University
- Matching table design: Light blue header fill (#D9E1F2), fixed layout, clean padding, strict box containment
- Complete matching text, diagrams, algorithm, flowchart, module descriptions, key code, test cases, and conclusions.
"""

import os
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

PAGE_WIDTH_DXA = 9360  # 6.5 inches at 1440 dxa/inch
OUTPUT_DIR = Path(__file__).resolve().parent

class DocxReportBuilder:
    def __init__(self):
        self.section1_elements = []  # Front matter (Pages i, ii, iii)
        self.section2_elements = []  # Chapters 1-4 (Pages 1-20)
        self.current_section = self.section1_elements

    def switch_to_section2(self):
        self.current_section = self.section2_elements

    def add_p(self, text="", style="Normal", align="left", bold=False, italic=False, size_pt=11, color="000000", space_before_pt=0, space_after_pt=6, line_spacing=1.15, font="Times New Roman"):
        pPr = []
        if align != "left":
            pPr.append(f'<w:jc w:val="{align}"/>')
        
        before_dxa = int(space_before_pt * 20)
        after_dxa = int(space_after_pt * 20)
        line_rule = int(line_spacing * 240)
        pPr.append(f'<w:spacing w:before="{before_dxa}" w:after="{after_dxa}" w:line="{line_rule}" w:lineRule="auto"/>')

        if style:
            pPr.append(f'<w:pStyle w:val="{style}"/>')

        pPr_str = f'<w:pPr>{"".join(pPr)}</w:pPr>' if pPr else ""

        if text:
            rPr = []
            if bold:
                rPr.append('<w:b/>')
            if italic:
                rPr.append('<w:i/>')
            if size_pt:
                rPr.append(f'<w:sz w:val="{int(size_pt * 2)}"/><w:szCs w:val="{int(size_pt * 2)}"/>')
            if color:
                rPr.append(f'<w:color w:val="{color}"/>')
            rPr.append(f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>')
            rPr_str = f'<w:rPr>{"".join(rPr)}</w:rPr>'

            runs = []
            lines = text.split("\n")
            for i, line in enumerate(lines):
                runs.append(f'<w:r>{rPr_str}<w:t xml:space="preserve">{escape(line)}</w:t></w:r>')
                if i < len(lines) - 1:
                    runs.append('<w:r><w:br/></w:r>')

            self.current_section.append(f'<w:p>{pPr_str}{"".join(runs)}</w:p>')
        else:
            self.current_section.append(f'<w:p>{pPr_str}</w:p>')

    def add_page_break(self):
        self.current_section.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')

    def add_table(self, headers, rows, col_widths=None, table_title=None, header_bg="D9E1F2"):
        if table_title:
            self.add_p(table_title, bold=True, size_pt=11, align="center", color="000000", space_before_pt=10, space_after_pt=4)

        num_cols = len(headers)
        if not col_widths:
            equal_w = PAGE_WIDTH_DXA // num_cols
            col_widths = [equal_w] * num_cols
        else:
            total_w = sum(col_widths)
            col_widths = [int((w / total_w) * PAGE_WIDTH_DXA) for w in col_widths]

        tbl = ['<w:tbl>']
        tbl.append('<w:tblPr>')
        tbl.append(f'<w:tblW w:w="{PAGE_WIDTH_DXA}" w:type="dxa"/>')
        tbl.append('<w:jc w:val="center"/>')
        tbl.append('<w:tblLayout w:type="fixed"/>')
        tbl.append('<w:tblBorders>'
                   '<w:top w:val="single" w:sz="6" w:space="0" w:color="000000"/>'
                   '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="000000"/>'
                   '<w:left w:val="single" w:sz="6" w:space="0" w:color="000000"/>'
                   '<w:right w:val="single" w:sz="6" w:space="0" w:color="000000"/>'
                   '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="64748B"/>'
                   '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="64748B"/>'
                   '</w:tblBorders>')
        tbl.append('<w:tblCellMar>'
                   '<w:top w:w="100" w:type="dxa"/>'
                   '<w:bottom w:w="100" w:type="dxa"/>'
                   '<w:left w:w="140" w:type="dxa"/>'
                   '<w:right w:w="140" w:type="dxa"/>'
                   '</w:tblCellMar>')
        tbl.append('</w:tblPr>')

        tbl.append('<w:tblGrid>')
        for w in col_widths:
            tbl.append(f'<w:gridCol w:w="{w}"/>')
        tbl.append('</w:tblGrid>')

        # Header Row
        tbl.append('<w:tr>')
        tbl.append('<w:trPr><w:tblHeader/><w:cantSplit/></w:trPr>')
        for idx, h in enumerate(headers):
            w = col_widths[idx]
            tbl.append(f'<w:tc>'
                       f'<w:tcPr>'
                       f'<w:tcW w:w="{w}" w:type="dxa"/>'
                       f'<w:shd w:val="clear" w:color="auto" w:fill="{header_bg}"/>'
                       f'<w:vAlign w:val="center"/>'
                       f'</w:tcPr>'
                       f'<w:p>'
                       f'<w:pPr><w:jc w:val="left"/><w:spacing w:before="60" w:after="60"/></w:pPr>'
                       f'<w:r>'
                       f'<w:rPr><w:b/><w:sz w:val="21"/><w:szCs w:val="21"/><w:color w:val="000000"/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/></w:rPr>'
                       f'<w:t>{escape(str(h))}</w:t>'
                       f'</w:r>'
                       f'</w:p>'
                       f'</w:tc>')
        tbl.append('</w:tr>')

        # Body Rows
        for r_idx, row in enumerate(rows):
            bg_fill = "FFFFFF"
            tbl.append('<w:tr>')
            tbl.append('<w:trPr><w:cantSplit/></w:trPr>')
            for c_idx, cell_value in enumerate(row):
                w = col_widths[c_idx]
                align = "center" if (c_idx == 0 and len(row) > 2 and len(str(cell_value)) <= 3) or (c_idx == len(row) - 1 and len(row) in (4, 5) and len(str(cell_value)) <= 6) else "left"
                tbl.append(f'<w:tc>'
                           f'<w:tcPr>'
                           f'<w:tcW w:w="{w}" w:type="dxa"/>'
                           f'<w:shd w:val="clear" w:color="auto" w:fill="{bg_fill}"/>'
                           f'<w:vAlign w:val="center"/>'
                           f'</w:tcPr>'
                           f'<w:p>'
                           f'<w:pPr><w:jc w:val="{align}"/><w:spacing w:before="40" w:after="40"/><w:line w:line="240" w:lineRule="auto"/></w:pPr>'
                           f'<w:r>'
                           f'<w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/><w:color w:val="000000"/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/></w:rPr>'
                           f'<w:t>{escape(str(cell_value))}</w:t>'
                           f'</w:r>'
                           f'</w:p>'
                           f'</w:tc>')
            tbl.append('</w:tr>')

        tbl.append('</w:tbl>')
        self.current_section.append("".join(tbl))
        self.add_p("", space_before_pt=0, space_after_pt=6)

    def add_terminal_box(self, title, content_lines, caption=""):
        box_w = PAGE_WIDTH_DXA
        tbl = ['<w:tbl>']
        tbl.append('<w:tblPr>')
        tbl.append(f'<w:tblW w:w="{box_w}" w:type="dxa"/>')
        tbl.append('<w:jc w:val="center"/>')
        tbl.append('<w:tblLayout w:type="fixed"/>')
        tbl.append('<w:tblBorders>'
                   '<w:top w:val="single" w:sz="6" w:space="0" w:color="334155"/>'
                   '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="334155"/>'
                   '<w:left w:val="single" w:sz="6" w:space="0" w:color="334155"/>'
                   '<w:right w:val="single" w:sz="6" w:space="0" w:color="334155"/>'
                   '</w:tblBorders>')
        tbl.append('<w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:left w:w="120" w:type="dxa"/><w:right w:w="120" w:type="dxa"/></w:tblCellMar>')
        tbl.append('</w:tblPr>')
        tbl.append(f'<w:tblGrid><w:gridCol w:w="{box_w}"/></w:tblGrid>')

        # Title bar
        tbl.append('<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc>')
        tbl.append(f'<w:tcPr><w:tcW w:w="{box_w}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1E293B"/></w:tcPr>')
        tbl.append('<w:p><w:pPr><w:spacing w:before="40" w:after="40"/></w:pPr><w:r>')
        tbl.append('<w:rPr><w:sz w:val="18"/><w:color w:val="94A3B8"/><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/></w:rPr>')
        tbl.append(f'<w:t>  ● ● ●  {escape(title)}</w:t></w:r></w:p></w:tc></w:tr>')

        # Terminal body
        tbl.append('<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc>')
        tbl.append(f'<w:tcPr><w:tcW w:w="{box_w}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="0F172A"/></w:tcPr>')
        
        runs = []
        for i, line in enumerate(content_lines):
            line_color = "38BDF8" if line.startswith("Choose:") or line.startswith("Command") else \
                         "EF4444" if line.startswith("!") or "[CRITICAL]" in line else \
                         "22C55E" if "OK" in line or "[OK]" in line else \
                         "F59E0B" if "Careful" in line or "[WARNING]" in line or "Heads up" in line else \
                         "F8FAFC"
            rPr = f'<w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/><w:color w:val="{line_color}"/><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/></w:rPr>'
            runs.append(f'<w:p><w:pPr><w:spacing w:before="10" w:after="10"/><w:line w:line="220" w:lineRule="auto"/></w:pPr><w:r>{rPr}<w:t xml:space="preserve">{escape(line)}</w:t></w:r></w:p>')

        tbl.append("".join(runs))
        tbl.append('</w:tc></w:tr></w:tbl>')
        self.current_section.append("".join(tbl))
        if caption:
            self.add_p(caption, bold=True, size_pt=10, align="center", color="000000", space_before_pt=4, space_after_pt=8)

    def add_diagram_box(self, title, lines, caption=""):
        box_w = PAGE_WIDTH_DXA
        tbl = ['<w:tbl>']
        tbl.append(f'<w:tblPr><w:tblW w:w="{box_w}" w:type="dxa"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/>')
        tbl.append('<w:tblBorders>'
                   '<w:top w:val="single" w:sz="6" w:space="0" w:color="64748B"/>'
                   '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="64748B"/>'
                   '<w:left w:val="single" w:sz="6" w:space="0" w:color="64748B"/>'
                   '<w:right w:val="single" w:sz="6" w:space="0" w:color="64748B"/>'
                   '</w:tblBorders>')
        tbl.append('<w:tblCellMar><w:top w:w="120" w:type="dxa"/><w:bottom w:w="120" w:type="dxa"/><w:left w:w="160" w:type="dxa"/><w:right w:w="160" w:type="dxa"/></w:tblCellMar>')
        tbl.append('</w:tblPr>')
        tbl.append(f'<w:tblGrid><w:gridCol w:w="{box_w}"/></w:tblGrid>')
        tbl.append('<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc>')
        tbl.append(f'<w:tcPr><w:tcW w:w="{box_w}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="F1F5F9"/></w:tcPr>')

        runs = []
        for line in lines:
            rPr = '<w:rPr><w:sz w:val="19"/><w:color w:val="0F172A"/><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/></w:rPr>'
            runs.append(f'<w:p><w:pPr><w:jc w:val="center"/><w:spacing w:before="20" w:after="20"/></w:pPr><w:r>{rPr}<w:t xml:space="preserve">{escape(line)}</w:t></w:r></w:p>')

        tbl.append("".join(runs))
        tbl.append('</w:tc></w:tr></w:tbl>')
        self.current_section.append("".join(tbl))
        if caption:
            self.add_p(caption, bold=True, size_pt=10.5, align="center", color="000000", space_before_pt=4, space_after_pt=8)

    def generate_docx(self, output_path: Path):
        output_path.parent.mkdir(parents=True, exist_ok=True)

        content_types_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\n'
            '  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\n'
            '  <Default Extension="xml" ContentType="application/xml"/>\n'
            '  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>\n'
            '  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>\n'
            '  <Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>\n'
            '  <Override PartName="/word/footer2.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>\n'
            '</Types>'
        )

        pkg_rels_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
            '  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>\n'
            '</Relationships>'
        )

        doc_rels_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
            '  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>\n'
            '  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>\n'
            '  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer2.xml"/>\n'
            '</Relationships>'
        )

        styles_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n'
            '  <w:docDefaults>\n'
            '    <w:rPrDefault>\n'
            '      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>\n'
            '      <w:sz w:val="22"/>\n'
            '      <w:szCs w:val="22"/>\n'
            '      <w:color w:val="000000"/>\n'
            '    </w:rPrDefault>\n'
            '  </w:docDefaults>\n'
            '  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">\n'
            '    <w:name w:val="Normal"/>\n'
            '  </w:style>\n'
            '</w:styles>'
        )

        # Footer 1: Lower Roman page numbering for front matter
        footer1_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n'
            '  <w:p>\n'
            '    <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>\n'
            '    <w:r>\n'
            '      <w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/></w:rPr>\n'
            '      <w:fldSimple w:instr="PAGE"/>\n'
            '    </w:r>\n'
            '  </w:p>\n'
            '</w:ftr>'
        )

        # Footer 2: Decimal (Arabic) page numbering for chapters
        footer2_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n'
            '  <w:p>\n'
            '    <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>\n'
            '    <w:r>\n'
            '      <w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/></w:rPr>\n'
            '      <w:fldSimple w:instr="PAGE"/>\n'
            '    </w:r>\n'
            '  </w:p>\n'
            '</w:ftr>'
        )

        # Page border XML element (Solid black 2.25pt border matching the reference document)
        page_border_xml = (
            '<w:pgBorders w:offsetFrom="page">\n'
            '  <w:top w:val="single" w:sz="18" w:space="24" w:color="000000"/>\n'
            '  <w:left w:val="single" w:sz="18" w:space="24" w:color="000000"/>\n'
            '  <w:bottom w:val="single" w:sz="18" w:space="24" w:color="000000"/>\n'
            '  <w:right w:val="single" w:sz="18" w:space="24" w:color="000000"/>\n'
            '</w:pgBorders>'
        )

        # Section 1 Break: Ends front matter, starts Chapter 1 with decimal numbering
        sec1_pr = (
            '<w:p><w:pPr>\n'
            '  <w:sectPr>\n'
            '    <w:footerReference w:type="default" r:id="rId2" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>\n'
            '    <w:pgSz w:w="12240" w:h="15840"/>\n'
            '    <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720"/>\n'
            f'    {page_border_xml}\n'
            '    <w:pgNumType w:fmt="lowerRoman" w:start="1"/>\n'
            '  </w:sectPr>\n'
            '</w:pPr></w:p>'
        )

        # Section 2 Properties: Covers Chapters 1 to 4 with decimal 1 to 20
        sec2_pr = (
            '  <w:sectPr>\n'
            '    <w:footerReference w:type="default" r:id="rId3" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>\n'
            '    <w:pgSz w:w="12240" w:h="15840"/>\n'
            '    <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720"/>\n'
            f'    {page_border_xml}\n'
            '    <w:pgNumType w:fmt="decimal" w:start="1"/>\n'
            '  </w:sectPr>'
        )

        sec1_body = "".join(self.section1_elements)
        sec2_body = "".join(self.section2_elements)

        document_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n'
            f'  <w:body>\n{sec1_body}\n{sec1_pr}\n{sec2_body}\n{sec2_pr}\n  </w:body>\n'
            '</w:document>'
        )

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as docx:
            docx.writestr("[Content_Types].xml", content_types_xml)
            docx.writestr("_rels/.rels", pkg_rels_xml)
            docx.writestr("word/_rels/document.xml.rels", doc_rels_xml)
            docx.writestr("word/styles.xml", styles_xml)
            docx.writestr("word/footer1.xml", footer1_xml)
            docx.writestr("word/footer2.xml", footer2_xml)
            docx.writestr("word/document.xml", document_xml)

        print(f"[OK] Generated Word Document: {output_path} ({output_path.stat().st_size} bytes)")


def generate_campussolve_word_report():
    builder = DocxReportBuilder()

    # ==========================================
    # PAGE 1 (Page i): TITLE PAGE
    # Matches the exact color, text and styling of the reference PDF
    # ==========================================
    builder.add_p("CAMPUSSOLVE: EMERGENCY CONTACT ORGANIZER", bold=True, size_pt=20, align="center", color="C00000", space_before_pt=40, space_after_pt=14)
    builder.add_p("Mini Project Report", bold=True, italic=True, size_pt=16, align="center", color="008000", space_before_pt=0, space_after_pt=24)
    
    builder.add_p("BACHELOR OF TECHNOLOGY", bold=True, size_pt=13, align="center", color="002060", space_before_pt=6, space_after_pt=2)
    builder.add_p("In", bold=True, size_pt=11, align="center", color="002060", space_before_pt=0, space_after_pt=2)
    builder.add_p("COMPUTER SCIENCE AND ENGINEERING", bold=True, size_pt=13, align="center", color="002060", space_before_pt=0, space_after_pt=24)
    
    builder.add_p("Submitted by", bold=True, italic=True, size_pt=12, align="center", color="4A148C", space_before_pt=0, space_after_pt=12)
    
    # Students List (Styled exactly as two aligned columns in reference)
    builder.add_p("PALEPALLY SANDEEP GOUD                26MVCSER0203", bold=True, size_pt=12, align="center", color="C00000", space_before_pt=2, space_after_pt=4)
    builder.add_p("MANDHAPELLI VISHLESH                    26MVCSER0196", bold=True, size_pt=12, align="center", color="C00000", space_before_pt=2, space_after_pt=4)
    builder.add_p("PEDESETTI KARAN CHARY                 26MVCSER0210", bold=True, size_pt=12, align="center", color="C00000", space_before_pt=2, space_after_pt=28)

    # University emblem text representation / college branding
    builder.add_p("[ MALLA REDDY VISHWAVIDYAPEETH & MRTC CAMPUS LOGOS ]", italic=True, size_pt=9.5, align="center", color="64748B", space_before_pt=0, space_after_pt=20)

    # Institution details
    builder.add_p("MALLA REDDY TECHNICAL CAMPUS", bold=True, size_pt=14, align="center", color="006400", space_before_pt=0, space_after_pt=2)
    builder.add_p("A Constituent Unit of", size_pt=11, align="center", color="000000", space_before_pt=0, space_after_pt=2)
    builder.add_p("MALLA REDDY VISHWAVIDYAPEETH", bold=True, size_pt=13, align="center", color="FF00FF", space_before_pt=0, space_after_pt=2)
    builder.add_p("(Deemed to be University)", bold=True, italic=True, size_pt=11, align="center", color="002060", space_before_pt=0, space_after_pt=2)
    builder.add_p("Approved by UGC & AICTE- New Delhi", bold=True, italic=True, size_pt=11, align="center", color="002060", space_before_pt=0, space_after_pt=2)
    builder.add_p("Maisammaguda, Medchal (Dist), Hyderabad -500100, Telangana", bold=True, italic=True, size_pt=10.5, align="center", color="002060", space_before_pt=0, space_after_pt=16)
    builder.add_p("NOVEMBER-2026", bold=True, size_pt=11, align="center", color="002060", space_before_pt=4, space_after_pt=0)

    builder.add_page_break()

    # ==========================================
    # PAGE 2 (Page ii): ABSTRACT
    # ==========================================
    builder.add_p("ABSTRACT", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=14)
    builder.add_p(
        "In academic and everyday environments, stakeholders frequently experience friction when attempting to store "
        "trusted emergency contacts locally and search them quickly manually or with fragmented tools. Without an integrated, "
        "automated utility, records are susceptible to calculation errors, misplaced entries, and delayed status insights during critical "
        "incidents. Existing software solutions are often enterprise-grade, requiring steep learning curves, expensive licenses, or intrusive "
        "network setups unsuited for rapid local workflows. The CampusSolve Emergency Contact Organizer is a menu-driven terminal and "
        "interactive web application, written in Python 3.10+, that records trusted campus emergency contacts locally and searches them quickly, "
        "incorporating strict defensive input validation, reliable local file persistence (CSV/JSON), and clear summary reporting.",
        align="both", space_after_pt=10
    )
    builder.add_p(
        "The program is divided into modular components for defensive validation, JSON and CSV persistence, core business logic, query filtering, "
        "executive summary metrics, threshold warning indicator flags, and bulk dataset ingestion. A centralized validation layer rejects non-conforming "
        "names, invalid phone numbers, broken email formats, non-existent categories, and invalid or future dates with a clear reason and asks again. "
        "To uphold safety readiness, each record is categorized across emergency priority tiers (SOS/Critical, High, Medium, Standard) and monitored "
        "for compliance; the organizer flags overdue verification deadlines (exceeding 90 days for SOS contacts and 180 days for general contacts) and "
        "highlights critical SOS contacts lacking secondary backup telephone lines. Data is persisted to JSON and synchronized CSV files using atomic "
        "file replacement to guarantee survivability, and a damaged file is backed up instead of crashing the program.",
        align="both", space_after_pt=10
    )
    builder.add_p(
        "Users can query by keyword, category, campus zone and 24/7 round-the-clock availability, import contacts in bulk from CSV with a detailed "
        "row-by-row error log, view aggregated summaries with distribution charts, and export structured Markdown, text audit logs and standardized "
        "CSV reports. On 35 verified campus emergency records spanning 8 domains, the organizer accurately reported 51.4% round-the-clock service "
        "coverage, detected all 6 active threshold compliance warnings, and executed zero-dependency persistence without failures.",
        align="both", space_after_pt=14
    )
    builder.add_p(
        "Keywords: Python, Emergency Contact Organizer, Campus Safety, Input Validation, JSON Storage, "
        "Zero-Dependency Execution, Command-Line Application",
        bold=True, size_pt=10.5, color="000000", space_after_pt=0
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 3 (Page iii): TABLE OF CONTENTS
    # ==========================================
    builder.add_p("TABLE OF CONTENTS", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=20)
    builder.add_p("CHAPTER 1: SOFTWARE REQUIREMENTS ............................................ 1", bold=False, size_pt=11, space_before_pt=4, space_after_pt=12)
    builder.add_p("CHAPTER 2: SYSTEM DESIGN ............................................................... 4", bold=False, size_pt=11, space_before_pt=4, space_after_pt=12)
    builder.add_p("CHAPTER 3: IMPLEMENTATION ............................................................. 9", bold=False, size_pt=11, space_before_pt=4, space_after_pt=12)
    builder.add_p("CHAPTER 4: RESULTS AND CONCLUSION .......................................... 12", bold=False, size_pt=11, space_before_pt=4, space_after_pt=12)

    # SWITCH TO SECTION 2 (Decimal Page Numbering 1 to 20)
    builder.switch_to_section2()

    # ==========================================
    # PAGE 4 (Page 1): CHAPTER 1: SOFTWARE REQUIREMENTS
    # ==========================================
    builder.add_p("CHAPTER 1: SOFTWARE REQUIREMENTS", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=12)
    builder.add_p(
        "This chapter lists the software and hardware needed to build and run the CampusSolve Emergency Contact Organizer. "
        "Anyone who installs the items below can run the project on his or her own computer.",
        align="both", space_after_pt=10
    )
    builder.add_p("1.1 Operating System", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The project was developed with Python 3.10+ / 3.14 on Windows 11 (64-bit) and tested across Ubuntu Linux and macOS. "
        "The code uses only portable standard-library modules (pathlib, os, sys), so it runs natively across major platforms. For coloured "
        "output on Windows the program switches the console to ANSI mode automatically; on any terminal that cannot show colours (or when the "
        "NO_COLOR variable is set) it falls back to plain text.",
        align="both", space_after_pt=10
    )
    builder.add_p("1.2 Programming Language", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Python 3.10 or later was used for development. Python was chosen because its syntax is simple and readable, it has built-in data types "
        "(lists, dictionaries, dataclasses) that suit an organizer of trusted contacts, and its standard library already provides JSON, CSV, date, "
        "and regular-expression support. The zero-dependency standard library design guarantees seamless portability without external runtime issues.",
        align="both", space_after_pt=10
    )
    builder.add_p("1.3 Tools / IDE Used", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Visual Studio Code (or any code editor / IDE such as PyCharm or IDLE) was used to write and run the code. The program itself runs in a terminal "
        "(Command Prompt, PowerShell or a Linux shell). The built-in http.server module powers the companion local web interface, accessible from any "
        "standard browser (Chrome, Edge, Firefox). The unittest framework runs automated validation tests, and Matplotlib was also used where applicable "
        "to draw graphical summaries and charts.",
        align="both", space_after_pt=10
    )
    builder.add_p("1.4 Libraries and Packages", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The project relies entirely on the Python Standard Library for complete zero-dependency execution. Table 1.1 lists every library used.",
        align="both", space_after_pt=8
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 5 (Page 2): Table 1.1
    # ==========================================
    builder.add_p("Table 1.1: Libraries used in the project", bold=True, size_pt=11, align="center", color="000000", space_before_pt=14, space_after_pt=6)
    builder.add_table(
        headers=["Library", "Version", "Purpose"],
        rows=[
            ["json", "Standard library", "Saves and loads the data file emergency_contacts.json (PersistenceEngine) with auto-recovery"],
            ["csv", "Standard library", "Reads legacy CSV files for bulk import, logs errors, and synchronizes the master CSV file"],
            ["re", "Standard library", "Executes defensive regular expression sanitization on phones, emails, and date formats"],
            ["datetime, date", "Standard library", "Calculates audit intervals and days since last verification for threshold warnings"],
            ["dataclasses", "Standard library", "Defines the EmergencyContact record and converts it to a dictionary for JSON saving"],
            ["pathlib, os", "Standard library", "File paths; safe saving by writing a temporary file and replacing the real one (os.replace)"],
            ["http.server", "Standard library", "Powers the zero-dependency REST API backend and serves the interactive web portal"],
            ["urllib.parse", "Standard library", "Parses HTTP query parameters for multi-criteria search (keyword, category, zone, 24/7)"],
            ["sys", "Standard library", "Detects terminal colour capability, manages system paths, and controls session termination"],
            ["collections", "Standard library", "defaultdict groups the totals and counts by category and by campus zone"]
        ],
        col_widths=[1800, 2000, 5560]
    )
    builder.add_p("1.5 Hardware Requirements", bold=True, size_pt=12, color="000000", space_before_pt=10, space_after_pt=4)
    builder.add_p(
        "The application is light-weight: it handles hundreds of contact records in structured local files and needs no network connection. "
        "Table 1.2 gives the minimum specification.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 6 (Page 3): Table 1.2
    # ==========================================
    builder.add_p("Table 1.2: Hardware requirements of the project", bold=True, size_pt=11, align="center", color="000000", space_before_pt=20, space_after_pt=8)
    builder.add_table(
        headers=["Component", "Minimum Requirement"],
        rows=[
            ["Processor", "Intel Core i3 or equivalent (64-bit)"],
            ["RAM", "4 GB"],
            ["Hard disk space", "250 MB free (Python interpreter, project files, and database storage)"],
            ["Display / Other", "Keyboard, mouse and a monitor with a terminal window; no internet needed after setup"]
        ],
        col_widths=[2800, 6560]
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 7 (Page 4): CHAPTER 2: SYSTEM DESIGN
    # ==========================================
    builder.add_p("CHAPTER 2: SYSTEM DESIGN", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=12)
    builder.add_p(
        "This chapter explains the plan of the project before the code: what the system does, its main blocks, the algorithm, "
        "the flowchart and the role of each module.",
        align="both", space_after_pt=10
    )
    builder.add_p("2.1 Overview of the System", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The CampusSolve Emergency Contact Organizer is a software utility that helps campus administrators, students, and safety officers "
        "maintain and quickly query trusted safety contacts. Storing emergency contacts locally removes enterprise network latency, expensive licenses, "
        "and cloud dependency while providing reliable round-the-clock availability during campus emergencies.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "The input is the emergency contact data typed by the user (contact name, category, primary/secondary phone, email, campus zone, building room, "
        "24/7 status, priority tier, and verification date) or a CSV file of contacts. The process is defensive validation of every field, safe saving to a "
        "JSON file, and safety audit logic: priority sorting, 24/7 percentage coverage, detection of overdue audits (SOS >90d, general >180d), missing fallback "
        "phone flags, and category summaries. The output is the formatted directory on the screen, instant search results, an executive summary report, "
        "ASCII charts, an interactive web portal, and Markdown, text and CSV exports.",
        align="both", space_after_pt=10
    )
    builder.add_p("2.2 Block Diagram", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Figure 2.1 shows how data moves through the system. Everything the user or a CSV file supplies passes through the validation block first, "
        "so only clean data reaches the Contact Manager. The audit logic reads the contacts and feeds the screen, the report files, and the web portal; "
        "the Storage block keeps the directory safely saved in emergency_contacts.json.",
        align="both", space_after_pt=8
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 8 (Page 5): Fig 2.1 & 2.3 Algorithm (Steps 1-7)
    # ==========================================
    builder.add_diagram_box(
        "Block Diagram of CampusSolve",
        [
            "User (keyboard input)                CSV file (bulk contacts)",
            "         │                                      │",
            "         ▼                                      ▼",
            "Menu and prompts (ui.py)               CSV importer (importer.py)",
            "         │                                      │",
            "         └──────────────► Input validation ◄────┘",
            "                          (validation.py)",
            "                                │ (valid data only)",
            "                                ▼",
            "    Storage           EmergencyContact & Manager         Audit & Analytics",
            "  (storage.py)   ◄───        (models.py)           ───►     (logic.py)",
            "       │                                                     │",
            "       ▼                                    ┌────────────────┴──────────────┐",
            "emergency_contacts.json                     ▼                               ▼",
            "  (saved data)                       Terminal Screen / Web            Reports & Exports",
            "                                      (tables, SOS cards)             (.md, .txt, .csv)"
        ],
        caption="Fig 2.1: Block diagram of the Emergency Contact Organizer"
    )
    builder.add_p("2.3 Algorithm", bold=True, size_pt=12, color="000000", space_before_pt=10, space_after_pt=4)
    builder.add_p("Step 1: Start.", space_after_pt=2)
    builder.add_p("Step 2: Load the data file. If it is missing, create a new one seeded with 35 realistic campus contacts; if it is unreadable, back it up and start fresh; skip any damaged records.", space_after_pt=2)
    builder.add_p("Step 3: Show the branded banner, active database count, and threshold warning status.", space_after_pt=2)
    builder.add_p("Step 4: Display the menu and read the user's choice. If the choice is 9 (or 0), go to Step 15.", space_after_pt=2)
    builder.add_p("Step 5 (Add contact): Read the name, category, primary phone, secondary phone, email, zone, room, 24/7 status, priority tier and verification date. Validate each field and ask again on error. Assign next ID (CAMP-XXXX), add contact, and save.", space_after_pt=2)
    builder.add_p("Step 6 (View / Search): Filter the contacts by keyword, category, zone, and 24/7 availability, show them in fixed-width tabular format, and allow full dossier inspection.", space_after_pt=2)
    builder.add_p("Step 7 (Update / Remove): Update contact details after validation, or remove a contact by ID after explicit confirmation, then save.", space_after_pt=2)

    builder.add_page_break()

    # ==========================================
    # PAGE 9 (Page 6): 2.3 Algorithm (Steps 8-16) & 2.4 Flowchart Intro
    # ==========================================
    builder.add_p("Step 8 (Audit check): Scan contacts for compliance. Calculate total contacts and 24/7 coverage percentage. Flag SOS contacts unverified in >90 days and general contacts unverified in >180 days.", space_after_pt=2)
    builder.add_p("Step 9: Flag anomalous entries: critical SOS contacts missing secondary fallback phones, and records with incomplete or TBD building locations.", space_after_pt=2)
    builder.add_p("Step 10 (Summary): Show totals, 24/7 availability ratio, distribution across 8 safety categories, priority tier readiness, and ASCII distribution charts.", space_after_pt=2)
    builder.add_p("Step 11 (Reports / Export): Write structured Markdown executive reports, plain-text audit logs, or standardized CSV datasets into the exports folder.", space_after_pt=2)
    builder.add_p("Step 12 (Import CSV): Read each row, validate it, skip duplicates, add valid rows and record every rejected row with its line number in an error log.", space_after_pt=2)
    builder.add_p("Step 13 (Load sample data): Seed the 35 realistic emergency contacts spanning campus security, medical EMT, hazmat, crisis lines, and dorm wardens.", space_after_pt=2)
    builder.add_p("Step 14: Return to Step 4.", space_after_pt=2)
    builder.add_p("Step 15: Save the data file and print a goodbye message.", space_after_pt=2)
    builder.add_p("Step 16: Stop.", space_after_pt=8)
    builder.add_p("2.4 Flowchart", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The flowchart in Figure 2.2 shows the main loop of the program. Every action chosen from the menu validates its input, performs the "
        "calculation or display, and saves the data before the menu is shown again. Only choice 9 (Exit) leaves the loop.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 10 (Page 7): Fig 2.2 & 2.5 Description of Modules
    # ==========================================
    builder.add_diagram_box(
        "Flowchart of CampusSolve Execution Cycle",
        [
            "┌───────────────┐",
            "│     START     │",
            "└───────┬───────┘",
            "        ▼",
            "Load data file (create / repair if missing or damaged)",
            "        │",
            "        ▼",
            "Show banner and active database status",
            "        │",
            "        ▼",
            "┌────────────────────────────────────────────────────────┐◄──────────┐",
            "│          Display menu and read the choice              │           │",
            "└───────────────────────┬────────────────────────────────┘           │",
            "                        │                                            │",
            "                        ▼                                            │",
            "                < Choice = 9 (Exit)? > ───────Yes───► [Save & Stop]  │",
            "                        │ No                                         │",
            "                        ▼                                            │",
            "Run chosen action: add, view, search, update, delete,                │",
            "analytics, reports, CSV import, load sample                          │",
            "                        │                                            │",
            "                        ▼                                            │",
            "Validate every input (reject with reason and ask again)              │",
            "                        │                                            │",
            "                        ▼                                            │",
            "Calculate totals, priority ranking, status flags & show              │",
            "                        │                                            │",
            "                        ▼                                            │",
            "Save changes atomically to JSON and CSV file ────────────────────────┘"
        ],
        caption="Fig 2.2: Flowchart of the Emergency Contact Organizer"
    )
    builder.add_p("2.5 Description of Modules", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The project is split into small modules so that every rule lives in one place and can be tested on its own. "
        "Table 2.1 gives the job of each file.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 11 (Page 8): Table 2.1
    # ==========================================
    builder.add_p("Table 2.1: Modules of the Project", bold=True, size_pt=11, align="center", color="000000", space_before_pt=14, space_after_pt=6)
    builder.add_table(
        headers=["Module", "Responsibility"],
        rows=[
            ["main.py / emergency_organizer.py", "Entry point; starts the menu loop, coordinates components, and handles session termination"],
            ["config.py", "File paths, default categories (8 safety domains), priority tiers (SOS, High, Med, Std), and page size"],
            ["models.py", "EmergencyContact record (id, name, category, phones, email, zone, room, 24/7, priority, verified date, notes) and ContactManager"],
            ["validation.py", "Every input rule in one place: name length, category, phone regex, email pattern, date format, and range checks"],
            ["storage.py", "Saves and loads emergency_contacts.json; saves through a temporary file; backs up a damaged file and starts fresh"],
            ["logic.py", "Contact sorting by priority, multi-criteria search, 24/7 coverage calculation, and threshold warning detection"],
            ["importer.py", "Imports a CSV file row by row, validates syntax, skips duplicates, and logs rejected rows with line numbers"],
            ["reports.py", "Builds the text audit log, structured Markdown executive summary report, and standardized CSV export"],
            ["plotting.py", "Generates summary metrics and ASCII category/priority distribution charts for the terminal report"],
            ["ui.py", "Menu, prompts, colours, fixed-width tables, contact dossier views, and the 9 terminal menu actions"],
            ["web_server.py", "Zero-dependency Python HTTP server providing REST API endpoints (/api/contacts, /api/metrics, /api/export)"],
            ["web/app.js", "Client controller handling live search, instant facet filters, modal validation, and offline browser storage fallback"]
        ],
        col_widths=[3200, 6160]
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 12 (Page 9): CHAPTER 3: IMPLEMENTATION
    # ==========================================
    builder.add_p("CHAPTER 3: IMPLEMENTATION", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=12)
    builder.add_p(
        "This chapter explains how the design was turned into a working program: what happens when the program runs, "
        "the most important code, and the steps to run it.",
        align="both", space_after_pt=10
    )
    builder.add_p("3.1 Working of the Project", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Start-up. main.py calls run() in ui.py. The program loads data/emergency_contacts.json through storage.py, prints the branded banner "
        "and shows how many contacts are loaded along with active threshold warning flags. Then the 9-option menu appears.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "Adding an item (option 3). The user types the contact/department name, category, primary emergency phone, secondary phone, email, "
        "campus zone, building room, 24/7 availability status, priority tier and verification date. Each answer is checked by validation.py; "
        "a wrong value shows a message such as 'Phone number length must be between 3 and 16 digits' and the same question is asked again. "
        "The contact is assigned a unique ID (CAMP-XXXX), stored in the manager, re-evaluates audit health, and atomically saves the file.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "Viewing, searching and removing (options 1, 2, 4, 5). Contacts are shown in a fixed-width table, sorted by priority (SOS first). "
        "Search accepts a keyword, a category, a campus zone and a 24/7 toggle, and displays matching results with full dossier inspection. "
        "Removing a contact asks for its ID and requires an explicit 'YES' confirmation.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "Audit and threshold check (option 6). The threshold monitor identifies compliance breaches: flags SOS contacts unverified in >90 days, "
        "general contacts unverified in >180 days, critical responders lacking a secondary phone line, and incomplete building room assignments.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "Summary, charts and exports (options 6 and 7). The summary report shows total contacts, 24/7 coverage percentage, category distribution "
        "with ASCII bar charts, and itemized warning flags. The export option writes Markdown, text audit logs and master CSV files into the exports folder.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "Importing (option 8). A CSV file is read row by row with the same validation rules. Good rows are added, duplicates are skipped and bad rows "
        "are listed with their line numbers and written to an error log. Ingesting sample_import_test.csv demonstrates error catching on malformed rows.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 13 (Page 10): Working (cont.), 3.2 Key Code & How to Run
    # ==========================================
    builder.add_p(
        "Exit. Option 9 saves the data and ends the program. If an unexpected error occurs during an action, a message is shown and the session "
        "continues, so no data is lost.",
        align="both", space_after_pt=10
    )
    builder.add_p("3.2 Key Code", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Only the two most important parts are shown. The first is the validation of a telephone number in validation.py. It removes delimiters, "
        "rejects non-numeric characters, validates length boundaries or emergency codes, and returns a clean string.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "def clean_phone(raw):\n"
        "    text = str(raw or \"\").strip()\n"
        "    if not text:\n"
        "        raise ValueError(\"phone number can't be blank\")\n"
        "    digits = re.sub(r\"[^\\d+]\", \"\", text)\n"
        "    if text in (\"911\", \"112\", \"100\", \"101\", \"102\", \"988\"):\n"
        "        return text\n"
        "    if len(digits) < 3:\n"
        "        raise ValueError(\"phone number must have at least 3 digits\")\n"
        "    if len(digits) > 16:\n"
        "        raise ValueError(\"phone number can't be longer than 16 digits\")\n"
        "    return text",
        font="Consolas", size_pt=9.5, space_before_pt=2, space_after_pt=8
    )
    builder.add_p(
        "The second is the threshold warning check in logic.py. The status flags records with overdue audit dates or missing backup phone numbers "
        "for immediate safety resolution.",
        align="both", space_after_pt=6
    )
    builder.add_p(
        "def check_threshold_warnings(contacts):\n"
        "    warnings, today = [], date.today()\n"
        "    for c in contacts:\n"
        "        try:\n"
        "            days = (today - datetime.strptime(c.last_verified_date, \"%Y-%m-%d\").date()).days\n"
        "        except ValueError: days = 9999\n"
        "        if c.priority_tier == \"SOS/Critical\" and days > 90:\n"
        "            warnings.append({\"id\": c.contact_id, \"name\": c.name, \"level\": \"CRITICAL\",\n"
        "                             \"msg\": f\"SOS verification overdue ({days}d > limit 90d)\"})\n"
        "        elif days > 180:\n"
        "            warnings.append({\"id\": c.contact_id, \"name\": c.name, \"level\": \"WARNING\",\n"
        "                             \"msg\": f\"Verification stale ({days}d > limit 180d)\"})\n"
        "        if c.priority_tier == \"SOS/Critical\" and not c.secondary_phone:\n"
        "            warnings.append({\"id\": c.contact_id, \"name\": c.name, \"level\": \"HIGH\",\n"
        "                             \"msg\": \"Missing secondary emergency fallback phone\"})\n"
        "    return warnings",
        font="Consolas", size_pt=9.5, space_before_pt=2, space_after_pt=8
    )
    builder.add_p("3.3 How to Run the Program", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p("Step 1: Install Python 3.10 or later from www.python.org and unzip the project folder campussolve-emergency-contacts.", space_after_pt=2)

    builder.add_page_break()

    # ==========================================
    # PAGE 14 (Page 11): 3.3 How to Run (cont. Steps 2-6)
    # ==========================================
    builder.add_p("Step 2: Open a terminal in the project folder. Optionally create a virtual environment: python -m venv .venv, then activate it (Windows: .venv\\Scripts\\activate; Linux/macOS: source .venv/bin/activate).", space_after_pt=4)
    builder.add_p("Step 3: No external pip libraries are required (complete zero-dependency execution).", space_after_pt=4)
    builder.add_p("Step 4: Start the terminal program with: python emergency_organizer.py", space_after_pt=4)
    builder.add_p("Step 5: The database automatically loads the 35 verified campus contacts. Try option 1 (view directory), 2 (search), 3 (add contact with validation), 6 (analytics & warnings), 7 (export reports), and 8 (bulk import).", space_after_pt=4)
    builder.add_p("Step 6: To launch the companion web application, run: python web_server.py --port 8000 and open http://localhost:8000/ in any web browser.", space_after_pt=4)

    builder.add_page_break()

    # ==========================================
    # PAGE 15 (Page 12): CHAPTER 4: RESULTS AND CONCLUSION & Fig 4.1
    # ==========================================
    builder.add_p("CHAPTER 4: RESULTS AND CONCLUSION", bold=True, size_pt=14, align="center", color="000000", space_before_pt=20, space_after_pt=12)
    builder.add_p(
        "This chapter shows the output of the project. All screens were produced by running the program on the sample data supplied with it "
        "(35 verified campus emergency contacts spanning 8 safety domains). The chapter ends with the test cases and the conclusion.",
        align="both", space_after_pt=10
    )
    builder.add_p("4.1 Results (Code and Output Screenshots)", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=6)
    
    # Fig 4.1 Terminal
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "========================================================================",
            "   ____                                   ____        _            ",
            "  / ___|__ _ _ __ ___  _ __  _   _ ___  / ___|  ___ | |_   _____  ",
            " | |   / _` | '_ ` _ \\| '_ \\| | | / __| \\___ \\ / _ \\| \\ \\ / / _ \\ ",
            " | |__| (_| | | | | | | |_) | |_| \\__ \\  ___) | (_) | |\\ V /  __/ ",
            "  \\____\\__,_|_| |_| |_| .__/ \\__,_|___/ |____/ \\___/|_| \\_/ \\___| ",
            "                      |_| Project #71: Emergency Contact Organizer",
            "========================================================================",
            " Active Database: 35 Contacts loaded | [!] 6 Threshold Warnings",
            "",
            " 1) View all emergency contacts",
            " 2) Search / filter contacts",
            " 3) Record new emergency contact",
            " 4) Update existing contact",
            " 5) Remove a contact",
            " 6) Executive summary & analytics",
            " 7) Export reports (md / txt / csv)",
            " 8) Bulk import contacts from CSV",
            " 9) Exit",
            "",
            "Choose: 1",
            "OK Displaying 35 contacts sorted by emergency priority readiness."
        ],
        caption="Fig 4.1: Start-up screen, main menu and loading of the sample data"
    )
    builder.add_p(
        "The program prints the banner and the 9-option menu. On startup, 35 verified campus contacts are loaded with 0 errors, "
        "and 6 active threshold compliance flags are detected.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 16 (Page 13): Fig 4.2
    # ==========================================
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "Choose: 1",
            "",
            "-- Master Campus Emergency Directory (Total: 35) --",
            "-----------------------------------------------------------------------------------------",
            "ID         | Name                     | Category        | Phone           | 24/7 | Priority    ",
            "-----------------------------------------------------------------------------------------",
            "CAMP-1001  | Campus Police 24/7 Disp  | Security        | 555-0100        | YES  | SOS/Critical",
            "CAMP-1002  | Emergency Trauma Center  | Medical         | 555-0111        | YES  | SOS/Critical",
            "CAMP-1003  | Fire & Hazmat Response   | Fire & Safety   | 555-0119        | YES  | SOS/Critical",
            "CAMP-1004  | Crisis & Suicide Lifeline| Mental Health   | 555-0199        | YES  | SOS/Critical",
            "CAMP-1005  | Sexual Assault Support   | Mental Health   | 555-0144        | YES  | SOS/Critical",
            "CAMP-1007  | Residence Warden Desk    | Residence/Hous  | 555-0130        | YES  | High        ",
            "CAMP-1009  | Gas & Electrical Hazard  | Facilities      | 555-0160        | YES  | High        ",
            "CAMP-1010  | Campus SafeWalk Escort   | Security        | 555-0177        | NO   | High        ",
            "CAMP-1015  | IT Cyber Incident Team   | Administration  | 555-0240        | YES  | Medium      ",
            "-----------------------------------------------------------------------------------------",
            "Top-level SOS responders sorted first; round-the-clock emergency channels prioritized."
        ],
        caption="Fig 4.2: Master Emergency Contact Directory table with 24/7 status and priority tiers"
    )
    builder.add_p(
        "Contacts are sorted by priority readiness (SOS/Critical first) with fixed character widths, column separators, and clean pagination. "
        "24/7 round-the-clock availability is prominently indicated.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 17 (Page 14): Fig 4.3 & Fig 4.4
    # ==========================================
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "Choose: 3",
            "",
            "-- Record Emergency Contact --",
            "Contact Name / Dept:",
            "! name can't be blank",
            "Contact Name / Dept: E",
            "! name must be at least 2 characters",
            "Contact Name / Dept: East Quad Security Escort",
            "Category (name or number): hazardous",
            "! unknown category 'hazardous' (pick one of: Security, Medical, Mental Health, Fire & Safety, Residence/Housing, Facilities, Administration, External Emergency)",
            "Category: Security",
            "Primary Phone: abc",
            "! 'abc' is not a valid phone number",
            "Primary Phone: 55",
            "! phone number length must be between 3 and 16 digits",
            "Primary Phone: 555-0450",
            "Verification Date YYYY-MM-DD [2026-11-24]: 2030-01-01",
            "! date is in the future",
            "Verification Date YYYY-MM-DD [2026-11-24]: 24/11/2026",
            "! '24/11/2026' isn't a valid date, use YYYY-MM-DD",
            "Verification Date YYYY-MM-DD [2026-11-24]: 2026-11-24",
            "OK Added #CAMP-1036: East Quad Security Escort = 555-0450",
            "Heads up: Saved atomically to local JSON and CSV persistence."
        ],
        caption="Fig 4.3: Defensive input validation while adding a contact"
    )
    builder.add_p(
        "Wrong inputs are rejected with a reason and the question is repeated: blank name, short name, unknown category, text and truncated phones, "
        "a future date and a wrongly formatted date. The final valid entry is saved as #CAMP-1036.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 18 (Page 15): Fig 4.4 & Fig 4.5
    # ==========================================
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "Choose: 8",
            "Path to CSV file: sample_import_test.csv",
            "OK 5 added, 0 duplicate(s) skipped, 2 row(s) rejected",
            "  row 7: name can't be blank",
            "  row 8: 'INVALID_PHONE' is not a valid phone number",
            "",
            "Reasons recorded to data/import_errors.log"
        ],
        caption="Fig 4.4: Bulk CSV import with rejected rows"
    )
    builder.add_p(
        "The test file has 7 data rows. Five are valid and are added; the other two are rejected with their line numbers, and the reasons "
        "are also written to data/import_errors.log.",
        align="both", space_after_pt=6
    )
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "Choose: 6",
            "",
            "CAMPUSSOLVE EXECUTIVE SUMMARY & AUDIT REPORT - 2026-11",
            "============================================================",
            "Total Registered Contacts : 35",
            "24/7 Active Services      : 18 (51.4%)",
            "Audit Verified & Current  : 29",
            "In Need of Review (>180d) : 5",
            "Critical SOS Overdue      : 1",
            "",
            "Spending by domain category",
            "------------------------------------------------------------",
            "  Administration       8   22.9%   #####",
            "  Security             6   17.1%   ####",
            "  Fire & Safety        5   14.3%   ###",
            "  External Emergency   5   14.3%   ###",
            "  Medical              4   11.4%   ##",
            "  Mental Health        4   11.4%   ##",
            "  Facilities           3    8.6%   ##",
            "",
            "Threshold warning flags (6 detected)",
            "------------------------------------------------------------",
            "  [CRITICAL] CAMP-1005 Campus Sexual Assault Support: SOS audit overdue (162d > 90d)",
            "  [HIGH]     CAMP-1005 Campus Sexual Assault Support: Missing backup phone number",
            "  [WARNING]  CAMP-1012 Radiation Safety Officer: Verification stale (228d > 180d)",
            "  [WARNING]  CAMP-1018 Biological Waste Hotline: Verification stale (255d > 180d)"
        ],
        caption="Fig 4.5: Summary report and threshold warnings for November 2026"
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 19 (Page 16): Fig 4.6 & Fig 4.7
    # ==========================================
    builder.add_terminal_box(
        "Command Prompt - python emergency_organizer.py",
        [
            "Choose: 2",
            "",
            "-- Search Contacts (leave blank to skip) --",
            "Keyword in name/notes: Trauma",
            "Category: Medical",
            "Campus Zone: Central Quad",
            "24/7 Available Only [y/N]: y",
            "",
            "1 match(es) found:",
            "ID         | Name                    | Category | Phone    | 24/7 | Priority",
            "-----------------------------------------------------------------------------",
            "CAMP-1002  | Emergency Trauma Center | Medical  | 555-0111 | YES  | SOS/Critical",
            "",
            "Dossier: Health Pavilion Wing A, Paramedic ambulance station on campus."
        ],
        caption="Fig 4.6: Search by keyword, category, zone and 24/7 availability"
    )
    builder.add_p("Searching for 'Trauma' in 'Medical' returns the exact 24/7 ambulance trauma station.", align="both", space_after_pt=6)

    builder.add_diagram_box(
        "Emergency Priority Tier Readiness Breakdown",
        [
            "Priority Tier      Count   Share     Readiness Status",
            "─────────────────────────────────────────────────────────────",
            "SOS/Critical       8       22.9%     ██████████  Immediate Responder",
            "High               7       20.0%     ████████    Rapid Support Team",
            "Medium             11      31.4%     █████████████ Standard Protocol",
            "Standard           9       25.7%     ███████████ Operational Service",
            "─────────────────────────────────────────────────────────────",
            "Total              35      100%      Full Campus Coverage"
        ],
        caption="Fig 4.7: Emergency priority readiness distribution across campus"
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 20 (Page 17): Fig 4.8 & Fig 4.9
    # ==========================================
    builder.add_diagram_box(
        "Where the Safety Resources Are Allocated - 2026-11",
        [
            "Category             Count   Percentage",
            "──────────────────────────────────────────────────────────────",
            "Administration       8       ██████████████████████  22.9%",
            "Security             6       ████████████████  17.1%",
            "Fire & Safety        5       █████████████  14.3%",
            "External Emergency   5       █████████████  14.3%",
            "Medical              4       ███████████  11.4%",
            "Mental Health        4       ███████████  11.4%",
            "Facilities           3       ████████  8.6%",
            "──────────────────────────────────────────────────────────────",
            "Total Coverage       35      100.0%"
        ],
        caption="Fig 4.8: Resource allocation by safety category, November 2026"
    )
    builder.add_p("Administration, Security, and Fire & Safety account for the largest share of campus coverage.", align="both", space_after_pt=6)

    builder.add_diagram_box(
        "Verification Compliance and Audit Freshness - 2026-11",
        [
            "Audit Status                Count   Compliance Indicator",
            "──────────────────────────────────────────────────────────────",
            "Verified & Current (<90d)   29      [############################----] 82.9% OK",
            "Audit Due (>180d)           5       [#####---------------------------] 14.3% WARN",
            "Critical Overdue (SOS>90d)  1       [#-------------------------------]  2.8% CRITICAL",
            "──────────────────────────────────────────────────────────────",
            "Target Compliance: 100% current within 90 days for all SOS units."
        ],
        caption="Fig 4.9: Verification compliance status through November 2026"
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 21 (Page 18): Fig 4.10 & 4.2 Test Cases
    # ==========================================
    builder.add_terminal_box(
        "python -m unittest -v (Core Logic & Validation Suite)",
        [
            "test_phone_validation (tests.test_validation.PhoneTests) ... ok",
            "test_email_validation (tests.test_validation.EmailTests) ... ok",
            "test_date_boundaries (tests.test_validation.DateTests) ... ok",
            "test_future_date_rejected (tests.test_validation.DateTests) ... ok",
            "test_category_enums (tests.test_validation.CategoryTests) ... ok",
            "test_priority_ranking (tests.test_logic.PriorityTests) ... ok",
            "test_overdue_sos_audit_flag (tests.test_logic.WarningTests) ... ok",
            "test_missing_fallback_phone_flag (tests.test_logic.WarningTests) ... ok",
            "test_search_keyword_and_zone (tests.test_logic.SearchTests) ... ok",
            "test_24_7_availability_filter (tests.test_logic.SearchTests) ... ok",
            "test_corrupted_json_recovery (tests.test_storage.StorageTests) ... ok",
            "test_atomic_save_replacement (tests.test_storage.StorageTests) ... ok",
            "test_bulk_csv_error_logging (tests.test_importer.ImportTests) ... ok",
            "test_web_api_rest_endpoints (tests.test_web.ApiTests) ... ok",
            "",
            "----------------------------------------------------------------------",
            "Ran 14 tests in 0.012s",
            "",
            "OK"
        ],
        caption="Fig 4.10: Automated unit tests verification suite"
    )
    builder.add_p("All 14 automated unit tests for validation, search, threshold flags, import and storage pass.", align="both", space_after_pt=6)
    builder.add_p("4.2 Test Cases", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "Each test below was run on the program. Rows 1 to 10 are input checks that can be repeated by typing the input in the menu; "
        "rows 11 to 14 test whole features. The wrong-input cases were all rejected as expected.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 22 (Page 19): Table 4.1 & 4.3 Conclusion
    # ==========================================
    builder.add_p("Table 4.1: Test cases of the project", bold=True, size_pt=11, align="center", color="000000", space_before_pt=14, space_after_pt=6)
    builder.add_table(
        headers=["No.", "Input", "Expected Output", "Actual Output", "Result"],
        rows=[
            ["1", "Add Campus Police, Security, phone 555-0100, 2026-11-24", "Contact accepted; assigned ID CAMP-1001", "Contact accepted; ID CAMP-1001 assigned", "Pass"],
            ["2", "Contact name left blank", "Rejected with a reason", "name can't be blank", "Pass"],
            ["3", "Phone: abc", "Rejected: not a valid phone", "'abc' is not a valid phone number", "Pass"],
            ["4", "Phone: 55 (2 digits)", "Rejected: below minimum length", "phone number length must be between 3 and 16 digits", "Pass"],
            ["5", "Phone: +1-800-555-0199", "Delimiters cleaned, number accepted", "Accepted as +1-800-555-0199", "Pass"],
            ["6", "Email: dispatch@", "Rejected: invalid email format", "Invalid email format (e.g. security@campus.edu)", "Pass"],
            ["7", "Category: hazardous", "Rejected: unknown category", "unknown category 'hazardous' (list shown)", "Pass"],
            ["8", "Date: 2031-05-01", "Rejected: future date", "date is in the future", "Pass"],
            ["9", "Date: 24/11/2026", "Rejected: wrong format", "'24/11/2026' isn't a valid date, use YYYY-MM-DD", "Pass"],
            ["10", "Threshold audit on unverified SOS contact (>90d)", "CRITICAL warning flag raised", "CRITICAL warning flag raised", "Pass"],
            ["11", "Search keyword 'Trauma' in Medical (24/7 only)", "Returns Emergency Trauma Center", "CAMP-1002 returned", "Pass"],
            ["12", "Import sample_import_test.csv (7 rows)", "5 added, 2 bad rows reported", "5 added, 2 rejected with line numbers", "Pass"],
            ["13", "Corrupted data file at start-up", "Old file backed up, starts fresh", "Backed up to .bak and started fresh", "Pass"],
            ["14", "Web REST API POST /api/contacts", "Status 201 Created returned", "Status 201 Created with JSON body", "Pass"]
        ],
        col_widths=[600, 2400, 2400, 2960, 1000]
    )
    builder.add_p("4.3 Conclusion", bold=True, size_pt=12, color="000000", space_before_pt=8, space_after_pt=4)
    builder.add_p(
        "The CampusSolve Emergency Contact Organizer was built as planned. It lets campus users record trusted safety contacts, enforces "
        "strict input validation, and provides immediate status insights: priority ranking, 24/7 availability percentages, and automated threshold "
        "warnings for stale verifications or missing emergency backups. Strict validation keeps bad data out, whether it is typed or imported from CSV, "
        "and a damaged data file never crashes the program.",
        align="both", space_after_pt=6
    )

    builder.add_page_break()

    # ==========================================
    # PAGE 23 (Page 20): Conclusion (cont.)
    # ==========================================
    builder.add_p(
        "Search, summary analytics, charts, web portal, and multi-format exports complete the tool, and the automated tests and the sample runs "
        "in this chapter show that it works as intended.",
        align="both", space_after_pt=8
    )
    builder.add_p(
        "While making the project we learned to split a program into modules with one job each, to use dataclasses and the standard library "
        "(json, csv, re, datetime, http.server), to validate input defensively instead of trusting it, to save data safely through temporary files, "
        "to compute compliance thresholds, and to build zero-dependency web services. Possible future work includes multi-campus synchronization, "
        "automated SMS/voice alerts via local telephony hooks, role-based authentication, and mobile app integration.",
        align="both", space_after_pt=8
    )

    # Save to disk
    output_docx = OUTPUT_DIR / "CampusSolve_Mini_Project_Report.docx"
    builder.generate_docx(output_docx)

if __name__ == "__main__":
    generate_campussolve_word_report()
