"""
CampusSolve - Project #71: Emergency Contact Organizer
Domain: Safety & Community | Hackathon Mentor Guide

A robust, zero-dependency Python 3.10+ terminal application featuring:
- Interactive Menu-Driven Terminal Interface
- Defensive Input Validation & Regex Verification
- Core Business Logic Engine for Contact Organization & Fast Search
- Reliable JSON & CSV Persistence with Corrupted File Auto-Recovery
- Executive Summary & Analytics Generation with ASCII Charts
- Threshold Warning Flags (Overdue Verifications, Missing Fallbacks)
- Multi-Format Export (Markdown, CSV, Plain-text Audit Log)
- Bulk CSV Import with Row-by-Row Error Logging
"""

import os
import sys
import json
import csv
import re
from datetime import datetime, date, timedelta
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Optional, Tuple, Any
from pathlib import Path

# ==========================================
# CONSTANTS & CONFIGURATION
# ==========================================
DEFAULT_DATA_DIR = Path(__file__).resolve().parent / "data"
DEFAULT_JSON_FILE = DEFAULT_DATA_DIR / "emergency_contacts.json"
DEFAULT_CSV_FILE = DEFAULT_DATA_DIR / "emergency_contacts.csv"
DEFAULT_EXPORTS_DIR = Path(__file__).resolve().parent / "exports"

VALID_CATEGORIES = [
    "Security",
    "Medical",
    "Mental Health",
    "Fire & Safety",
    "Residence/Housing",
    "Facilities",
    "Administration",
    "External Emergency"
]

VALID_PRIORITIES = ["SOS/Critical", "High", "Medium", "Standard"]

VALID_CAMPUS_ZONES = [
    "Campus-Wide",
    "North Campus",
    "South Campus",
    "Central Quad",
    "Science Complex",
    "Engineering Block",
    "Student Residences",
    "Athletics Center"
]

PHONE_REGEX = re.compile(r"^(\+?\d{1,4}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?[\d]{3}[-.\s]?[\d]{4}$|^(911|112|100|101|102|108|999|000)$")
EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# ==========================================
# DATA MODELS
# ==========================================
@dataclass
class EmergencyContact:
    contact_id: str
    name: str
    category: str
    primary_phone: str
    secondary_phone: str
    email: str
    campus_zone: str
    building_room: str
    is_24_7: bool
    priority_tier: str
    last_verified_date: str  # YYYY-MM-DD
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EmergencyContact":
        # Handle string booleans if parsed from CSV
        is_24_7_val = data.get("is_24_7", False)
        if isinstance(is_24_7_val, str):
            is_24_7_val = is_24_7_val.strip().lower() in ("true", "1", "yes", "t", "y")
        
        return cls(
            contact_id=str(data.get("contact_id", "")).strip(),
            name=str(data.get("name", "")).strip(),
            category=str(data.get("category", "Security")).strip(),
            primary_phone=str(data.get("primary_phone", "")).strip(),
            secondary_phone=str(data.get("secondary_phone", "")).strip(),
            email=str(data.get("email", "")).strip(),
            campus_zone=str(data.get("campus_zone", "Campus-Wide")).strip(),
            building_room=str(data.get("building_room", "")).strip(),
            is_24_7=bool(is_24_7_val),
            priority_tier=str(data.get("priority_tier", "Standard")).strip(),
            last_verified_date=str(data.get("last_verified_date", date.today().isoformat())).strip(),
            notes=str(data.get("notes", "")).strip()
        )

# ==========================================
# DEFENSIVE VALIDATION MODULE
# ==========================================
class InputValidator:
    @staticmethod
    def sanitize(text: str) -> str:
        return text.strip() if text else ""

    @staticmethod
    def validate_name(name: str) -> Tuple[bool, str]:
        s = name.strip()
        if len(s) < 2:
            return False, "Name must be at least 2 characters long."
        if len(s) > 80:
            return False, "Name cannot exceed 80 characters."
        return True, ""

    @staticmethod
    def validate_category(cat: str) -> Tuple[bool, str]:
        s = cat.strip()
        matched = [c for c in VALID_CATEGORIES if c.lower() == s.lower()]
        if matched:
            return True, matched[0]
        return False, f"Invalid category. Allowed: {', '.join(VALID_CATEGORIES)}"

    @staticmethod
    def validate_priority(prio: str) -> Tuple[bool, str]:
        s = prio.strip()
        matched = [p for p in VALID_PRIORITIES if p.lower() == s.lower()]
        if matched:
            return True, matched[0]
        return False, f"Invalid priority. Allowed: {', '.join(VALID_PRIORITIES)}"

    @staticmethod
    def validate_phone(phone: str, optional: bool = False) -> Tuple[bool, str]:
        s = phone.strip()
        if not s and optional:
            return True, ""
        if not s:
            return False, "Phone number cannot be empty."
        # Clean delimiters for basic validation
        digits_only = re.sub(r"[^\d+]", "", s)
        if len(digits_only) < 3 or len(digits_only) > 16:
            return False, "Phone number length must be between 3 and 16 digits/characters."
        return True, s

    @staticmethod
    def validate_email(email: str, optional: bool = False) -> Tuple[bool, str]:
        s = email.strip()
        if not s and optional:
            return True, ""
        if not EMAIL_REGEX.match(s):
            return False, "Invalid email format (e.g., security@campus.edu)."
        return True, s

    @staticmethod
    def validate_date(date_str: str) -> Tuple[bool, str]:
        s = date_str.strip()
        if not DATE_REGEX.match(s):
            return False, "Date must be formatted as YYYY-MM-DD."
        try:
            d = datetime.strptime(s, "%Y-%m-%d").date()
            if d > date.today():
                return False, "Verification date cannot be in the future."
            return True, s
        except ValueError:
            return False, "Invalid calendar date."

# Centralized interactive input wrappers
def prompt_with_validation(prompt_text: str, validator_fn, optional: bool = False, default: str = "") -> str:
    while True:
        display_prompt = f"{prompt_text} [{default}]: " if default else f"{prompt_text}: "
        try:
            val = input(display_prompt).strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[!] Input aborted by user.")
            return default

        if not val and default:
            return default
        if not val and optional:
            return ""

        valid, result_or_err = validator_fn(val)
        if valid:
            return result_or_err if result_or_err != "" else val
        print(f"  [X] Error: {result_or_err}. Please try again.")

def prompt_choice(prompt_text: str, options: List[str], default_idx: int = 0) -> str:
    print(f"\n{prompt_text}:")
    for i, opt in enumerate(options, 1):
        def_tag = " (Default)" if i - 1 == default_idx else ""
        print(f"  [{i}] {opt}{def_tag}")
    
    while True:
        try:
            choice = input(f"Select option (1-{len(options)}) [{default_idx+1}]: ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            return options[default_idx]
        
        if not choice:
            return options[default_idx]
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(options):
                return options[idx]
        # Allow typing exact match
        for opt in options:
            if opt.lower() == choice.lower():
                return opt
        print(f"  [X] Invalid selection. Please enter a number between 1 and {len(options)}.")

# ==========================================
# PERSISTENCE ENGINE (JSON & CSV)
# ==========================================
class PersistenceEngine:
    def __init__(self, data_dir = DEFAULT_DATA_DIR, json_file = DEFAULT_JSON_FILE, csv_file = DEFAULT_CSV_FILE):
        self.data_dir = Path(data_dir)
        self.json_file = Path(json_file)
        self.csv_file = Path(csv_file)
        self._ensure_directories()

    def _ensure_directories(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        DEFAULT_EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

    def load_contacts(self) -> List[EmergencyContact]:
        """Loads contacts safely from JSON. Recovers gracefully from corruption or missing files."""
        if not self.json_file.exists():
            print(f"[*] No existing database found. Initializing empty dataset at {self.json_file.name}...")
            self.save_contacts([])
            return []

        try:
            with open(self.json_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if not isinstance(data, list):
                    raise ValueError("JSON root element must be a list of contact records.")
                contacts = []
                for entry in data:
                    try:
                        contacts.append(EmergencyContact.from_dict(entry))
                    except Exception as err:
                        print(f"  [!] Skipping malformed record: {err}")
                return contacts
        except (json.JSONDecodeError, ValueError) as e:
            backup_file = self.json_file.with_suffix(f".corrupted_{int(datetime.now().timestamp())}.bak")
            print(f"\n[!] WARNING: Database file '{self.json_file.name}' is corrupted ({e}).")
            print(f"[*] Creating backup of corrupted file at '{backup_file.name}' and initializing clean file.")
            try:
                os.rename(self.json_file, backup_file)
            except OSError:
                pass
            self.save_contacts([])
            return []
        except Exception as e:
            print(f"[!] Unexpected error loading storage: {e}")
            return []

    def save_contacts(self, contacts: List[EmergencyContact]) -> bool:
        """Atomically saves contacts to both JSON and CSV files."""
        self._ensure_directories()
        data = [c.to_dict() for c in contacts]
        
        # Save JSON
        try:
            temp_json = self.json_file.with_suffix(".tmp")
            with open(temp_json, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            temp_json.replace(self.json_file)
        except Exception as e:
            print(f"[X] Failed to persist JSON data: {e}")
            return False

        # Save synchronized CSV
        try:
            temp_csv = self.csv_file.with_suffix(".tmp")
            if contacts:
                fieldnames = list(contacts[0].to_dict().keys())
            else:
                fieldnames = [
                    "contact_id", "name", "category", "primary_phone", "secondary_phone",
                    "email", "campus_zone", "building_room", "is_24_7", "priority_tier",
                    "last_verified_date", "notes"
                ]
            with open(temp_csv, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for c in contacts:
                    writer.writerow(c.to_dict())
            temp_csv.replace(self.csv_file)
        except Exception as e:
            print(f"[!] Warning: CSV synchronization failed ({e}), but JSON succeeded.")

        return True

# ==========================================
# CORE BUSINESS LOGIC & SEARCH ENGINE
# ==========================================
class ContactManager:
    def __init__(self, persistence: PersistenceEngine):
        self.persistence = persistence
        self.contacts: List[EmergencyContact] = self.persistence.load_contacts()

    def get_all(self) -> List[EmergencyContact]:
        return sorted(self.contacts, key=lambda c: (self._priority_rank(c.priority_tier), c.name.lower()))

    @staticmethod
    def _priority_rank(prio: str) -> int:
        rank_map = {"SOS/Critical": 0, "High": 1, "Medium": 2, "Standard": 3}
        return rank_map.get(prio, 4)

    def generate_next_id(self) -> str:
        existing_nums = []
        for c in self.contacts:
            match = re.match(r"^CAMP-(\d+)$", c.contact_id.upper())
            if match:
                existing_nums.append(int(match.group(1)))
        next_num = max(existing_nums, default=1000) + 1
        return f"CAMP-{next_num}"

    def add_contact(self, contact: EmergencyContact) -> Tuple[bool, str]:
        # Check duplicate primary phone or ID
        for c in self.contacts:
            if c.contact_id.upper() == contact.contact_id.upper():
                return False, f"Contact ID '{contact.contact_id}' already exists."
        self.contacts.append(contact)
        if self.persistence.save_contacts(self.contacts):
            return True, f"Contact '{contact.name}' ({contact.contact_id}) successfully created."
        return False, "Failed to save to local persistence."

    def update_contact(self, contact_id: str, updated_fields: Dict[str, Any]) -> Tuple[bool, str]:
        for idx, c in enumerate(self.contacts):
            if c.contact_id.upper() == contact_id.upper():
                current_dict = c.to_dict()
                current_dict.update(updated_fields)
                self.contacts[idx] = EmergencyContact.from_dict(current_dict)
                self.persistence.save_contacts(self.contacts)
                return True, f"Contact '{c.name}' updated successfully."
        return False, f"Contact with ID '{contact_id}' not found."

    def delete_contact(self, contact_id: str) -> Tuple[bool, str]:
        for idx, c in enumerate(self.contacts):
            if c.contact_id.upper() == contact_id.upper():
                removed = self.contacts.pop(idx)
                self.persistence.save_contacts(self.contacts)
                return True, f"Contact '{removed.name}' ({removed.contact_id}) permanently removed."
        return False, f"Contact with ID '{contact_id}' not found."

    def find_by_id(self, contact_id: str) -> Optional[EmergencyContact]:
        for c in self.contacts:
            if c.contact_id.upper() == contact_id.upper():
                return c
        return None

    def search(self, query: str = "", category: str = "", zone: str = "", priority: str = "", only_24_7: bool = False) -> List[EmergencyContact]:
        """Multi-criteria search engine supporting keyword, category, zone, priority and 24/7 filter."""
        results = []
        q = query.strip().lower()
        cat_filter = category.strip().lower()
        zone_filter = zone.strip().lower()
        prio_filter = priority.strip().lower()

        for c in self.contacts:
            # Category match
            if cat_filter and c.category.lower() != cat_filter:
                continue
            # Zone match
            if zone_filter and c.campus_zone.lower() != zone_filter:
                continue
            # Priority match
            if prio_filter and c.priority_tier.lower() != prio_filter:
                continue
            # 24/7 filter
            if only_24_7 and not c.is_24_7:
                continue
            # Keyword match across all major fields
            if q:
                searchable_text = f"{c.contact_id} {c.name} {c.category} {c.primary_phone} {c.secondary_phone} {c.email} {c.campus_zone} {c.building_room} {c.notes}".lower()
                if q not in searchable_text:
                    continue
            results.append(c)

        return sorted(results, key=lambda c: (self._priority_rank(c.priority_tier), c.name.lower()))

    # ==========================================
    # THRESHOLD WARNING ENGINE (Stretch Feature)
    # ==========================================
    def check_threshold_warnings(self) -> List[Dict[str, Any]]:
        """
        Automated warning flags:
        1. Overdue verification (> 180 days for all, > 90 days for SOS/Critical)
        2. Critical SOS without a backup secondary phone
        3. Missing building/room details
        4. Stale contacts verified over a year ago
        """
        warnings = []
        today = date.today()

        for c in self.contacts:
            try:
                verified_date = datetime.strptime(c.last_verified_date, "%Y-%m-%d").date()
                days_since_verified = (today - verified_date).days
            except ValueError:
                days_since_verified = 9999

            # Check 1: SOS overdue (> 90 days)
            if c.priority_tier == "SOS/Critical" and days_since_verified > 90:
                warnings.append({
                    "contact_id": c.contact_id,
                    "name": c.name,
                    "severity": "CRITICAL",
                    "code": "OVERDUE_SOS_AUDIT",
                    "message": f"SOS Contact verification overdue! Last verified {days_since_verified} days ago (limit: 90 days)."
                })
            elif days_since_verified > 180:
                warnings.append({
                    "contact_id": c.contact_id,
                    "name": c.name,
                    "severity": "WARNING",
                    "code": "OVERDUE_GENERAL_AUDIT",
                    "message": f"Contact verification is stale ({days_since_verified} days ago, recommended audit interval: 180 days)."
                })

            # Check 2: Critical SOS missing secondary fallback phone
            if c.priority_tier == "SOS/Critical" and not c.secondary_phone:
                warnings.append({
                    "contact_id": c.contact_id,
                    "name": c.name,
                    "severity": "HIGH",
                    "code": "MISSING_FALLBACK_PHONE",
                    "message": "SOS contact has NO secondary/backup phone number registered."
                })

            # Check 3: Incomplete physical location
            if not c.building_room or c.building_room.lower() in ("tbd", "unknown", "n/a", "-"):
                warnings.append({
                    "contact_id": c.contact_id,
                    "name": c.name,
                    "severity": "MEDIUM",
                    "code": "INCOMPLETE_LOCATION",
                    "message": "Physical office / building room is unassigned or marked TBD."
                })

        return warnings

    # ==========================================
    # EXECUTIVE SUMMARY & ANALYTICS
    # ==========================================
    def generate_summary_metrics(self) -> Dict[str, Any]:
        total = len(self.contacts)
        if total == 0:
            return {
                "total_contacts": 0,
                "count_24_7": 0,
                "pct_24_7": 0.0,
                "category_breakdown": {},
                "priority_breakdown": {},
                "zone_breakdown": {},
                "audit_status": {"verified_current": 0, "needs_review": 0, "critical_overdue": 0},
                "warnings": []
            }

        count_24_7 = sum(1 for c in self.contacts if c.is_24_7)
        pct_24_7 = round((count_24_7 / total) * 100, 1)

        category_counts: Dict[str, int] = {}
        for c in self.contacts:
            category_counts[c.category] = category_counts.get(c.category, 0) + 1

        priority_counts: Dict[str, int] = {}
        for c in self.contacts:
            priority_counts[c.priority_tier] = priority_counts.get(c.priority_tier, 0) + 1

        zone_counts: Dict[str, int] = {}
        for c in self.contacts:
            zone_counts[c.campus_zone] = zone_counts.get(c.campus_zone, 0) + 1

        # Audit health
        today = date.today()
        verified_current = 0
        needs_review = 0
        critical_overdue = 0

        for c in self.contacts:
            try:
                vd = datetime.strptime(c.last_verified_date, "%Y-%m-%d").date()
                diff = (today - vd).days
                if c.priority_tier == "SOS/Critical" and diff > 90:
                    critical_overdue += 1
                elif diff > 180:
                    needs_review += 1
                else:
                    verified_current += 1
            except ValueError:
                needs_review += 1

        warnings = self.check_threshold_warnings()

        return {
            "total_contacts": total,
            "count_24_7": count_24_7,
            "pct_24_7": pct_24_7,
            "category_breakdown": category_counts,
            "priority_breakdown": priority_counts,
            "zone_breakdown": zone_counts,
            "audit_status": {
                "verified_current": verified_current,
                "needs_review": needs_review,
                "critical_overdue": critical_overdue
            },
            "warnings_count": len(warnings),
            "warnings": warnings
        }

    # ==========================================
    # BULK IMPORT CSV ENGINE (Stretch Feature)
    # ==========================================
    def bulk_import_csv(self, file_path: str) -> Dict[str, Any]:
        path = Path(file_path)
        if not path.exists():
            return {"success": False, "imported": 0, "errors": [f"File not found: '{file_path}'"]}

        imported_count = 0
        row_errors: List[str] = []
        new_contacts: List[EmergencyContact] = []

        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    return {"success": False, "imported": 0, "errors": ["CSV file is empty or missing headers."]}

                required_keys = {"name", "category", "primary_phone"}
                missing_headers = required_keys - set(reader.fieldnames)
                if missing_headers:
                    return {
                        "success": False,
                        "imported": 0,
                        "errors": [f"Missing required CSV columns: {', '.join(missing_headers)}"]
                    }

                for row_num, row in enumerate(reader, start=2):
                    row_clean = {k: v.strip() for k, v in row.items() if k}
                    name = row_clean.get("name", "")
                    if not name:
                        row_errors.append(f"Row {row_num}: Missing contact name.")
                        continue

                    # Validate Category
                    cat = row_clean.get("category", "Security")
                    cat_ok, cat_val = InputValidator.validate_category(cat)
                    if not cat_ok:
                        cat_val = "Security"  # Fallback gracefully with note

                    # Validate Phone
                    phone = row_clean.get("primary_phone", "")
                    phone_ok, phone_val = InputValidator.validate_phone(phone)
                    if not phone_ok:
                        row_errors.append(f"Row {row_num} ('{name}'): Invalid primary phone '{phone}'.")
                        continue

                    # Priority
                    prio = row_clean.get("priority_tier", "Standard")
                    prio_ok, prio_val = InputValidator.validate_priority(prio)
                    if not prio_ok:
                        prio_val = "Standard"

                    # Email
                    email = row_clean.get("email", "")
                    if email:
                        e_ok, e_val = InputValidator.validate_email(email, optional=True)
                        if not e_ok:
                            email = ""  # Clean or keep empty

                    # 24/7 flag
                    is_24_7_raw = row_clean.get("is_24_7", "False").lower()
                    is_24_7 = is_24_7_raw in ("true", "1", "yes", "t", "y")

                    # Last verified date
                    vdate = row_clean.get("last_verified_date", date.today().isoformat())
                    d_ok, d_val = InputValidator.validate_date(vdate)
                    if not d_ok:
                        vdate = date.today().isoformat()

                    contact_id = row_clean.get("contact_id")
                    if not contact_id or self.find_by_id(contact_id):
                        contact_id = self.generate_next_id()

                    contact = EmergencyContact(
                        contact_id=contact_id,
                        name=name,
                        category=cat_val,
                        primary_phone=phone_val,
                        secondary_phone=row_clean.get("secondary_phone", ""),
                        email=email,
                        campus_zone=row_clean.get("campus_zone", "Campus-Wide"),
                        building_room=row_clean.get("building_room", "Main Desk"),
                        is_24_7=is_24_7,
                        priority_tier=prio_val,
                        last_verified_date=vdate,
                        notes=row_clean.get("notes", "Imported via bulk dataset")
                    )
                    new_contacts.append(contact)
                    self.contacts.append(contact)
                    imported_count += 1

            if imported_count > 0:
                self.persistence.save_contacts(self.contacts)

            return {
                "success": True,
                "imported": imported_count,
                "errors": row_errors,
                "total_rows_processed": imported_count + len(row_errors)
            }
        except Exception as e:
            return {"success": False, "imported": 0, "errors": [f"CSV parse exception: {str(e)}"]}

    # ==========================================
    # MULTI-FORMAT EXPORT ENGINE (Stretch Feature)
    # ==========================================
    def export_summary_markdown(self, output_path: Optional[Path] = None) -> Path:
        metrics = self.generate_summary_metrics()
        out_file = output_path or (DEFAULT_EXPORTS_DIR / f"CampusSolve_Report_{date.today().isoformat()}.md")

        md_lines = [
            f"# CampusSolve: Emergency Contact Organizer - Executive Summary",
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
            f"**Campus Safety Domain:** Comprehensive Audit & Status Insight  \n",
            "---",
            "## 1. High-Level Operational Metrics",
            f"- **Total Emergency Contacts Registered:** {metrics['total_contacts']}",
            f"- **24/7 Emergency Services Available:** {metrics['count_24_7']} ({metrics['pct_24_7']}% coverage)",
            f"- **Contacts in Active Compliance:** {metrics['audit_status']['verified_current']}",
            f"- **Audit Review Recommended (>180d):** {metrics['audit_status']['needs_review']}",
            f"- **Critical Overdue Inquiries (>90d for SOS):** {metrics['audit_status']['critical_overdue']}  \n",
            "## 2. Category Distribution",
            "| Category | Count | Percentage |",
            "| :--- | :---: | :---: |"
        ]

        total = metrics["total_contacts"] or 1
        for cat, cnt in sorted(metrics["category_breakdown"].items(), key=lambda x: -x[1]):
            pct = round((cnt / total) * 100, 1)
            md_lines.append(f"| {cat} | {cnt} | {pct}% |")

        md_lines.extend([
            "\n## 3. Priority Tier Breakdown",
            "| Priority Tier | Count | Description |",
            "| :--- | :---: | :--- |"
        ])
        for prio, cnt in sorted(metrics["priority_breakdown"].items(), key=lambda x: self._priority_rank(x[0])):
            md_lines.append(f"| {prio} | {cnt} | {'Top-level instant responder' if 'SOS' in prio else 'Standard operational tier'} |")

        warnings = metrics.get("warnings", [])
        md_lines.extend([
            f"\n## 4. Threshold Warnings & Anomalies ({len(warnings)} Detected)",
            "| Severity | Contact ID | Name | Issue Flag |",
            "| :--- | :--- | :--- | :--- |"
        ])
        if not warnings:
            md_lines.append("| OK | - | All Contacts | No threshold violations found. Full compliance. |")
        else:
            for w in warnings:
                md_lines.append(f"| **{w['severity']}** | `{w['contact_id']}` | {w['name']} | {w['message']} |")

        md_lines.extend([
            "\n## 5. Master Directory Roster",
            "| ID | Name | Category | Primary Phone | 24/7 | Priority | Last Verified |",
            "| :--- | :--- | :--- | :--- | :---: | :--- | :--- |"
        ])
        for c in self.get_all():
            md_lines.append(f"| {c.contact_id} | {c.name} | {c.category} | {c.primary_phone} | {'YES' if c.is_24_7 else 'No'} | {c.priority_tier} | {c.last_verified_date} |")

        out_file.write_text("\n".join(md_lines), encoding="utf-8")
        return out_file

    def export_audit_log(self, output_path: Optional[Path] = None) -> Path:
        out_file = output_path or (DEFAULT_EXPORTS_DIR / f"audit_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
        lines = [
            "=" * 70,
            "CAMPUSSOLVE EMERGENCY CONTACT ORGANIZER - SYSTEM AUDIT LOG",
            f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Total Records Inspected: {len(self.contacts)}",
            "=" * 70,
            "\n[1] STATUS COMPLIANCE AUDIT"
        ]
        warnings = self.check_threshold_warnings()
        if not warnings:
            lines.append("  -> All records satisfy active audit checks. 0 anomalies.")
        else:
            for w in warnings:
                lines.append(f"  [{w['severity']}] [{w['contact_id']}] {w['name']}: {w['message']}")

        lines.extend([
            "\n[2] RECORD FINGERPRINT INVENTORY",
            f"{'ID':<11} | {'PRIORITY':<12} | {'CATEGORY':<16} | {'NAME':<30} | PHONE",
            "-" * 85
        ])
        for c in self.get_all():
            lines.append(f"{c.contact_id:<11} | {c.priority_tier:<12} | {c.category:<16} | {c.name[:29]:<30} | {c.primary_phone}")

        out_file.write_text("\n".join(lines), encoding="utf-8")
        return out_file

# ==========================================
# TERMINAL USER INTERFACE (CLI)
# ==========================================
class TerminalUI:
    def __init__(self, manager: ContactManager):
        self.mgr = manager

    @staticmethod
    def clear():
        os.system("cls" if os.name == "nt" else "clear")

    def print_banner(self):
        banner = r"""
========================================================================
   ____                                   ____        _            
  / ___|__ _ _ __ ___  _ __  _   _ ___  / ___|  ___ | |_   _____  
 | |   / _` | '_ ` _ \| '_ \| | | / __| \___ \ / _ \| \ \ / / _ \ 
 | |__| (_| | | | | | | |_) | |_| \__ \  ___) | (_) | |\ V /  __/ 
  \____\__,_|_| |_| |_| .__/ \__,_|___/ |____/ \___/|_| \_/ \___| 
                      |_| Project #71: Emergency Contact Organizer
========================================================================
 Domain: Campus Safety & Community   | Mode: Local Secure Persistence
 Status: Zero-Dependency Python 3.10+ | Health: Verified Ready
========================================================================"""
        print(banner)

    def print_table(self, contacts: List[EmergencyContact], title: str = "Search Results"):
        print(f"\n--- {title} (Total: {len(contacts)}) ---")
        if not contacts:
            print("  [i] No contacts matched the criteria.")
            return

        header = f"{'ID':<10} | {'Name':<24} | {'Category':<15} | {'Phone':<15} | {'24/7':<4} | {'Zone':<14} | {'Priority':<12}"
        separator = "-" * len(header)
        print(separator)
        print(header)
        print(separator)

        for c in contacts:
            name_disp = c.name if len(c.name) <= 24 else c.name[:21] + "..."
            zone_disp = c.campus_zone if len(c.campus_zone) <= 14 else c.campus_zone[:11] + "..."
            is_247_disp = "YES" if c.is_24_7 else "NO"
            print(f"{c.contact_id:<10} | {name_disp:<24} | {c.category:<15} | {c.primary_phone:<15} | {is_247_disp:<4} | {zone_disp:<14} | {c.priority_tier:<12}")
        print(separator)

    def run_add_contact_workflow(self):
        print("\n=== RECORD A NEW EMERGENCY CONTACT ===")
        print("Please follow the defensive validation prompts below (Ctrl+C to cancel):\n")
        
        name = prompt_with_validation("Contact Name / Dept Name", InputValidator.validate_name)
        category = prompt_choice("Designated Category", VALID_CATEGORIES)
        primary_phone = prompt_with_validation("Primary Emergency Phone", InputValidator.validate_phone)
        secondary_phone = prompt_with_validation("Secondary/Fallback Phone (Optional)", lambda p: InputValidator.validate_phone(p, optional=True), optional=True)
        email = prompt_with_validation("Official Email Address (Optional)", lambda e: InputValidator.validate_email(e, optional=True), optional=True)
        campus_zone = prompt_choice("Campus Zone Coverage", VALID_CAMPUS_ZONES)
        building_room = prompt_with_validation("Building & Room / Station", lambda r: (True, r), default="Security Desk Rm 101")
        
        is_24_7_choice = prompt_choice("Is this service available 24/7?", ["Yes (Round-the-clock emergency responder)", "No (Regular / Scheduled Hours)"])
        is_24_7 = "Yes" in is_24_7_choice
        
        priority_tier = prompt_choice("Emergency Priority Level", VALID_PRIORITIES, default_idx=1)
        last_verified = prompt_with_validation("Audit Verification Date (YYYY-MM-DD)", InputValidator.validate_date, default=date.today().isoformat())
        notes = input("Operational Notes / Protocol (Optional): ").strip()

        cid = self.mgr.generate_next_id()
        new_c = EmergencyContact(
            contact_id=cid,
            name=name,
            category=category,
            primary_phone=primary_phone,
            secondary_phone=secondary_phone,
            email=email,
            campus_zone=campus_zone,
            building_room=building_room,
            is_24_7=is_24_7,
            priority_tier=priority_tier,
            last_verified_date=last_verified,
            notes=notes
        )

        ok, msg = self.mgr.add_contact(new_c)
        if ok:
            print(f"\n[OK] SUCCESS: {msg}")
            # Print card preview
            print(f"     Recorded ID: {new_c.contact_id} | Phone: {new_c.primary_phone} | Priority: {new_c.priority_tier}")
        else:
            print(f"\n[X] ERROR: {msg}")

    def run_search_workflow(self):
        print("\n=== QUERY & SEARCH CONTACT RECORDS ===")
        print("Filter by keyword, category, zone, or 24/7 status.")
        kw = input("Enter search keyword (name, phone, room, notes) [Leave empty for all]: ").strip()
        
        filter_cat = prompt_choice("Filter by Category?", ["All Categories"] + VALID_CATEGORIES, default_idx=0)
        selected_cat = "" if filter_cat == "All Categories" else filter_cat
        
        filter_zone = prompt_choice("Filter by Campus Zone?", ["All Zones"] + VALID_CAMPUS_ZONES, default_idx=0)
        selected_zone = "" if filter_zone == "All Zones" else filter_zone

        only_247 = prompt_choice("Filter 24/7 Availability?", ["Show All Records", "Only 24/7 Services"], default_idx=0) == "Only 24/7 Services"

        results = self.mgr.search(query=kw, category=selected_cat, zone=selected_zone, only_24_7=only_247)
        self.print_table(results, title="Filtered Emergency Directory")

        if results:
            inspect = input("\nEnter Contact ID to view complete dossier (or press Enter to return): ").strip()
            if inspect:
                c = self.mgr.find_by_id(inspect)
                if c:
                    self.print_contact_dossier(c)
                else:
                    print(f"  [X] No contact found with ID '{inspect}'.")

    def print_contact_dossier(self, c: EmergencyContact):
        print("\n" + "=" * 60)
        print(f" DOSSIER: [{c.contact_id}] {c.name.upper()}")
        print("=" * 60)
        print(f"  Priority Level    : {c.priority_tier}")
        print(f"  Domain Category   : {c.category}")
        print(f"  Primary Phone     : {c.primary_phone} (Immediate Call)")
        print(f"  Secondary Phone   : {c.secondary_phone or 'None registered'}")
        print(f"  Official Email    : {c.email or 'N/A'}")
        print(f"  Campus Zone       : {c.campus_zone}")
        print(f"  Office / Room     : {c.building_room}")
        print(f"  24/7 Available    : {'YES (24 Hours / 7 Days)' if c.is_24_7 else 'No (Operating hours apply)'}")
        print(f"  Last Verified     : {c.last_verified_date}")
        print(f"  Operational Notes : {c.notes or 'None'}")
        print("=" * 60)

    def run_update_workflow(self):
        print("\n=== UPDATE CONTACT RECORD ===")
        cid = input("Enter Contact ID to update (e.g. CAMP-1001): ").strip()
        c = self.mgr.find_by_id(cid)
        if not c:
            print(f"[X] Contact with ID '{cid}' not found.")
            return

        self.print_contact_dossier(c)
        print("\nPress Enter to retain existing value, or provide new data:")

        new_name = prompt_with_validation("New Name", InputValidator.validate_name, default=c.name)
        new_phone = prompt_with_validation("New Primary Phone", InputValidator.validate_phone, default=c.primary_phone)
        new_sec_phone = prompt_with_validation("New Secondary Phone", lambda p: InputValidator.validate_phone(p, optional=True), optional=True, default=c.secondary_phone)
        new_email = prompt_with_validation("New Email", lambda e: InputValidator.validate_email(e, optional=True), optional=True, default=c.email)
        new_room = prompt_with_validation("Building & Room", lambda r: (True, r), default=c.building_room)
        new_notes = input(f"Operational Notes [{c.notes}]: ").strip() or c.notes

        is_verified = prompt_choice("Update verification date to TODAY?", ["Yes (Mark verified today)", "No (Keep current date)"])
        vdate = date.today().isoformat() if "Yes" in is_verified else c.last_verified_date

        updates = {
            "name": new_name,
            "primary_phone": new_phone,
            "secondary_phone": new_sec_phone,
            "email": new_email,
            "building_room": new_room,
            "notes": new_notes,
            "last_verified_date": vdate
        }
        ok, msg = self.mgr.update_contact(cid, updates)
        if ok:
            print(f"\n[OK] {msg}")
        else:
            print(f"\n[X] {msg}")

    def run_delete_workflow(self):
        print("\n=== REMOVE EMERGENCY CONTACT ===")
        cid = input("Enter Contact ID to permanently remove: ").strip()
        c = self.mgr.find_by_id(cid)
        if not c:
            print(f"[X] Contact '{cid}' not found.")
            return

        confirm = input(f"[!] Are you sure you want to delete '{c.name}' ({c.contact_id})? Type 'YES' to confirm: ").strip()
        if confirm == "YES":
            ok, msg = self.mgr.delete_contact(cid)
            print(f"\n[OK] {msg}" if ok else f"\n[X] {msg}")
        else:
            print("[*] Deletion canceled.")

    def run_analytics_dashboard(self):
        metrics = self.mgr.generate_summary_metrics()
        print("\n========================================================")
        print("     EXECUTIVE ANALYTICS & AUDIT SUMMARY REPORT        ")
        print("========================================================")
        total = metrics["total_contacts"]
        print(f" Total Registered Contacts : {total}")
        print(f" 24/7 Active Services     : {metrics['count_24_7']} ({metrics['pct_24_7']}%)")
        print(f" Verified & Current       : {metrics['audit_status']['verified_current']}")
        print(f" In Need of Review (>180d): {metrics['audit_status']['needs_review']}")
        print(f" Critical SOS Overdue     : {metrics['audit_status']['critical_overdue']}")
        
        # ASCII Bar Chart for Categories
        print("\n--- Distribution by Category ---")
        if total > 0:
            for cat, cnt in sorted(metrics["category_breakdown"].items(), key=lambda x: -x[1]):
                pct = (cnt / total) * 100
                bar = "#" * int(pct / 4)
                print(f"  {cat:<18} | {cnt:>2} ({pct:>5.1f}%) | {bar}")

        # ASCII Bar Chart for Priorities
        print("\n--- Priority Tier Readiness ---")
        if total > 0:
            for prio, cnt in sorted(metrics["priority_breakdown"].items(), key=lambda x: self.mgr._priority_rank(x[0])):
                pct = (cnt / total) * 100
                bar = "=" * int(pct / 4)
                print(f"  {prio:<14} | {cnt:>2} ({pct:>5.1f}%) | {bar}")

        # Threshold Warnings Section
        warnings = metrics.get("warnings", [])
        print(f"\n--- Threshold Warning Flags ({len(warnings)} Detected) ---")
        if not warnings:
            print("  [OK] No anomalous records or compliance breaches detected.")
        else:
            for w in warnings:
                print(f"  [{w['severity']}] Contact [{w['contact_id']}] {w['name']}: {w['message']}")
        print("========================================================\n")

    def run_export_workflow(self):
        print("\n=== MULTI-FORMAT DATA & AUDIT EXPORT ===")
        print("  [1] Export Structured Executive Markdown Report (.md)")
        print("  [2] Export Plain-Text Verification Audit Log (.txt)")
        print("  [3] Export Raw Synchronized CSV Dataset (.csv)")
        print("  [4] Return to Main Menu")

        choice = input("\nSelect export target (1-4): ").strip()
        if choice == "1":
            p = self.mgr.export_summary_markdown()
            print(f"[OK] Markdown Report generated at: {p}")
        elif choice == "2":
            p = self.mgr.export_audit_log()
            print(f"[OK] Audit Log written at: {p}")
        elif choice == "3":
            print(f"[OK] Master CSV file synchronized at: {self.mgr.persistence.csv_file}")
        else:
            print("[*] Returning.")

    def run_import_workflow(self):
        print("\n=== BULK DATASET IMPORT (CSV) ===")
        print("Ingest external contact datasets with automatic validation and error logging.")
        fpath = input("Enter path to CSV file (e.g., sample_data.csv): ").strip()
        if not fpath:
            print("[*] Import aborted.")
            return

        result = self.mgr.bulk_import_csv(fpath)
        if result["success"]:
            print(f"\n[OK] Bulk Import Completed!")
            print(f"     Successfully Imported Records: {result['imported']}")
            if result["errors"]:
                print(f"\n[!] Notice: {len(result['errors'])} row(s) had errors and were skipped:")
                for err in result["errors"][:10]:
                    print(f"     - {err}")
                if len(result["errors"]) > 10:
                    print(f"     ... and {len(result['errors']) - 10} more errors.")
        else:
            print(f"\n[X] Import Failed: {', '.join(result['errors'])}")

    def main_loop(self):
        while True:
            self.print_banner()
            # Quick status line
            total = len(self.mgr.contacts)
            warnings = len(self.mgr.check_threshold_warnings())
            warn_str = f" | [!] {warnings} Threshold Warnings" if warnings else " | [OK] 0 Warnings"
            print(f" Active Database: {total} Contacts loaded{warn_str}\n")

            print(" [1] View All Contacts Directory")
            print(" [2] Query & Search Contacts (Keyword / Category / Zone / 24-7)")
            print(" [3] Record New Emergency Contact (Defensive Validation)")
            print(" [4] Update Existing Contact")
            print(" [5] Delete Contact Record")
            print(" [6] View Executive Summary & Analytics Dashboard")
            print(" [7] Multi-Format Report Export (Markdown / Audit Log / CSV)")
            print(" [8] Bulk Dataset Ingestion (Import CSV with Error Logs)")
            print(" [9] Exit Application")
            
            try:
                choice = input("\nEnter choice (1-9): ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\n\nGoodbye! Stay safe.")
                break

            if choice == "1":
                self.print_table(self.mgr.get_all(), title="Master Campus Emergency Directory")
                input("\nPress Enter to continue...")
            elif choice == "2":
                self.run_search_workflow()
                input("\nPress Enter to continue...")
            elif choice == "3":
                self.run_add_contact_workflow()
                input("\nPress Enter to continue...")
            elif choice == "4":
                self.run_update_workflow()
                input("\nPress Enter to continue...")
            elif choice == "5":
                self.run_delete_workflow()
                input("\nPress Enter to continue...")
            elif choice == "6":
                self.run_analytics_dashboard()
                input("\nPress Enter to continue...")
            elif choice == "7":
                self.run_export_workflow()
                input("\nPress Enter to continue...")
            elif choice == "8":
                self.run_import_workflow()
                input("\nPress Enter to continue...")
            elif choice == "9":
                print("\n[OK] Session saved safely. Exiting CampusSolve.")
                break
            else:
                print("  [X] Invalid selection. Please enter a number 1 through 9.")

# ==========================================
# SEED SAMPLE DATA GENERATOR
# ==========================================
def generate_sample_dataset() -> List[EmergencyContact]:
    """Generates 35+ realistic records covering all campus emergency scenarios and edge cases."""
    raw_samples = [
        # SOS/Critical
        ("CAMP-1001", "Campus Police 24/7 Dispatch", "Security", "555-0100", "555-0101", "police@campus.edu", "Campus-Wide", "Security HQ Rm 101", True, "SOS/Critical", "2026-11-15", "Immediate response dispatch unit"),
        ("CAMP-1002", "Emergency Medical Trauma Center", "Medical", "555-0111", "555-0112", "emt@campus.edu", "Central Quad", "Health Pavilion Wing A", True, "SOS/Critical", "2026-11-10", "Paramedic ambulance station on campus"),
        ("CAMP-1003", "Fire & Hazmat Emergency Response", "Fire & Safety", "555-0119", "555-0120", "hazmat@campus.edu", "Science Complex", "Chemical Safety Bldg B", True, "SOS/Critical", "2026-10-28", "Chemical spill and rapid fire suppression"),
        ("CAMP-1004", "Crisis & Suicide Prevention Lifeline", "Mental Health", "555-0199", "1-800-273-8255", "crisis@campus.edu", "Campus-Wide", "Student Well-being Suite 300", True, "SOS/Critical", "2026-11-01", "Confidential 24/7 mental health emergency team"),
        ("CAMP-1005", "Campus Sexual Assault Support (Title IX)", "Mental Health", "555-0144", "", "advocate@campus.edu", "Central Quad", "Student Services Rm 204", True, "SOS/Critical", "2026-06-15", "Confidential victim advocacy (Needs backup phone)"),

        # High Priority
        ("CAMP-1006", "Student Health Services Clinic", "Medical", "555-0122", "555-0123", "health@campus.edu", "North Campus", "Infirmary Bldg Level 1", False, "High", "2026-10-15", "Mon-Fri 8am-8pm, Sat 9am-2pm urgent walk-in"),
        ("CAMP-1007", "Hostel / Residence Warden Emergency Desk", "Residence/Housing", "555-0130", "555-0131", "warden@campus.edu", "Student Residences", "Dorm Quad Main Office", True, "High", "2026-11-05", "Dorm lockouts, domestic issues, building emergencies"),
        ("CAMP-1008", "Dean of Students Emergency Office", "Administration", "555-0150", "", "dean.emergency@campus.edu", "Central Quad", "Administration Tower Rm 401", False, "High", "2026-09-12", "Student family emergencies and academic accommodations"),
        ("CAMP-1009", "Facilities Gas & Electrical Hazard Desk", "Facilities", "555-0160", "555-0161", "facilities.rapid@campus.edu", "Engineering Block", "Power Substation B", True, "High", "2026-11-02", "Gas leaks, live wires, flooding emergencies"),
        ("CAMP-1010", "Campus SafeWalk Escort Service", "Security", "555-0177", "", "safewalk@campus.edu", "Campus-Wide", "Student Union Ground Floor", False, "High", "2026-11-12", "Night-time walking escort 6 PM - 4 AM"),

        # Medium Priority
        ("CAMP-1011", "Counseling & Psychological Services (CAPS)", "Mental Health", "555-0188", "", "counseling@campus.edu", "North Campus", "Wellness Center Rm 110", False, "Medium", "2026-10-01", "Individual and group counseling appointments"),
        ("CAMP-1012", "Radiation Safety & Lab Officer", "Fire & Safety", "555-0210", "", "radsafety@campus.edu", "Science Complex", "Physics Hall Rm 402", False, "Medium", "2026-04-10", "Stale verification test case (Overdue > 180 days)"),
        ("CAMP-1013", "International Student Support Coordinator", "Administration", "555-0220", "", "intl.support@campus.edu", "Central Quad", "Global Center Rm 105", False, "Medium", "2026-10-20", "Visa & passport emergency assistance"),
        ("CAMP-1014", "Athletics & Gym First Aid Room", "Medical", "555-0230", "", "gym.firstaid@campus.edu", "Athletics Center", "Fieldhouse Rm 12", False, "Medium", "2026-11-08", "Sports injuries and physical rehab"),
        ("CAMP-1015", "Campus IT Cyber Incident Response Team", "Administration", "555-0240", "555-0241", "soc@campus.edu", "Science Complex", "Data Center Annex", True, "Medium", "2026-11-18", "Data breach, ransomware, server outage response"),
        ("CAMP-1016", "Disability & Accessibility Transport", "Administration", "555-0250", "", "access.rides@campus.edu", "Campus-Wide", "Transit Depot", False, "Medium", "2026-10-10", "Wheelchair van shuttle on demand"),
        ("CAMP-1017", "South Campus Housing Security Office", "Residence/Housing", "555-0260", "", "south.housing@campus.edu", "South Campus", "Tower C Gatehouse", True, "Medium", "2026-11-01", "South quad student residence safety"),
        ("CAMP-1018", "Biological Waste & Biohazard Hotline", "Fire & Safety", "555-0270", "", "biohazard@campus.edu", "Science Complex", "Biomedical Tower Rm 103", False, "Medium", "2026-03-14", "Biohazard containment protocol (Stale audit)"),

        # Standard Priority
        ("CAMP-1019", "Campus Lost and Found & Key Control", "Security", "555-0280", "", "lostfound@campus.edu", "Central Quad", "Welcome Center Rm 12", False, "Standard", "2026-10-25", "Recover lost IDs, laptops, transit passes"),
        ("CAMP-1020", "Parking & Campus Transit Dispatch", "Administration", "555-0290", "", "parking@campus.edu", "North Campus", "Parking Structure 2", False, "Standard", "2026-11-04", "Vehicle battery jump, flat tire assistance"),
        ("CAMP-1021", "Campus Food Pantry Emergency Hampers", "Administration", "555-0300", "", "pantry@campus.edu", "South Campus", "Basement Dining Hall", False, "Standard", "2026-09-30", "Food security assistance for students"),
        ("CAMP-1022", "Environmental Health & Occupational Safety", "Fire & Safety", "555-0310", "", "ehs@campus.edu", "Science Complex", "Safety Bldg Rm 201", False, "Standard", "2026-10-14", "Ergonomics, workplace air quality testing"),
        ("CAMP-1023", "Campus Animal Welfare & Pest Control", "Facilities", "555-0320", "", "pestcontrol@campus.edu", "Campus-Wide", "Maintenance Yards", False, "Standard", "2026-08-15", "Wildlife removal and safety"),
        ("CAMP-1024", "Residence Maintenance (Plumbing & HVAC)", "Facilities", "555-0330", "", "dorm.repair@campus.edu", "Student Residences", "Underground Shop 3", True, "Standard", "2026-11-16", "24/7 pipe burst and heating failure repairs"),
        ("CAMP-1025", "Legal Aid Clinic for Students", "Administration", "555-0340", "", "legalaid@campus.edu", "North Campus", "Law Annex Rm 310", False, "Standard", "2026-10-05", "Tenant rights and emergency legal consultation"),

        # External Emergency Services
        ("CAMP-1026", "Municipal City Police Emergency", "External Emergency", "911", "555-0911", "dispatch@citypolice.gov", "Campus-Wide", "Off-Campus Station 4", True, "SOS/Critical", "2026-11-20", "City police joint jurisdiction dispatch"),
        ("CAMP-1027", "Metro Fire & Rescue Department", "External Emergency", "911", "555-0912", "alarm@metrofire.gov", "Campus-Wide", "Station 7 (0.8 miles from campus)", True, "SOS/Critical", "2026-11-20", "City fire department ladder and engine truck"),
        ("CAMP-1028", "Regional Poison Control Center", "External Emergency", "1-800-222-1222", "", "help@poisoncontrol.org", "Campus-Wide", "National Network", True, "SOS/Critical", "2026-11-01", "Toxic ingestion and snake bite emergency advice"),
        ("CAMP-1029", "County Mental Health Mobile Crisis Unit", "External Emergency", "988", "555-0988", "mobilecrisis@countyhealth.gov", "Campus-Wide", "County Health Dept", True, "High", "2026-10-18", "Off-campus rapid mental crisis deployment"),
        ("CAMP-1030", "State Spill Response & Environmental Hotline", "External Emergency", "1-800-424-8802", "", "spill@state.gov", "Campus-Wide", "State Environmental Agency", True, "Medium", "2026-05-10", "Overdue verification test case"),
        
        # Additional Diverse Records
        ("CAMP-1031", "Student Government Emergency Relief Fund", "Administration", "555-0350", "", "sga.relief@campus.edu", "Central Quad", "Student Union 312", False, "Standard", "2026-10-22", "Micro-grants for sudden unexpected crises"),
        ("CAMP-1032", "Campus Chaplaincy & Spiritual Grief Support", "Mental Health", "555-0360", "", "chaplain@campus.edu", "North Campus", "Interfaith Chapel", False, "Standard", "2026-09-15", "Multi-faith bereavement support"),
        ("CAMP-1033", "Engineering Robotics Lab Safety Monitor", "Fire & Safety", "555-0370", "", "robo.safety@campus.edu", "Engineering Block", "Robotics High Bay Rm 105", False, "Medium", "2026-11-14", "High voltage and mechanical arm emergency stop"),
        ("CAMP-1034", "Night Shuttle On-Call Dispatch", "Administration", "555-0380", "", "nightshuttle@campus.edu", "Campus-Wide", "Transit Depot", True, "High", "2026-11-19", "Late night safe transit for campus commuters"),
        ("CAMP-1035", "University Public Affairs & Media Hotline", "Administration", "555-0390", "", "press.emergency@campus.edu", "Central Quad", "Media Center Rm 50", True, "High", "2026-10-30", "Emergency communications and campus-wide alerts")
    ]

    dataset = []
    for item in raw_samples:
        dataset.append(EmergencyContact(
            contact_id=item[0],
            name=item[1],
            category=item[2],
            primary_phone=item[3],
            secondary_phone=item[4],
            email=item[5],
            campus_zone=item[6],
            building_room=item[7],
            is_24_7=item[8],
            priority_tier=item[9],
            last_verified_date=item[10],
            notes=item[11]
        ))
    return dataset

# ==========================================
# MAIN ENTRY POINT
# ==========================================
def main():
    persistence = PersistenceEngine()
    contacts = persistence.load_contacts()

    # If database is fresh/empty, automatically seed with 35 realistic records
    if not contacts:
        print("[*] First-time setup detected. Seeding 35 realistic emergency contacts for demo...")
        sample_records = generate_sample_dataset()
        persistence.save_contacts(sample_records)
        contacts = sample_records
        print(f"[OK] Successfully initialized database with {len(contacts)} contacts across 8 safety categories.\n")

    manager = ContactManager(persistence)
    ui = TerminalUI(manager)
    ui.main_loop()

if __name__ == "__main__":
    main()
