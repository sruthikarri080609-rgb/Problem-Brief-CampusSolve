# CampusSolve: Emergency Contact Organizer
**Project #71** | **Domain:** Safety & Community | **Hackathon Mentor Guide Solution**

A robust, enterprise-grade Python application and modern web interfaces engineered to store trusted emergency contacts locally, validate entries defensively, provide instant multi-criteria search, compute executive analytics, flag threshold compliance warnings, and export audit reports.

---

## 📁 Project Architecture

```
campussolve-emergency-contacts/
│
├── streamlit_app.py             # Modern Streamlit Web Application (for streamlit.io & local)
├── app.py                       # Cloud deployment entrypoint alias
├── requirements.txt             # Pip dependencies for Streamlit Cloud
├── .streamlit/
│   └── config.toml              # Streamlit branding, theme, and server configuration
│
├── emergency_organizer.py       # Core Python application (Terminal UI, Business Logic, Validation, Storage)
├── web_server.py                # Zero-dependency Python REST API server (Standard Library http.server)
├── sample_import_test.csv       # Test dataset with valid & edge-case rows to test bulk CSV import
│
├── data/                        # Persistent local database (survives restarts)
│   ├── emergency_contacts.json  # Primary JSON structured storage
│   └── emergency_contacts.csv   # Synchronized master CSV export
│
├── exports/                     # Generated export reports
│   ├── CampusSolve_Report_*.md  # Structured Markdown Executive Summary
│   └── audit_log_*.txt          # Plain-text Compliance & Audit Log
│
├── web/                         # Companion REST/SPA Web Interface
│   ├── index.html               # Responsive Single-Page Application (Tailwind CSS + Lucide Icons)
│   ├── style.css                # Custom UI styling, badges, transitions & animations
│   └── app.js                   # Client controller: Live search, CRUD operations, CSV ingestion
│
└── CampusSolve_Mini_Project_Report.docx # Complete 23-page academic report (Malla Reddy reference format)
```

---

## 🚀 How to Run the Project

### Prerequisites
- **Python 3.10 or higher** (Python 3.14+ supported).

---

### Option 1: Streamlit Web Dashboard (streamlit.io Interface) ⭐ RECOMMENDED

You can run the polished Streamlit dashboard locally or deploy it directly to the cloud at **[streamlit.io](https://streamlit.io)**!

#### 1. Run Locally:
Install dependencies and launch Streamlit:
```powershell
cd "C:\Users\VIS\.gemini\antigravity\scratch\campussolve-emergency-contacts"
pip install -r requirements.txt
streamlit run streamlit_app.py
```
Your browser will automatically open at:
👉 **`http://localhost:8501/`**

#### 2. Deploy on Streamlit Community Cloud (streamlit.io):
1. Create a GitHub repository and push this folder's contents.
2. Go to **[share.streamlit.io](https://share.streamlit.io)** and log in with your GitHub account.
3. Click **"New app"**.
4. Choose your repository and set the **Main file path** to: `streamlit_app.py` (or `app.py`).
5. Click **"Deploy!"**
Streamlit Cloud will read `requirements.txt`, install dependencies, and give you a public URL (e.g. `https://campussolve.streamlit.app`) to share with anyone!

#### Streamlit Interface Highlights:
- 🚨 **Emergency Speed-Dial Strip**: 1-click calling & dispatch for top campus response units.
- 📋 **Live Search & Interactive Tables**: Real-time filtering by category, zone, priority tier, and 24/7 round-the-clock availability.
- ➕ **Add & Edit Records**: Built-in defensive validation forms for adding or updating contact records.
- 📊 **Executive Analytics & Visual Charts**: Native interactive bar charts showing category breakdowns, priority distribution, zone coverage, and audit compliance health.
- ⚠️ **Automated Threshold Warnings**: Live alert banner flagging stale verifications (>90 days for SOS, >180 days for general) or critical contacts missing secondary phone lines.
- 📁 **1-Click Multi-Format Export**: Direct download buttons for CSV, JSON, Markdown Report, and Text Audit Log.
- 📥 **Bulk CSV Ingestion**: Upload any CSV to inspect row-by-row validation logs and ingest verified contacts.

---

### Option 2: Running the Terminal Console Application (Must-Have CLI)

Open your terminal or PowerShell and run:
```powershell
cd "C:\Users\VIS\.gemini\antigravity\scratch\campussolve-emergency-contacts"
python emergency_organizer.py
```

#### What happens on startup:
1. **Auto-Seed Initialization**: If the database is missing or empty, it automatically populates **35 realistic emergency contacts** across 8 campus safety categories (`Security`, `Medical`, `Mental Health`, `Fire & Safety`, `Residence/Housing`, `Facilities`, `Administration`, `External Emergency`).
2. **Interactive Menu**:
   ```text
    [1] View All Contacts Directory (Fixed-width table)
    [2] Query & Search Contacts (Keyword / Category / Zone / 24-7)
    [3] Record New Emergency Contact (Defensive Validation)
    [4] Update Existing Contact
    [5] Delete Contact Record
    [6] View Executive Summary & Analytics Dashboard (ASCII charts)
    [7] Multi-Format Report Export (Markdown / Audit Log / CSV)
    [8] Bulk Dataset Ingestion (Import CSV with Error Logs)
    [9] Exit Application
   ```

---

### Option 3: Companion Zero-Dependency REST API Web Portal

To launch the standalone zero-dependency Python REST API and HTML5 web portal:
```powershell
cd "C:\Users\VIS\.gemini\antigravity\scratch\campussolve-emergency-contacts"
python web_server.py --port 8000
```
Then open your browser and navigate to:
👉 **`http://localhost:8000/`**

---

## 🧪 Testing Edge Cases & Defensive Validation

1. **Defensive Input Handling**:
   - Phone numbers must contain valid numeric lengths (3 to 16 characters) or recognized emergency codes (`911`, `112`, `100`, `988`).
   - Email format is validated using strict regular expressions.
   - Verification dates cannot be in the future.
2. **Auto-Recovery from Corrupted Files**:
   - If `data/emergency_contacts.json` is modified with invalid syntax, the persistence engine detects `json.JSONDecodeError`, automatically archives the corrupted file to a `.bak` timestamped file, and re-initializes clean storage without crashing.
3. **Bulk CSV Ingestion Error Logging**:
   - Ingest `sample_import_test.csv` to see row-by-row parsing where valid rows are inserted and rows with missing names or invalid phones are cleanly logged without aborting the batch.

---

## 🏆 Hackathon Demo Script (Section 9 Compliance)

1. **Streamlit Showcase**: Launch `streamlit run streamlit_app.py` to demonstrate the interactive web interface, 1-click SOS dialing, interactive search, and live charts.
2. **Introduction**: Launch `python emergency_organizer.py` to showcase the branded console banner and clean status line showing 35 loaded contacts.
3. **Defensive Validation Demo**: Choose Option `[3] Record New Emergency Contact`. Enter invalid characters or blank inputs for name or phone to demonstrate the defensive input loops catching errors.
4. **Search & Retrieval**: Choose Option `[2]` and filter by `Medical` or search for `Trauma` to demonstrate instant lookups.
5. **Analytics & Threshold Warnings**: Choose Option `[6]` to display ASCII charts, totals, and the automated compliance warnings.
6. **Multi-Format Export**: Choose Option `[7] -> [1]` to export the Markdown executive report.
