"""
CampusSolve - Web Server & REST API Backend
Project #71: Emergency Contact Organizer | Domain: Safety & Community

Zero-dependency standard library HTTP server providing:
- Full REST API for emergency contact CRUD operations
- Real-time search, category filtering & 24/7 filtering
- Analytics metrics & threshold warning monitoring
- Multi-format file export (Markdown, CSV, TXT, JSON)
- Bulk CSV import with error logging
- Static asset serving for the web interface
"""

import sys
import os
import json
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import date

# Add current directory to path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from emergency_organizer import (
    PersistenceEngine,
    ContactManager,
    EmergencyContact,
    InputValidator,
    VALID_CATEGORIES,
    VALID_PRIORITIES,
    VALID_CAMPUS_ZONES,
    generate_sample_dataset
)

WEB_DIR = BASE_DIR / "web"
persistence = PersistenceEngine()
contacts = persistence.load_contacts()
if not contacts:
    contacts = generate_sample_dataset()
    persistence.save_contacts(contacts)
manager = ContactManager(persistence)

def safe_str(val, default=""):
    if val is None:
        return default
    return str(val).strip()

class CampusSolveAPIHandler(BaseHTTPRequestHandler):
    def _send_json(self, data, status=200):
        try:
            payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        except Exception as e:
            payload = json.dumps({"error": f"Serialization error: {str(e)}"}).encode("utf-8")
            status = 500

        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(payload)

    def _send_bytes(self, content_bytes: bytes, content_type: str, status=200, headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content_bytes)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "close")
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(content_bytes)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        self.end_headers()

    def _read_body_json(self):
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length <= 0:
            return {}
        raw_body = self.rfile.read(content_length).decode("utf-8")
        try:
            return json.loads(raw_body)
        except json.JSONDecodeError:
            return {}

    def do_GET(self):
        try:
            parsed_url = urllib.parse.urlparse(self.path)
            path = parsed_url.path
            query_params = urllib.parse.parse_qs(parsed_url.query)

            # 1. API: List / Search Contacts
            if path == "/api/contacts":
                q = query_params.get("q", [""])[0]
                cat = query_params.get("category", [""])[0]
                zone = query_params.get("zone", [""])[0]
                prio = query_params.get("priority", [""])[0]
                only_247 = query_params.get("only_24_7", ["false"])[0].lower() in ("true", "1", "yes")

                filtered = manager.search(query=q, category=cat, zone=zone, priority=prio, only_24_7=only_247)
                resp = [c.to_dict() for c in filtered]
                self._send_json(resp, 200)
                return

            # 2. API: Get Single Contact
            if path.startswith("/api/contacts/"):
                cid = path.replace("/api/contacts/", "").strip()
                contact = manager.find_by_id(cid)
                if contact:
                    self._send_json(contact.to_dict(), 200)
                else:
                    self._send_json({"error": f"Contact '{cid}' not found"}, 404)
                return

            # 3. API: Summary Metrics
            if path == "/api/metrics":
                metrics = manager.generate_summary_metrics()
                self._send_json(metrics, 200)
                return

            # 4. API: Threshold Warnings
            if path == "/api/warnings":
                warnings = manager.check_threshold_warnings()
                self._send_json(warnings, 200)
                return

            # 5. API: Metadata Options
            if path == "/api/metadata":
                meta = {
                    "categories": VALID_CATEGORIES,
                    "priorities": VALID_PRIORITIES,
                    "zones": VALID_CAMPUS_ZONES
                }
                self._send_json(meta, 200)
                return

            # 6. API: Exports
            if path.startswith("/api/export"):
                fmt = query_params.get("format", ["md"])[0].lower()
                if fmt == "md":
                    out_path = manager.export_summary_markdown()
                    content = out_path.read_bytes()
                    headers = {"Content-Disposition": f'attachment; filename="{out_path.name}"'}
                    self._send_bytes(content, "text/markdown; charset=utf-8", 200, headers)
                    return
                elif fmt == "txt":
                    out_path = manager.export_audit_log()
                    content = out_path.read_bytes()
                    headers = {"Content-Disposition": f'attachment; filename="{out_path.name}"'}
                    self._send_bytes(content, "text/plain; charset=utf-8", 200, headers)
                    return
                elif fmt == "csv":
                    csv_path = manager.persistence.csv_file
                    content = csv_path.read_bytes() if csv_path.exists() else b""
                    headers = {"Content-Disposition": 'attachment; filename="emergency_contacts_export.csv"'}
                    self._send_bytes(content, "text/csv; charset=utf-8", 200, headers)
                    return
                elif fmt == "json":
                    content = json.dumps([c.to_dict() for c in manager.get_all()], indent=2).encode("utf-8")
                    headers = {"Content-Disposition": 'attachment; filename="emergency_contacts_export.json"'}
                    self._send_bytes(content, "application/json; charset=utf-8", 200, headers)
                    return

            # 7. Static Website Serving
            if path == "/" or path == "":
                target_file = WEB_DIR / "index.html"
            else:
                rel_path = path.lstrip("/")
                target_file = WEB_DIR / rel_path

            if target_file.exists() and target_file.is_file():
                ext = target_file.suffix.lower()
                content_type = "text/plain"
                if ext == ".html":
                    content_type = "text/html; charset=utf-8"
                elif ext == ".css":
                    content_type = "text/css; charset=utf-8"
                elif ext == ".js":
                    content_type = "application/javascript; charset=utf-8"
                elif ext == ".json":
                    content_type = "application/json; charset=utf-8"
                elif ext in (".png", ".jpg", ".jpeg", ".svg", ".ico"):
                    content_type = f"image/{ext.lstrip('.')}"

                self._send_bytes(target_file.read_bytes(), content_type, 200)
                return

            # Fallback 404
            self._send_json({"error": f"Path '{path}' not found."}, 404)
        except Exception as exc:
            self._send_json({"error": f"Internal Server Error: {str(exc)}"}, 500)

    def do_POST(self):
        try:
            path = urllib.parse.urlparse(self.path).path

            # 1. API: Create New Contact
            if path == "/api/contacts":
                body = self._read_body_json()
                
                # Defensive validation
                name = safe_str(body.get("name"))
                name_ok, name_msg = InputValidator.validate_name(name)
                if not name_ok:
                    self._send_json({"error": name_msg}, 400)
                    return

                cat = safe_str(body.get("category"), "Security")
                cat_ok, cat_val = InputValidator.validate_category(cat)
                if not cat_ok:
                    self._send_json({"error": cat_val}, 400)
                    return

                phone = safe_str(body.get("primary_phone"))
                phone_ok, phone_val = InputValidator.validate_phone(phone)
                if not phone_ok:
                    self._send_json({"error": phone_val}, 400)
                    return

                email = safe_str(body.get("email"))
                if email:
                    e_ok, e_msg = InputValidator.validate_email(email, optional=True)
                    if not e_ok:
                        self._send_json({"error": e_msg}, 400)
                        return

                vdate = safe_str(body.get("last_verified_date"), date.today().isoformat())
                d_ok, d_msg = InputValidator.validate_date(vdate)
                if not d_ok:
                    self._send_json({"error": d_msg}, 400)
                    return

                contact_id = safe_str(body.get("contact_id")) or manager.generate_next_id()
                contact = EmergencyContact(
                    contact_id=contact_id,
                    name=name,
                    category=cat_val,
                    primary_phone=phone_val,
                    secondary_phone=safe_str(body.get("secondary_phone")),
                    email=email,
                    campus_zone=safe_str(body.get("campus_zone"), "Campus-Wide"),
                    building_room=safe_str(body.get("building_room"), "Security Desk"),
                    is_24_7=bool(body.get("is_24_7", False)),
                    priority_tier=safe_str(body.get("priority_tier"), "Standard"),
                    last_verified_date=vdate,
                    notes=safe_str(body.get("notes"))
                )

                ok, msg = manager.add_contact(contact)
                if ok:
                    self._send_json({"message": msg, "contact": contact.to_dict()}, 201)
                else:
                    self._send_json({"error": msg}, 400)
                return

            # 2. API: Bulk Import CSV
            if path == "/api/import":
                body = self._read_body_json()
                csv_content = safe_str(body.get("csv_content"))
                if not csv_content:
                    self._send_json({"error": "No CSV content provided."}, 400)
                    return

                temp_path = BASE_DIR / "temp_import.csv"
                try:
                    temp_path.write_text(csv_content, encoding="utf-8")
                    result = manager.bulk_import_csv(str(temp_path))
                    if temp_path.exists():
                        temp_path.unlink()
                    self._send_json(result, 200)
                except Exception as e:
                    self._send_json({"error": str(e)}, 500)
                return

            self._send_json({"error": "Endpoint not found"}, 404)
        except Exception as exc:
            self._send_json({"error": f"Internal Server Error: {str(exc)}"}, 500)

    def do_PUT(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path.startswith("/api/contacts/"):
                cid = path.replace("/api/contacts/", "").strip()
                body = self._read_body_json()
                
                updates = {}
                if "name" in body:
                    name = safe_str(body["name"])
                    ok, err = InputValidator.validate_name(name)
                    if not ok:
                        self._send_json({"error": err}, 400)
                        return
                    updates["name"] = name

                if "category" in body:
                    cat = safe_str(body["category"])
                    ok, err = InputValidator.validate_category(cat)
                    if not ok:
                        self._send_json({"error": err}, 400)
                        return
                    updates["category"] = err

                if "primary_phone" in body:
                    phone = safe_str(body["primary_phone"])
                    ok, err = InputValidator.validate_phone(phone)
                    if not ok:
                        self._send_json({"error": err}, 400)
                        return
                    updates["primary_phone"] = phone

                if "secondary_phone" in body:
                    updates["secondary_phone"] = safe_str(body["secondary_phone"])

                if "email" in body:
                    email = safe_str(body["email"])
                    if email:
                        ok, err = InputValidator.validate_email(email, optional=True)
                        if not ok:
                            self._send_json({"error": err}, 400)
                            return
                    updates["email"] = email

                if "campus_zone" in body:
                    updates["campus_zone"] = safe_str(body["campus_zone"])

                if "building_room" in body:
                    updates["building_room"] = safe_str(body["building_room"])

                if "is_24_7" in body:
                    updates["is_24_7"] = bool(body["is_24_7"])

                if "priority_tier" in body:
                    prio = safe_str(body["priority_tier"])
                    ok, err = InputValidator.validate_priority(prio)
                    if not ok:
                        self._send_json({"error": err}, 400)
                        return
                    updates["priority_tier"] = err

                if "last_verified_date" in body:
                    vdate = safe_str(body["last_verified_date"])
                    ok, err = InputValidator.validate_date(vdate)
                    if not ok:
                        self._send_json({"error": err}, 400)
                        return
                    updates["last_verified_date"] = vdate

                if "notes" in body:
                    updates["notes"] = safe_str(body["notes"])

                ok, msg = manager.update_contact(cid, updates)
                if ok:
                    updated_obj = manager.find_by_id(cid)
                    self._send_json({"message": msg, "contact": updated_obj.to_dict() if updated_obj else {}}, 200)
                else:
                    self._send_json({"error": msg}, 404)
                return

            self._send_json({"error": "Endpoint not found"}, 404)
        except Exception as exc:
            self._send_json({"error": f"Internal Server Error: {str(exc)}"}, 500)

    def do_DELETE(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path.startswith("/api/contacts/"):
                cid = path.replace("/api/contacts/", "").strip()
                ok, msg = manager.delete_contact(cid)
                if ok:
                    self._send_json({"message": msg}, 200)
                else:
                    self._send_json({"error": msg}, 404)
                return

            self._send_json({"error": "Endpoint not found"}, 404)
        except Exception as exc:
            self._send_json({"error": f"Internal Server Error: {str(exc)}"}, 500)

    def log_message(self, format, *args):
        print(f"[HTTP {self.command}] {self.path} - {args[0] if args else ''}")

def start_server(host="127.0.0.1", port=8000):
    server = HTTPServer((host, port), CampusSolveAPIHandler)
    print("=" * 65)
    print("  CAMPUSSOLVE: EMERGENCY CONTACT ORGANIZER - WEB PORTAL")
    print("=" * 65)
    print(f"  [+] Local Web App running at : http://{host}:{port}/")
    print(f"  [+] REST API Endpoint       : http://{host}:{port}/api/contacts")
    print(f"  [+] Database Location       : {persistence.json_file}")
    print("  [+] Press Ctrl+C in terminal to stop server.")
    print("=" * 65)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Stopping web server...")
        server.server_close()
        print("[OK] Server shutdown successfully.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CampusSolve Web Server")
    parser.add_argument("--port", type=int, default=8000, help="Port to run web server on (default: 8000)")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host interface (default: 127.0.0.1)")
    args = parser.parse_args()
    start_server(host=args.host, port=args.port)
